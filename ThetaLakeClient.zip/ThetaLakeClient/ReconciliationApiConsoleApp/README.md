# Reconciliation API Console Application

This project is a C# console application that utilizes the Reconciliation API to interact with the `reconciliation/new` and `reconciliation/count` endpoints. It exposes a simple interface for users to input data and receive responses from the API.

## Project Structure

- **src/**: Contains the source code for the application.
  - **Program.cs**: Entry point of the console application. Sets up the host and configures services and middleware.
  - **ReconciliationApiClient.cs**: Contains the `ReconciliationApiClient` class, which handles HTTP requests to the reconciliation API.
  - **Controllers/**: Contains the controllers for handling API requests.
    - **ReconciliationController.cs**: Exposes endpoints for the reconciliation API calls.
  - **Models/**: Contains the data models used for requests and responses.
    - **ReconciliationRequest.cs**: Defines the structure of the request body for the reconciliation API calls.
    - **ReconciliationResponse.cs**: Defines the structure of the response returned by the reconciliation API calls.
  - **Startup.cs**: Configures services and middleware for the application, including dependency injection and routing.

- **ReconciliationApiConsoleApp.csproj**: Project file containing information about dependencies and build settings.

## Getting Started

### Prerequisites

- .NET SDK (version 5.0 or later)
- A valid API key for accessing the Reconciliation API

### Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd ReconciliationApiConsoleApp
   ```
3. Restore the dependencies:
   ```
   dotnet restore
   ```

### Running the Application

To run the application, use the following command:
```
dotnet run --project ReconciliationApiConsoleApp.csproj
```

### Using the API Endpoints

The application exposes endpoints to interact with the Reconciliation API. You can send requests to the following endpoints:

- **POST /reconciliation/new**: To create a new reconciliation.
- **GET /reconciliation/count**: To get the count of reconciliations.

Make sure to provide the necessary input in the request body for the `reconciliation/new` endpoint and handle the responses accordingly.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.