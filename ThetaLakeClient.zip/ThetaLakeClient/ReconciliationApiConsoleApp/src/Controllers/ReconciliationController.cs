using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ReconciliationApiConsoleApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReconciliationController : ControllerBase
    {
        private readonly ReconciliationApiClient _apiClient;

        public ReconciliationController(ReconciliationApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        [HttpPost("new")]
        public async Task<IActionResult> CreateReconciliation([FromBody] ReconciliationRequest request)
        {
            if (request == null)
            {
                return BadRequest("Invalid request.");
            }

            var response = await _apiClient.CreateReconciliationAsync(request);
            return Ok(response);
        }

        [HttpGet("count")]
        public async Task<IActionResult> GetReconciliationCount()
        {
            var response = await _apiClient.GetReconciliationCountAsync();
            return Ok(response);
        }
    }
}