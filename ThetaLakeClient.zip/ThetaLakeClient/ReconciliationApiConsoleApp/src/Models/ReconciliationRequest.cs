public class ReconciliationRequest
{
    public string Parameter1 { get; set; }
    public string Parameter2 { get; set; }
    // Add additional properties as needed for the reconciliation request
}