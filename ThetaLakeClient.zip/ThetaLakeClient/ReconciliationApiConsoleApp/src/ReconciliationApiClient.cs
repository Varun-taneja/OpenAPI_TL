using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

public class ReconciliationApiClient
{
    private readonly HttpClient _httpClient;

    public ReconciliationApiClient(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<ReconciliationResponse> CreateReconciliationAsync(ReconciliationRequest request)
    {
        var response = await _httpClient.PostAsJsonAsync("reconciliation/new", request);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ReconciliationResponse>();
    }

    public async Task<ReconciliationResponse> CountReconciliationAsync(ReconciliationRequest request)
    {
        var response = await _httpClient.PostAsJsonAsync("reconciliation/count", request);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ReconciliationResponse>();
    }
}