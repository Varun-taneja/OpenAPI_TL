# Org.OpenAPITools.Api.AnalysisApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**AnalysisPolicyHitsGet**](AnalysisApi.md#analysispolicyhitsget) | **GET** /analysis/policy_hits | List all policy hits |

<a id="analysispolicyhitsget"></a>
# **AnalysisPolicyHitsGet**
> ListAllPolicyHitsResponse AnalysisPolicyHitsGet ()

List all policy hits

**REQUIRED PERMISSIONS:** `analysis:read`   **RATE LIMIT:** `medium` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**ListAllPolicyHitsResponse**](ListAllPolicyHitsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A list of policy hits |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

