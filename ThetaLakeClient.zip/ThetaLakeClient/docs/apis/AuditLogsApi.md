# Org.OpenAPITools.Api.AuditLogsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**AuditLogsConfigChangeGet**](AuditLogsApi.md#auditlogsconfigchangeget) | **GET** /audit_logs/config_change | List all configuration change audit logs |
| [**AuditLogsGet**](AuditLogsApi.md#auditlogsget) | **GET** /audit_logs | List all audit logs |

<a id="auditlogsconfigchangeget"></a>
# **AuditLogsConfigChangeGet**
> GetAuditLogResponse AuditLogsConfigChangeGet (int userId = null, DateOnly fromDate = null, DateOnly toDate = null, string pageToken = null, int max = null)

List all configuration change audit logs

**REQUIRED PERMISSIONS:** `audit_log:read`   **RATE LIMIT:** `heavy`  **NOTE:** Gets an (optionally filtered) list of audit logs for configuration changes related to the current user's org unit. This will contain the following auditable types: - Archive Bucket - Directory Group - Disclaimer Group - Entry Strategy - Integration - License - Microsoft Teams Disclaimer - Org Unit - Policy - Role - Storage Account - Supervision Space - Workflow  And the following auditable actions: - Create - Update - Delete - Disable - Enable 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **userId** | **int** | An user ID to filter by | [optional]  |
| **fromDate** | **DateOnly** | Filter audit_logs with created_at date starting at this value, uses the [RFC3339 full-date format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional]  |
| **toDate** | **DateOnly** | Filter audit_logs with created_at date ending at this value, uses the [RFC3339 full-date format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional]  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetAuditLogResponse**](GetAuditLogResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a paginated list of org_unit&#39;s audit_logs matching the criteria, for configuration changes |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="auditlogsget"></a>
# **AuditLogsGet**
> GetAuditLogResponse AuditLogsGet (int userId = null, AuditableType auditableType = null, DateOnly fromDate = null, DateOnly toDate = null, AuditableAction auditableAction = null, string pageToken = null, int max = null)

List all audit logs

**REQUIRED PERMISSIONS:** `audit_log:read`   **RATE LIMIT:** `heavy`  **NOTE:** Gets an (optionally filtered) list of audit logs for the current user's org unit 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **userId** | **int** | An user ID to filter by | [optional]  |
| **auditableType** | **AuditableType** | An auditable type to filter by | [optional]  |
| **fromDate** | **DateOnly** | Filter audit_logs with created_at date starting at this value, uses the [RFC3339 full-date format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional]  |
| **toDate** | **DateOnly** | Filter audit_logs with created_at date ending at this value, uses the [RFC3339 full-date format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional]  |
| **auditableAction** | **AuditableAction** | An auditable action to filter by (see response) | [optional]  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetAuditLogResponse**](GetAuditLogResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a paginated list of org_unit&#39;s audit_logs matching the criteria, and the allowed values for the auditable type and action filters |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

