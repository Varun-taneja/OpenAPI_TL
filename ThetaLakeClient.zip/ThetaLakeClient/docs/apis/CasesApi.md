# Org.OpenAPITools.Api.CasesApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**CasesGet**](CasesApi.md#casesget) | **GET** /cases | List all cases |
| [**CasesIdClosePut**](CasesApi.md#casesidcloseput) | **PUT** /cases/{id}/close | Close a case |
| [**CasesIdGet**](CasesApi.md#casesidget) | **GET** /cases/{id} | Get case by ID |
| [**CasesIdOpenPut**](CasesApi.md#casesidopenput) | **PUT** /cases/{id}/open | Reopen a case |
| [**CasesIdPut**](CasesApi.md#casesidput) | **PUT** /cases/{id} | Update a case |
| [**CasesIdRecordsDelete**](CasesApi.md#casesidrecordsdelete) | **DELETE** /cases/{id}/records | Remove records from a case |
| [**CasesIdRecordsPost**](CasesApi.md#casesidrecordspost) | **POST** /cases/{id}/records | Add records to a case |
| [**CasesPost**](CasesApi.md#casespost) | **POST** /cases | Create new case |

<a id="casesget"></a>
# **CasesGet**
> GetCasesResponse CasesGet (string pageToken = null, int max = null)

List all cases

**REQUIRED PERMISSIONS:** `cases:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetCasesResponse**](GetCasesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A paginated list of cases |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidcloseput"></a>
# **CasesIdClosePut**
> GetCaseResponse CasesIdClosePut (int id, CloseCaseBody closeCaseBody = null)

Close a case

**REQUIRED PERMISSIONS:** `cases:update`   **RATE LIMIT:** `heavy`   **NOTE:** This endpoint closes the case, it does not delete it. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to close |  |
| **closeCaseBody** | [**CloseCaseBody**](CloseCaseBody.md) |  | [optional]  |

### Return type

[**GetCaseResponse**](GetCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The closed case |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidget"></a>
# **CasesIdGet**
> GetCaseResponse CasesIdGet (int id)

Get case by ID

**REQUIRED PERMISSIONS:** `cases:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to retrieve |  |

### Return type

[**GetCaseResponse**](GetCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The case with the given ID |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidopenput"></a>
# **CasesIdOpenPut**
> GetCaseResponse CasesIdOpenPut (int id)

Reopen a case

**REQUIRED PERMISSIONS:** `cases:update`   **RATE LIMIT:** `heavy`   **NOTE:** This endpoint reopens a case that has been closed 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to reopen |  |

### Return type

[**GetCaseResponse**](GetCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The reopened case |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidput"></a>
# **CasesIdPut**
> GetCaseResponse CasesIdPut (int id, PostCaseBody postCaseBody = null)

Update a case

**REQUIRED PERMISSIONS:** `cases:create`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to update |  |
| **postCaseBody** | [**PostCaseBody**](PostCaseBody.md) |  | [optional]  |

### Return type

[**GetCaseResponse**](GetCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated case |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidrecordsdelete"></a>
# **CasesIdRecordsDelete**
> RemoveRecordIdsFromCaseResponse CasesIdRecordsDelete (int id, RemoveRecordIdsFromCaseBody removeRecordIdsFromCaseBody = null)

Remove records from a case

**REQUIRED PERMISSIONS:** `cases:remove_records`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to remove records from |  |
| **removeRecordIdsFromCaseBody** | [**RemoveRecordIdsFromCaseBody**](RemoveRecordIdsFromCaseBody.md) |  | [optional]  |

### Return type

[**RemoveRecordIdsFromCaseResponse**](RemoveRecordIdsFromCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response containing the removed record ids |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casesidrecordspost"></a>
# **CasesIdRecordsPost**
> AddRecordIdsToCaseResponse CasesIdRecordsPost (int id, AddRecordIdsToCaseBody addRecordIdsToCaseBody = null)

Add records to a case

**REQUIRED PERMISSIONS:** `cases:add_records`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The id of the case to add records to |  |
| **addRecordIdsToCaseBody** | [**AddRecordIdsToCaseBody**](AddRecordIdsToCaseBody.md) |  | [optional]  |

### Return type

[**AddRecordIdsToCaseResponse**](AddRecordIdsToCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response containing the added record ids |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="casespost"></a>
# **CasesPost**
> GetCaseResponse CasesPost (PostCaseBody postCaseBody = null)

Create new case

**REQUIRED PERMISSIONS:** `cases:create`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postCaseBody** | [**PostCaseBody**](PostCaseBody.md) |  | [optional]  |

### Return type

[**GetCaseResponse**](GetCaseResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The created case |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

