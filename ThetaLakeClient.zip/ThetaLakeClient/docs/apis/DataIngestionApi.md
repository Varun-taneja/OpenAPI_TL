# Org.OpenAPITools.Api.DataIngestionApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**IngestionExistsGet**](DataIngestionApi.md#ingestionexistsget) | **GET** /ingestion/exists | Check data already exists |
| [**IngestionIntegrationIdAudioPost**](DataIngestionApi.md#ingestionintegrationidaudiopost) | **POST** /ingestion/integration/{id}/audio | Upload audio |
| [**IngestionIntegrationIdChatPost**](DataIngestionApi.md#ingestionintegrationidchatpost) | **POST** /ingestion/integration/{id}/chat | Upload chats |
| [**IngestionIntegrationIdDocumentPost**](DataIngestionApi.md#ingestionintegrationiddocumentpost) | **POST** /ingestion/integration/{id}/document | Upload documents |
| [**IngestionIntegrationIdEmailPost**](DataIngestionApi.md#ingestionintegrationidemailpost) | **POST** /ingestion/integration/{id}/email | Upload emails |
| [**IngestionIntegrationIdOtherPost**](DataIngestionApi.md#ingestionintegrationidotherpost) | **POST** /ingestion/integration/{id}/other | Upload other data |
| [**IngestionIntegrationIdStateGet**](DataIngestionApi.md#ingestionintegrationidstateget) | **GET** /ingestion/integration/{id}/state | Get integration state |
| [**IngestionIntegrationIdStatePut**](DataIngestionApi.md#ingestionintegrationidstateput) | **PUT** /ingestion/integration/{id}/state | Update integration state |
| [**IngestionIntegrationIdVideoPost**](DataIngestionApi.md#ingestionintegrationidvideopost) | **POST** /ingestion/integration/{id}/video | Upload videos |
| [**IngestionQuotaGet**](DataIngestionApi.md#ingestionquotaget) | **GET** /ingestion/quota | Get upload quota |

<a id="ingestionexistsget"></a>
# **IngestionExistsGet**
> GetDatumIdentityResponse IngestionExistsGet (List<string> identityData = null, List<string> hashSha256 = null)

Check data already exists

**REQUIRED PERMISSION:** `ingestion:read`   **RATE LIMIT:** `light`   **NOTE:** This endpoint supports searching for multiple datums. Because of this behavior it will never return a 404 Not Found, but instead just a blank response array.   Depending on the datum type (audio, chat, document, email, other, or video) different fields are returned. Fields that are always returned are denoted with a '*'.   Only 1 identifier can be specified, if both are specified, only `identity_data` will be checked 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **identityData** | [**List&lt;string&gt;**](string.md) | The arbitrary string identifier data associated with the record. NOTE: Limit of 20 per request | [optional]  |
| **hashSha256** | [**List&lt;string&gt;**](string.md) | The sha256 hash of the record to check. NOTE: Limit of 20 per request | [optional]  |

### Return type

[**GetDatumIdentityResponse**](GetDatumIdentityResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The datums matching the given &#x60;identity_data&#x60; in the request |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidaudiopost"></a>
# **IngestionIntegrationIdAudioPost**
> PostDatumResponse IngestionIntegrationIdAudioPost (int id, bool xThetalakeMetaonly = null, string xThetalakeContentType = null, PostAudioBodyMeta meta = null, System.IO.Stream data = null)

Upload audio

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the audio should be uploaded |  |
| **xThetalakeMetaonly** | **bool** | Must be set true if no audio file is attached | [optional]  |
| **xThetalakeContentType** | **string** | The content type using standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml). Must be set if no audio file is attached, must **NOT** be set if there is an audio file attached | [optional]  |
| **meta** | [**PostAudioBodyMeta**](PostAudioBodyMeta.md) |  | [optional]  |
| **data** | **System.IO.Stream****System.IO.Stream** | The audio to upload | [optional]  |

### Return type

[**PostDatumResponse**](PostDatumResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the audio has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidchatpost"></a>
# **IngestionIntegrationIdChatPost**
> PostChatResponse IngestionIntegrationIdChatPost (int id, PostChatConversationBodyMeta meta = null, PostChatConversationBodyChat chat = null, List<System.IO.Stream> attachments = null)

Upload chats

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy`   **NOTE:** This endpoint performs the upload of the chat data, image attachments, and file attachments.           The response contains upload responses for the chat data which includes the image attachments            and for the file attachments. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the chat conversation should be uploaded |  |
| **meta** | [**PostChatConversationBodyMeta**](PostChatConversationBodyMeta.md) |  | [optional]  |
| **chat** | [**PostChatConversationBodyChat**](PostChatConversationBodyChat.md) |  | [optional]  |
| **attachments** | **List&lt;System.IO.Stream&gt;** | The actual attachment files from the chat messages | [optional]  |

### Return type

[**PostChatResponse**](PostChatResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the chat conversation has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationiddocumentpost"></a>
# **IngestionIntegrationIdDocumentPost**
> PostDatumResponse IngestionIntegrationIdDocumentPost (int id, bool xThetalakeMetaonly = null, string xThetalakeContentType = null, PostDocumentBodyMeta meta = null, System.IO.Stream data = null)

Upload documents

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the document should be uploaded |  |
| **xThetalakeMetaonly** | **bool** | Must be set true if no data file is attached | [optional]  |
| **xThetalakeContentType** | **string** | The content type using standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml). Must be set if no data file is attached, must **NOT** be set if there is a data file attached | [optional]  |
| **meta** | [**PostDocumentBodyMeta**](PostDocumentBodyMeta.md) |  | [optional]  |
| **data** | **System.IO.Stream****System.IO.Stream** | The document to upload | [optional]  |

### Return type

[**PostDatumResponse**](PostDatumResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the data has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidemailpost"></a>
# **IngestionIntegrationIdEmailPost**
> PostDatumResponse IngestionIntegrationIdEmailPost (int id, bool xThetalakeMetaonly = null, string xThetalakeContentType = null, PostEmailBodyMeta meta = null, System.IO.Stream data = null)

Upload emails

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy`   **NOTE:** The `Content-Type` of the data part must be `message/rfc822`. Participant metadata should not be included in the JSON meta payload as it is parsed directly from the attached EML file. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the data should be uploaded |  |
| **xThetalakeMetaonly** | **bool** | Must be set true if no data file is attached | [optional]  |
| **xThetalakeContentType** | **string** | The content type using standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml). Must be set if no data file is attached, must **NOT** be set if there is a data file attached | [optional]  |
| **meta** | [**PostEmailBodyMeta**](PostEmailBodyMeta.md) |  | [optional]  |
| **data** | **System.IO.Stream****System.IO.Stream** | The file to upload | [optional]  |

### Return type

[**PostDatumResponse**](PostDatumResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the data has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidotherpost"></a>
# **IngestionIntegrationIdOtherPost**
> PostDatumResponse IngestionIntegrationIdOtherPost (int id, bool xThetalakeMetaonly = null, string xThetalakeContentType = null, PostDatumBodyMeta meta = null, System.IO.Stream data = null)

Upload other data

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the data should be uploaded |  |
| **xThetalakeMetaonly** | **bool** | Must be set true if no data file is attached | [optional]  |
| **xThetalakeContentType** | **string** | The content type using standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml). Must be set if no data file is attached, must **NOT** be set if there is a data file attached | [optional]  |
| **meta** | [**PostDatumBodyMeta**](PostDatumBodyMeta.md) |  | [optional]  |
| **data** | **System.IO.Stream****System.IO.Stream** | The file to upload | [optional]  |

### Return type

[**PostDatumResponse**](PostDatumResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the data has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidstateget"></a>
# **IngestionIntegrationIdStateGet**
> GetIntegrationStateResponse IngestionIntegrationIdStateGet (int id)

Get integration state

**REQUIRED PERMISSION:** `ingestion:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration state to get |  |

### Return type

[**GetIntegrationStateResponse**](GetIntegrationStateResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved integration state |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidstateput"></a>
# **IngestionIntegrationIdStatePut**
> GetIntegrationStateResponse IngestionIntegrationIdStatePut (int id, PutIntegrationStateRequest putIntegrationStateRequest)

Update integration state

**REQUIRED PERMISSION:** `ingestion:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration state to update |  |
| **putIntegrationStateRequest** | [**PutIntegrationStateRequest**](PutIntegrationStateRequest.md) | The integration state to set |  |

### Return type

[**GetIntegrationStateResponse**](GetIntegrationStateResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated integration state |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionintegrationidvideopost"></a>
# **IngestionIntegrationIdVideoPost**
> PostDatumResponse IngestionIntegrationIdVideoPost (int id, bool xThetalakeMetaonly = null, string xThetalakeContentType = null, PostVideoBodyMeta meta = null, System.IO.Stream data = null)

Upload videos

**REQUIRED PERMISSION:** `ingestion:upload`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to which the video should be uploaded |  |
| **xThetalakeMetaonly** | **bool** | Must be set true if no video file is attached | [optional]  |
| **xThetalakeContentType** | **string** | The content type using standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml). Must be set if no video file is attached, must **NOT** be set if there is an video file attached | [optional]  |
| **meta** | [**PostVideoBodyMeta**](PostVideoBodyMeta.md) |  | [optional]  |
| **data** | **System.IO.Stream****System.IO.Stream** | The video to upload | [optional]  |

### Return type

[**PostDatumResponse**](PostDatumResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The response when the video has been uploaded |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The data has already been uploaded |  -  |
| **415** | The uploaded file&#39;s content type is not supported |  -  |
| **423** | This error indicates that the API refused to process the request because the resource is currently locked. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="ingestionquotaget"></a>
# **IngestionQuotaGet**
> QuotaResponse IngestionQuotaGet (string from = null, string to = null)

Get upload quota

**REQUIRED PERMISSION:** `ingestion:read`   **RATE LIMIT:** `heavy`   **NOTE:** The quota is for the entire org unit 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **from** | **string** | A date in YYYY-MM-DD format that is the start of the time range to summarize in, if not provided the summary starts at the beginning of time | [optional]  |
| **to** | **string** | A date in YYY_MM_DD format that is the end of the time range to summarize, if not provided the summary ends with the current day | [optional]  |

### Return type

[**QuotaResponse**](QuotaResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The upload quota |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

