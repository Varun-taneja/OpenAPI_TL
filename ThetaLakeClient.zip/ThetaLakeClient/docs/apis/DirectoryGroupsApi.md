# Org.OpenAPITools.Api.DirectoryGroupsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**DirectoryGroupsGet**](DirectoryGroupsApi.md#directorygroupsget) | **GET** /directory_groups | List all directory groups |
| [**DirectoryGroupsIdDelete**](DirectoryGroupsApi.md#directorygroupsiddelete) | **DELETE** /directory_groups/{id} | Delete directory group |
| [**DirectoryGroupsIdGet**](DirectoryGroupsApi.md#directorygroupsidget) | **GET** /directory_groups/{id} | Get directory group by ID |
| [**DirectoryGroupsIdIdentitiesPost**](DirectoryGroupsApi.md#directorygroupsididentitiespost) | **POST** /directory_groups/{id}/identities | Add existing identities to directory group |
| [**DirectoryGroupsIdIdentityIdentityIdDelete**](DirectoryGroupsApi.md#directorygroupsididentityidentityiddelete) | **DELETE** /directory_groups/{id}/identity/{identity_id} | Remove identity from directory group |
| [**DirectoryGroupsIdIdentityPost**](DirectoryGroupsApi.md#directorygroupsididentitypost) | **POST** /directory_groups/{id}/identity | Create a new identity in directory group |
| [**DirectoryGroupsIdPut**](DirectoryGroupsApi.md#directorygroupsidput) | **PUT** /directory_groups/{id} | Update directory group |
| [**DirectoryGroupsPost**](DirectoryGroupsApi.md#directorygroupspost) | **POST** /directory_groups | Create a new directory group |
| [**DirectoryGroupsUploadPost**](DirectoryGroupsApi.md#directorygroupsuploadpost) | **POST** /directory_groups/upload | Upload directory groups &amp; identities |

<a id="directorygroupsget"></a>
# **DirectoryGroupsGet**
> GetDirectoryGroupResponse DirectoryGroupsGet (string pageToken = null, int max = null, bool includeIdentities = null)

List all directory groups

**REQUIRED PERMISSION:** `directory_group:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25,  max is 500 | [optional]  |
| **includeIdentities** | **bool** | Include the identities in the response. Defaults to **true** | [optional]  |

### Return type

[**GetDirectoryGroupResponse**](GetDirectoryGroupResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains a paged list of directory groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsiddelete"></a>
# **DirectoryGroupsIdDelete**
> DeleteDirectoryGroupResponse DirectoryGroupsIdDelete (int id)

Delete directory group

**REQUIRED PERMISSION:** `directory_group:delete`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the directory group to delete |  |

### Return type

[**DeleteDirectoryGroupResponse**](DeleteDirectoryGroupResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The directory group has been successfully updated |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsidget"></a>
# **DirectoryGroupsIdGet**
> GetDirectoryGroupByIdResponse DirectoryGroupsIdGet (int id, bool includeIdentities = null)

Get directory group by ID

**REQUIRED PERMISSION:** `directory_group:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the directory group to get |  |
| **includeIdentities** | **bool** | Include the identities in the response. Defaults to **true** | [optional]  |

### Return type

[**GetDirectoryGroupByIdResponse**](GetDirectoryGroupByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Responds with the directory group and the associated identities |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsididentitiespost"></a>
# **DirectoryGroupsIdIdentitiesPost**
> PutDirectoryGroupIdentitiesResponse DirectoryGroupsIdIdentitiesPost (int id, List<int> requestBody)

Add existing identities to directory group

**REQUIRED PERMISSION:** `directory_group:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The group ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**PutDirectoryGroupIdentitiesResponse**](PutDirectoryGroupIdentitiesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The directory group has been successfully updated |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The specific resource has a conflict (e.g. already exists) |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsididentityidentityiddelete"></a>
# **DirectoryGroupsIdIdentityIdentityIdDelete**
> DeleteDirectoryGroupIdentityResponse DirectoryGroupsIdIdentityIdentityIdDelete (int id, int identityId)

Remove identity from directory group

**REQUIRED PERMISSION:** `directory_group:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The group ID |  |
| **identityId** | **int** | The ID of the identity to delete from the group |  |

### Return type

[**DeleteDirectoryGroupIdentityResponse**](DeleteDirectoryGroupIdentityResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The directory group has been successfully updated |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsididentitypost"></a>
# **DirectoryGroupsIdIdentityPost**
> PostDirectoryGroupIdentityResponse DirectoryGroupsIdIdentityPost (int id, PostDirectoryGroupIdentityRequest postDirectoryGroupIdentityRequest)

Create a new identity in directory group

**REQUIRED PERMISSION:** `directory_group:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the directory group to add the identity |  |
| **postDirectoryGroupIdentityRequest** | [**PostDirectoryGroupIdentityRequest**](PostDirectoryGroupIdentityRequest.md) |  |  |

### Return type

[**PostDirectoryGroupIdentityResponse**](PostDirectoryGroupIdentityResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The directory group has been successfully updated |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **409** | The specific resource has a conflict (e.g. already exists) |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsidput"></a>
# **DirectoryGroupsIdPut**
> PutDirectoryGroupByIdResponse DirectoryGroupsIdPut (int id, PutDirectoryGroupByIdRequest putDirectoryGroupByIdRequest)

Update directory group

**REQUIRED PERMISSION:** ``directory_group:update``   **RATE LIMIT:** `light`   **NOTE:** Allows updating the external ID, name, and description of a directory group. The external ID must be unique among the directory groups otherwise the API will return a `409 Conflict` error. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the directory group to update |  |
| **putDirectoryGroupByIdRequest** | [**PutDirectoryGroupByIdRequest**](PutDirectoryGroupByIdRequest.md) |  |  |

### Return type

[**PutDirectoryGroupByIdResponse**](PutDirectoryGroupByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The directory group has been successfully updated |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **409** | The specific resource has a conflict (e.g. already exists) |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupspost"></a>
# **DirectoryGroupsPost**
> PostDirectoryGroupResponse DirectoryGroupsPost (PostDirectoryGroupRequest postDirectoryGroupRequest = null)

Create a new directory group

**REQUIRED PERMISSION:** `directory_group:create`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postDirectoryGroupRequest** | [**PostDirectoryGroupRequest**](PostDirectoryGroupRequest.md) |  | [optional]  |

### Return type

[**PostDirectoryGroupResponse**](PostDirectoryGroupResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains a list of directory groups with optional paging. |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="directorygroupsuploadpost"></a>
# **DirectoryGroupsUploadPost**
> PostUploadCsvResponse DirectoryGroupsUploadPost (System.IO.Stream file = null)

Upload directory groups & identities

**REQUIRED PERMISSION:** `directory_group:update`   **RATE LIMIT:** `light`   **NOTE:** CSV headers are `name,email,phone,userid,groupname,groupdesc,groupid`<br /> Extra columns can be added and will be processed as `extra_attributes`.<br /> Example CSV can be found [here](/api/v1/static/files/upload_example.csv).<br /> 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **file** | **System.IO.Stream****System.IO.Stream** | The file to upload | [optional]  |

### Return type

[**PostUploadCsvResponse**](PostUploadCsvResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The CSV was successfully uploaded and processed |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **422** | This error indicates that the API was unable to process the uploaded file. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

