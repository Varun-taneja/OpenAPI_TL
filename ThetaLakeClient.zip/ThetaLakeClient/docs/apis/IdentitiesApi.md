# Org.OpenAPITools.Api.IdentitiesApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**IdentitiesExtraAttributesIdDelete**](IdentitiesApi.md#identitiesextraattributesiddelete) | **DELETE** /identities/extra_attributes/{id} | Delete an identity extra_attribute |
| [**IdentitiesExtraAttributesIdGet**](IdentitiesApi.md#identitiesextraattributesidget) | **GET** /identities/extra_attributes/{id} | Get extra_attribute by ID |
| [**IdentitiesExtraAttributesIdMakePrimaryPut**](IdentitiesApi.md#identitiesextraattributesidmakeprimaryput) | **PUT** /identities/extra_attributes/{id}/make_primary | Make an extra_attribute the primary |
| [**IdentitiesExtraAttributesIdPut**](IdentitiesApi.md#identitiesextraattributesidput) | **PUT** /identities/extra_attributes/{id} | Update an identity extra_attribute |
| [**IdentitiesGet**](IdentitiesApi.md#identitiesget) | **GET** /identities | List all identities |
| [**IdentitiesIdDelete**](IdentitiesApi.md#identitiesiddelete) | **DELETE** /identities/{id} | Delete an identity |
| [**IdentitiesIdExtraAttributesPost**](IdentitiesApi.md#identitiesidextraattributespost) | **POST** /identities/{id}/extra_attributes | Create a new extra_attribute on an identity |
| [**IdentitiesIdGet**](IdentitiesApi.md#identitiesidget) | **GET** /identities/{id} | Get identity by ID |
| [**IdentitiesIdPut**](IdentitiesApi.md#identitiesidput) | **PUT** /identities/{id} | Update identity |
| [**IdentitiesIdRiskGet**](IdentitiesApi.md#identitiesidriskget) | **GET** /identities/{id}/risk | Get identity risk log |
| [**IdentitiesIdRiskPost**](IdentitiesApi.md#identitiesidriskpost) | **POST** /identities/{id}/risk | Flag the identity as risky |
| [**IdentitiesIdSupervisionSpacesGet**](IdentitiesApi.md#identitiesidsupervisionspacesget) | **GET** /identities/{id}/supervision_spaces | Get supervision spaces for identity (beta) |
| [**IdentitiesPost**](IdentitiesApi.md#identitiespost) | **POST** /identities | Create a new identity |
| [**IdentitiesPut**](IdentitiesApi.md#identitiesput) | **PUT** /identities | Merge two identities |
| [**IdentitiesSearchGet**](IdentitiesApi.md#identitiessearchget) | **GET** /identities/search | Search Identities |

<a id="identitiesextraattributesiddelete"></a>
# **IdentitiesExtraAttributesIdDelete**
> DeleteExtraAttributeResponse IdentitiesExtraAttributesIdDelete (int id)

Delete an identity extra_attribute

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The extra_attribute ID to delete |  |

### Return type

[**DeleteExtraAttributeResponse**](DeleteExtraAttributeResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Status message indicating successful deletion |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesextraattributesidget"></a>
# **IdentitiesExtraAttributesIdGet**
> GetExtraAttributeResponse IdentitiesExtraAttributesIdGet (int id)

Get extra_attribute by ID

**REQUIRED PERMISSION:** `identities:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The extra_attribute ID to get |  |

### Return type

[**GetExtraAttributeResponse**](GetExtraAttributeResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The identity that owns the updated extra_attribute |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesextraattributesidmakeprimaryput"></a>
# **IdentitiesExtraAttributesIdMakePrimaryPut**
> PutExtraAttributePrimaryResponse IdentitiesExtraAttributesIdMakePrimaryPut (int id)

Make an extra_attribute the primary

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light`   **NOTE:** Makes the extra_attribute the primary attribute on the identity by swapping the values. <br /> Example: Given the following identity:<br /> ``` json {     \"identity\": {       \"created_at\": \"2021-06-16T01:37:04.262Z\",       \"email\": \"john.smith@gmail.com\", <- - Notice the email before API call       \"external_id\": \"it-236\",       \"extra_attributes\": [         {           \"field\": \"email\",           \"id\": 42035,           \"value\": \"john@smith.com\" <- - Notice the email before API call         }       ],       \"globally_risky\": false,       \"id\": 88484,       \"is_submitter\": true,       \"name\": \"John Smith\",       \"participant\": false,       \"phone_number\": \"555-867-5309\",       \"risky\": false,       \"updated_at\": \"2022-10-12T02:29:49.146Z\"   } } ``` A call to `/identities/extra_attributes/42035/make_primary` would result in the following: ``` json {   \"identity\": {     \"created_at\": \"2021-06-16T01:37:04.262Z\",     \"email\": \"john@smith.com\", <- - Notice the swapped email after API call     \"external_id\": \"it-236\",     \"extra_attributes\": [       {         \"field\": \"email\",         \"id\": 42035,         \"value\": \"john.smith@gmail.com\" <- - Notice the swapped email after API call       }     ],     \"globally_risky\": false,     \"id\": 88484,     \"is_submitter\": true,     \"name\": \"John Smith\",     \"participant\": false,     \"phone_number\": \"555-867-5309\",     \"risky\": false,     \"updated_at\": \"2022-10-12T02:29:49.146Z\"   } } ``` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The extra_attribute ID to make primary |  |

### Return type

[**PutExtraAttributePrimaryResponse**](PutExtraAttributePrimaryResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The identity that owns the promoted extra_attribute |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesextraattributesidput"></a>
# **IdentitiesExtraAttributesIdPut**
> PutExtraAttributeResponse IdentitiesExtraAttributesIdPut (int id, ExtraAttributeBody extraAttributeBody)

Update an identity extra_attribute

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The extra_attribute ID to update |  |
| **extraAttributeBody** | [**ExtraAttributeBody**](ExtraAttributeBody.md) |  |  |

### Return type

[**PutExtraAttributeResponse**](PutExtraAttributeResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The identity that owns the updated extra_attribute |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesget"></a>
# **IdentitiesGet**
> GetIdentitiesResponse IdentitiesGet (string pageToken = null, int max = null, string query = null)

List all identities

**REQUIRED PERMISSION:** `identities:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |
| **query** | **string** | The value of the identities extra_attributes. If this query is passed, the query will search the identities: &#x60;email, name, phone_number&#x60; and &#x60;external_id&#x60; fields for a matching value. If &#x60;query&#x3D;@thetalake.com&#x60;, the result will have all identities with &#x60;@thetalake.com&#x60; value in their &#x60;email, name, phone_number, external_id&#x60;.  | [optional]  |

### Return type

[**GetIdentitiesResponse**](GetIdentitiesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains a paged list of identities |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesiddelete"></a>
# **IdentitiesIdDelete**
> DeleteIdentityByIdResponse IdentitiesIdDelete (int id)

Delete an identity

**REQUIRED PERMISSION:** `identities:delete`   **RATE LIMIT:** `light`   **NOTE:** Identities have many connections including to individual media records and cannot be deleted when they are connected 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to delete |  |

### Return type

[**DeleteIdentityByIdResponse**](DeleteIdentityByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Confirms successful execution of the delete request |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidextraattributespost"></a>
# **IdentitiesIdExtraAttributesPost**
> PostExtraAttributeResponse IdentitiesIdExtraAttributesPost (int id, ExtraAttributeBody extraAttributeBody)

Create a new extra_attribute on an identity

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the identity to add an the extra attribute on |  |
| **extraAttributeBody** | [**ExtraAttributeBody**](ExtraAttributeBody.md) |  |  |

### Return type

[**PostExtraAttributeResponse**](PostExtraAttributeResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The identity with the new extra_attribute |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidget"></a>
# **IdentitiesIdGet**
> GetIdentityByIdResponse IdentitiesIdGet (int id)

Get identity by ID

**REQUIRED PERMISSION:** `identities:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to retrieve |  |

### Return type

[**GetIdentityByIdResponse**](GetIdentityByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved identity |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidput"></a>
# **IdentitiesIdPut**
> PutIdentityByIdResponse IdentitiesIdPut (int id, PutIdentityByIdRequest putIdentityByIdRequest)

Update identity

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to update |  |
| **putIdentityByIdRequest** | [**PutIdentityByIdRequest**](PutIdentityByIdRequest.md) |  |  |

### Return type

[**PutIdentityByIdResponse**](PutIdentityByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated identity |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidriskget"></a>
# **IdentitiesIdRiskGet**
> GetRiskLogResponse IdentitiesIdRiskGet (int id, string pageToken = null, int max = null)

Get identity risk log

**REQUIRED PERMISSION:** `identities:read`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to retrieve the risk log |  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetRiskLogResponse**](GetRiskLogResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The risks currently documented for the identity |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidriskpost"></a>
# **IdentitiesIdRiskPost**
> PostIdentityRiskResponse IdentitiesIdRiskPost (int id, PostIdentityRiskRequest postIdentityRiskRequest = null)

Flag the identity as risky

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to flag as risky |  |
| **postIdentityRiskRequest** | [**PostIdentityRiskRequest**](PostIdentityRiskRequest.md) |  | [optional]  |

### Return type

[**PostIdentityRiskResponse**](PostIdentityRiskResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Status message confirming the user has been marked risky |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesidsupervisionspacesget"></a>
# **IdentitiesIdSupervisionSpacesGet**
> List&lt;IdentitySupervisionSpace&gt; IdentitiesIdSupervisionSpacesGet (int id)

Get supervision spaces for identity (beta)

**REQUIRED PERMISSION:** `supervision_spaces:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The identity ID to retrieve supervision spaces for |  |

### Return type

[**List&lt;IdentitySupervisionSpace&gt;**](IdentitySupervisionSpace.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision spaces the given identity ID is in |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiespost"></a>
# **IdentitiesPost**
> PostIdentityResponse IdentitiesPost (PostIdentityRequest postIdentityRequest)

Create a new identity

**REQUIRED PERMISSION:** `identities:create`   **RATE LIMIT:** `light` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postIdentityRequest** | [**PostIdentityRequest**](PostIdentityRequest.md) |  |  |

### Return type

[**PostIdentityResponse**](PostIdentityResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The new identity |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **409** | The identity already exists |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiesput"></a>
# **IdentitiesPut**
> PutMergeIdentitiesResponse IdentitiesPut (IdentitiesPutRequest identitiesPutRequest)

Merge two identities

**REQUIRED PERMISSION:** `identities:update`   **RATE LIMIT:** `heavy`   **NOTE:** Depending on the number of records associated with the merging identities, this endpoint may run slowly. An `extra_attribute` is added to the target identity to indicate each merged identity. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **identitiesPutRequest** | [**IdentitiesPutRequest**](IdentitiesPutRequest.md) |  |  |

### Return type

[**PutMergeIdentitiesResponse**](PutMergeIdentitiesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The merged identity |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="identitiessearchget"></a>
# **IdentitiesSearchGet**
> GetIdentitiesBySearchResponse IdentitiesSearchGet (string pageToken = null, int max = null, DateTime start = null, DateTime end = null, bool managed = null)

Search Identities

**REQUIRED PERMISSION:** `identities:read`   **RATE LIMIT:** `light`   **NOTE**: If managed is not provided, or set to false, the start and end dates cannot be more than 7 days apart. If start and end   date are not provided, they will default to the last 7 days.   All date searches compare the dates against the `updated_at` field of the identity. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |
| **start** | **DateTime** | **Inclusive** start of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Will default to current date if managed is set to false, or not provided | [optional]  |
| **end** | **DateTime** | **Inclusive** end of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Will default to 7 days from the current date if managed is set to false, or not provided | [optional]  |
| **managed** | **bool** | Denotes if only managed identities should be returned. Identities are managed if they are created by the API, CSV upload, or Active Directory sync | [optional]  |

### Return type

[**GetIdentitiesBySearchResponse**](GetIdentitiesBySearchResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains a paged list of identities |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

