# Org.OpenAPITools.Api.IntegrationsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**IntegrationsGet**](IntegrationsApi.md#integrationsget) | **GET** /integrations | List all integrations |
| [**IntegrationsIdGet**](IntegrationsApi.md#integrationsidget) | **GET** /integrations/{id} | Get integration by ID |
| [**IntegrationsIdInstalledUsersGet**](IntegrationsApi.md#integrationsidinstalledusersget) | **GET** /integrations/{id}/installed_users | Get integration&#39;s installed users |
| [**IntegrationsUserInstallsGet**](IntegrationsApi.md#integrationsuserinstallsget) | **GET** /integrations/user_installs | Get integration&#39;s user install status |

<a id="integrationsget"></a>
# **IntegrationsGet**
> GetIntegrationsResponse IntegrationsGet ()

List all integrations

**REQUIRED PERMISSION:** `integrations:read`   **RATE LIMIT:** `heavy` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetIntegrationsResponse**](GetIntegrationsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | An array of integrations |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="integrationsidget"></a>
# **IntegrationsIdGet**
> GetIntegrationByIdResponse IntegrationsIdGet (int id)

Get integration by ID

**REQUIRED PERMISSION:** `integrations:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to get |  |

### Return type

[**GetIntegrationByIdResponse**](GetIntegrationByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved integration |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="integrationsidinstalledusersget"></a>
# **IntegrationsIdInstalledUsersGet**
> GetIntegrationsInstalledUsersResponse IntegrationsIdInstalledUsersGet (int id, string pageToken = null, int max = null)

Get integration's installed users

**REQUIRED PERMISSION:** `integrations:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the integration to find installed users for |  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetIntegrationsInstalledUsersResponse**](GetIntegrationsInstalledUsersResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The installed users for the integration |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="integrationsuserinstallsget"></a>
# **IntegrationsUserInstallsGet**
> GetIntegrationsInstallResponse IntegrationsUserInstallsGet (string integrationType, string tenantId, string accountUserId = null, string email = null)

Get integration's user install status

**REQUIRED PERMISSION:** `integrations:read`   **RATE LIMIT:** `minimal` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **integrationType** | **string** | The type of integration to search for |  |
| **tenantId** | **string** | The integration&#39;s tenant ID |  |
| **accountUserId** | **string** | The account user ID to lookup | [optional]  |
| **email** | **string** | The email address to lookup | [optional]  |

### Return type

[**GetIntegrationsInstallResponse**](GetIntegrationsInstallResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved integration |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

