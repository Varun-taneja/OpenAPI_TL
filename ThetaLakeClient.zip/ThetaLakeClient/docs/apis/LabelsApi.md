# Org.OpenAPITools.Api.LabelsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**LabelsGet**](LabelsApi.md#labelsget) | **GET** /labels | List all labels |
| [**LabelsIdDelete**](LabelsApi.md#labelsiddelete) | **DELETE** /labels/{id} | Delete label by ID |
| [**LabelsIdGet**](LabelsApi.md#labelsidget) | **GET** /labels/{id} | Get label by ID |
| [**LabelsIdPut**](LabelsApi.md#labelsidput) | **PUT** /labels/{id} | Update label by ID |
| [**LabelsLabelIdRecordsRecordIdDelete**](LabelsApi.md#labelslabelidrecordsrecordiddelete) | **DELETE** /labels/{label_id}/records/{record_id} | Remove a label from a record |
| [**LabelsLabelIdRecordsRecordIdPost**](LabelsApi.md#labelslabelidrecordsrecordidpost) | **POST** /labels/{label_id}/records/{record_id} | Add a label to a record |
| [**LabelsPost**](LabelsApi.md#labelspost) | **POST** /labels | Create a new label |

<a id="labelsget"></a>
# **LabelsGet**
> GetLabelsResponse LabelsGet ()

List all labels

**REQUIRED PERMISSION:** `labels:read`   **RATE LIMIT:** `heavy` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetLabelsResponse**](GetLabelsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of labels |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelsiddelete"></a>
# **LabelsIdDelete**
> GetLabelByIdResponse LabelsIdDelete (int id)

Delete label by ID

**REQUIRED PERMISSION:** `labels:delete`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The label ID to delete |  |

### Return type

[**GetLabelByIdResponse**](GetLabelByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The deleted label |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelsidget"></a>
# **LabelsIdGet**
> GetLabelByIdResponse LabelsIdGet (int id)

Get label by ID

**REQUIRED PERMISSION:** `labels:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The label ID to retrieve |  |

### Return type

[**GetLabelByIdResponse**](GetLabelByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved label |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelsidput"></a>
# **LabelsIdPut**
> PutLabelByIdResponse LabelsIdPut (int id, PutLabelByIdRequest putLabelByIdRequest)

Update label by ID

**REQUIRED PERMISSION:** `labels:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The label ID to update |  |
| **putLabelByIdRequest** | [**PutLabelByIdRequest**](PutLabelByIdRequest.md) |  |  |

### Return type

[**PutLabelByIdResponse**](PutLabelByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated label |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelslabelidrecordsrecordiddelete"></a>
# **LabelsLabelIdRecordsRecordIdDelete**
> DeleteLabelFromRecordResponse LabelsLabelIdRecordsRecordIdDelete (int recordId, int labelId)

Remove a label from a record

**REQUIRED PERMISSION:** `labels:use`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **recordId** | **int** | The record ID to remove the label from |  |
| **labelId** | **int** | The label ID to remove |  |

### Return type

[**DeleteLabelFromRecordResponse**](DeleteLabelFromRecordResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The label was removed from the record |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelslabelidrecordsrecordidpost"></a>
# **LabelsLabelIdRecordsRecordIdPost**
> PostLabelToRecordResponse LabelsLabelIdRecordsRecordIdPost (int labelId, int recordId)

Add a label to a record

**REQUIRED PERMISSION:** `labels:use`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **labelId** | **int** | The label ID to add |  |
| **recordId** | **int** | The record ID to add the label to |  |

### Return type

[**PostLabelToRecordResponse**](PostLabelToRecordResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The label was added to the record |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="labelspost"></a>
# **LabelsPost**
> PostLabelResponse LabelsPost (PostLabelRequest postLabelRequest)

Create a new label

**REQUIRED PERMISSION:** `labels:create`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postLabelRequest** | [**PostLabelRequest**](PostLabelRequest.md) |  |  |

### Return type

[**PostLabelResponse**](PostLabelResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The new label |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

