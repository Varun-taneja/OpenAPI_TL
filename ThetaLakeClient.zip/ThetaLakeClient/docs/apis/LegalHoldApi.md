# Org.OpenAPITools.Api.LegalHoldApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**LegalHoldGet**](LegalHoldApi.md#legalholdget) | **GET** /legal_hold | List all legal holds |
| [**LegalHoldIdRulesGet**](LegalHoldApi.md#legalholdidrulesget) | **GET** /legal_hold/{id}/rules | List all rules on a legal hold |
| [**LegalHoldIdRulesPost**](LegalHoldApi.md#legalholdidrulespost) | **POST** /legal_hold/{id}/rules | Add identity to legal hold rule |
| [**LegalHoldRolesGet**](LegalHoldApi.md#legalholdrolesget) | **GET** /legal_hold/roles | List all legal hold roles |

<a id="legalholdget"></a>
# **LegalHoldGet**
> GetLegalHoldsResponse LegalHoldGet ()

List all legal holds

**REQUIRED PERMISSIONS:** `legal_hold:read`   **RATE LIMIT:** `medium` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetLegalHoldsResponse**](GetLegalHoldsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A list of legal holds |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="legalholdidrulesget"></a>
# **LegalHoldIdRulesGet**
> GetLegalHoldIdentitiesResponse LegalHoldIdRulesGet (int id, int max = null, string pageToken = null)

List all rules on a legal hold

**REQUIRED PERMISSIONS:** `legal_hold:read`   **RATE LIMIT:** `medium` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the legal hold |  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; object in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |

### Return type

[**GetLegalHoldIdentitiesResponse**](GetLegalHoldIdentitiesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A list of legal hold rules |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="legalholdidrulespost"></a>
# **LegalHoldIdRulesPost**
> AddLegalHoldIdentityResponse LegalHoldIdRulesPost (int id, LegalHoldRequestBody legalHoldRequestBody)

Add identity to legal hold rule

**REQUIRED PERMISSIONS:** `legal_hold:update`   **RATE LIMIT:** `medium` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the legal hold |  |
| **legalHoldRequestBody** | [**LegalHoldRequestBody**](LegalHoldRequestBody.md) |  |  |

### Return type

[**AddLegalHoldIdentityResponse**](AddLegalHoldIdentityResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The added legal hold rule |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="legalholdrolesget"></a>
# **LegalHoldRolesGet**
> GetLegalHoldRolesResponse LegalHoldRolesGet ()

List all legal hold roles

**REQUIRED PERMISSIONS:** `legal_hold:read`   **RATE LIMIT:** `medium` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetLegalHoldRolesResponse**](GetLegalHoldRolesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A list of legal hold roles |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

