# Org.OpenAPITools.Api.OrgUnitsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**OrgUnitsCurrentGet**](OrgUnitsApi.md#orgunitscurrentget) | **GET** /org_units/current | Get current org unit |
| [**OrgUnitsGet**](OrgUnitsApi.md#orgunitsget) | **GET** /org_units | List all org units |
| [**OrgUnitsIdGet**](OrgUnitsApi.md#orgunitsidget) | **GET** /org_units/{id} | Get org unit by ID |
| [**OrgUnitsIdPut**](OrgUnitsApi.md#orgunitsidput) | **PUT** /org_units/{id} | Update org unit |
| [**OrgUnitsIdSwitchPut**](OrgUnitsApi.md#orgunitsidswitchput) | **PUT** /org_units/{id}/switch | Switch the current org unit |

<a id="orgunitscurrentget"></a>
# **OrgUnitsCurrentGet**
> CurrentOrgUnit OrgUnitsCurrentGet ()

Get current org unit

**REQUIRED PERMISSION:** `org_units:read`   **RATE LIMIT:** `heavy` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**CurrentOrgUnit**](CurrentOrgUnit.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns the current org unit the user is apart of |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="orgunitsget"></a>
# **OrgUnitsGet**
> AllOrgUnitsResponse OrgUnitsGet ()

List all org units

**REQUIRED PERMISSION:** `org_units:read`   **RATE LIMIT:** `heavy` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**AllOrgUnitsResponse**](AllOrgUnitsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of org units |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="orgunitsidget"></a>
# **OrgUnitsIdGet**
> GetOrgUnitByIdResponse OrgUnitsIdGet (int id)

Get org unit by ID

**REQUIRED PERMISSION:** `org_units:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The org unit ID to retrieve |  |

### Return type

[**GetOrgUnitByIdResponse**](GetOrgUnitByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved org unit |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="orgunitsidput"></a>
# **OrgUnitsIdPut**
> GetOrgUnitByIdResponse OrgUnitsIdPut (int id, PutOrgUnitByIdRequest putOrgUnitByIdRequest)

Update org unit

**REQUIRED PERMISSION:** `org_units:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The org unit ID to update |  |
| **putOrgUnitByIdRequest** | [**PutOrgUnitByIdRequest**](PutOrgUnitByIdRequest.md) |  |  |

### Return type

[**GetOrgUnitByIdResponse**](GetOrgUnitByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved org unit |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="orgunitsidswitchput"></a>
# **OrgUnitsIdSwitchPut**
> InlineObject12 OrgUnitsIdSwitchPut (int id)

Switch the current org unit

**REQUIRED PERMISSION:** `none`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The org unit ID to switch to |  |

### Return type

[**InlineObject12**](InlineObject12.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns the status of the operation |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | Returned if the user is not apart of the org that is being switched to |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

