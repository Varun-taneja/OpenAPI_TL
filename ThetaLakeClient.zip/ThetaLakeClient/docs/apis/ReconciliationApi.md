# Org.OpenAPITools.Api.ReconciliationApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**ReconciliationCountPost**](ReconciliationApi.md#reconciliationcountpost) | **POST** /reconciliation/count | Get record count by platform |
| [**ReconciliationNewPost**](ReconciliationApi.md#reconciliationnewpost) | **POST** /reconciliation/new | Reconcile records (new) |

<a id="reconciliationcountpost"></a>
# **ReconciliationCountPost**
> GetReconciliationCount ReconciliationCountPost (CountRequest countRequest)

Get record count by platform

**REQUIRED PERMISSION:** `reconciliation:read`   **RATE LIMIT:** `medium`   **NOTE:** The [documentation](/documentation/reconciliation) covers the supported platforms and attributes that can be queried. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **countRequest** | [**CountRequest**](CountRequest.md) |  |  |

### Return type

[**GetReconciliationCount**](GetReconciliationCount.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a count of matching records |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="reconciliationnewpost"></a>
# **ReconciliationNewPost**
> GetReconciliationResultsV2 ReconciliationNewPost (RequestBodyV2 requestBodyV2)

Reconcile records (new)

**REQUIRED PERMISSION:** `reconciliation:read`   **RATE LIMIT:** `medium`   **NOTE:** The [documentation](/documentation/reconciliation) covers the supported platforms and attributes that can be reconciled against.   The date range field is defaulted to the last 7 days if not specified. The range is inclusive and can span a maximum of 7 days. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **requestBodyV2** | [**RequestBodyV2**](RequestBodyV2.md) |  |  |

### Return type

[**GetReconciliationResultsV2**](GetReconciliationResultsV2.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of matching records |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

