# Org.OpenAPITools.Api.RecordsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**RecordsIdShareableLinkGet**](RecordsApi.md#recordsidshareablelinkget) | **GET** /records/{id}/shareable_link | Get record shareable link by ID |
| [**RecordsUuidShareableLinkGet**](RecordsApi.md#recordsuuidshareablelinkget) | **GET** /records/{uuid}/shareable_link | Get record shareable link by UUID |

<a id="recordsidshareablelinkget"></a>
# **RecordsIdShareableLinkGet**
> GetShareableLinkResponse RecordsIdShareableLinkGet (int id)

Get record shareable link by ID

**REQUIRED PERMISSION:** `records:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the record to get a shareable link for |  |

### Return type

[**GetShareableLinkResponse**](GetShareableLinkResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains the shareable link for the record |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="recordsuuidshareablelinkget"></a>
# **RecordsUuidShareableLinkGet**
> GetShareableLinkResponse RecordsUuidShareableLinkGet (string uuid)

Get record shareable link by UUID

**REQUIRED PERMISSION:** `records:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **uuid** | **string** | The UUID of the record to get a shareable link for |  |

### Return type

[**GetShareableLinkResponse**](GetShareableLinkResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response contains the shareable link for the record |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

