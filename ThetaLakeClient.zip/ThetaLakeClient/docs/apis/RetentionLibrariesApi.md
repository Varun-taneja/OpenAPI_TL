# Org.OpenAPITools.Api.RetentionLibrariesApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**RetentionLibrariesGet**](RetentionLibrariesApi.md#retentionlibrariesget) | **GET** /retention_libraries | List all retention libraries |
| [**RetentionLibrariesIdDelete**](RetentionLibrariesApi.md#retentionlibrariesiddelete) | **DELETE** /retention_libraries/{id} | Delete an retention library |
| [**RetentionLibrariesIdGet**](RetentionLibrariesApi.md#retentionlibrariesidget) | **GET** /retention_libraries/{id} | Get retention library by ID |
| [**RetentionLibrariesIdPut**](RetentionLibrariesApi.md#retentionlibrariesidput) | **PUT** /retention_libraries/{id} | Update retention library |
| [**RetentionLibrariesPost**](RetentionLibrariesApi.md#retentionlibrariespost) | **POST** /retention_libraries | Create a new retention library |

<a id="retentionlibrariesget"></a>
# **RetentionLibrariesGet**
> GetRetentionLibraryResponse RetentionLibrariesGet ()

List all retention libraries

**REQUIRED PERMISSION:** `retention_libraries:read`   **RATE LIMIT:** `heavy`   **NOTE:** Get a list of all the organizations retention libraries 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetRetentionLibraryResponse**](GetRetentionLibraryResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of retention libraries |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="retentionlibrariesiddelete"></a>
# **RetentionLibrariesIdDelete**
> DeleteRetentionLibraryResponse RetentionLibrariesIdDelete (int id)

Delete an retention library

**REQUIRED PERMISSION:** `retention_libraries:delete`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the retention library to delete |  |

### Return type

[**DeleteRetentionLibraryResponse**](DeleteRetentionLibraryResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Status message of the delete operation |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="retentionlibrariesidget"></a>
# **RetentionLibrariesIdGet**
> GetRetentionLibraryByIdResponse RetentionLibrariesIdGet (int id)

Get retention library by ID

**REQUIRED PERMISSION:** `retention_libraries:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the retention library to retrieve |  |

### Return type

[**GetRetentionLibraryByIdResponse**](GetRetentionLibraryByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved retention library |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="retentionlibrariesidput"></a>
# **RetentionLibrariesIdPut**
> PutRetentionLibraryResponse RetentionLibrariesIdPut (int id, PutRetentionLibraryRequest putRetentionLibraryRequest)

Update retention library

**REQUIRED PERMISSION:** `retention_libraries:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the retention library to update |  |
| **putRetentionLibraryRequest** | [**PutRetentionLibraryRequest**](PutRetentionLibraryRequest.md) |  |  |

### Return type

[**PutRetentionLibraryResponse**](PutRetentionLibraryResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated retention library |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="retentionlibrariespost"></a>
# **RetentionLibrariesPost**
> PostRetentionLibraryResponse RetentionLibrariesPost (PostRetentionLibraryRequest postRetentionLibraryRequest)

Create a new retention library

**REQUIRED PERMISSION:** `retention_libraries:create`   **RATE LIMIT:** `heavy`   **NOTE:** Creates retention libraries and sets initial retention policies 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postRetentionLibraryRequest** | [**PostRetentionLibraryRequest**](PostRetentionLibraryRequest.md) |  |  |

### Return type

[**PostRetentionLibraryResponse**](PostRetentionLibraryResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Retention library successfully created, returns the new retention library |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

