# Org.OpenAPITools.Api.SearchApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**SearchRecordsPost**](SearchApi.md#searchrecordspost) | **POST** /search/records | Search records |
| [**SearchSavedGet**](SearchApi.md#searchsavedget) | **GET** /search/saved | List all saved searches |
| [**SearchSavedIdGet**](SearchApi.md#searchsavedidget) | **GET** /search/saved/{id} | Run search by ID |
| [**SearchSavedIdResetAndReenterPost**](SearchApi.md#searchsavedidresetandreenterpost) | **POST** /search/saved/{id}/reset_and_reenter | Reset and reenter records to workflow |

<a id="searchrecordspost"></a>
# **SearchRecordsPost**
> PostSearchResponseNew SearchRecordsPost (PostSearchBody postSearchBody, string pageToken = null, int max = null)

Search records

**REQUIRED PERMISSION:** `search:create`   **RATE LIMIT:** `heavy`   **NOTE:** This page supports pagination but does not support previous pages   For more detailed examples see [the search api guide](/documentation/search).   Limited to a max of 10,000 records 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postSearchBody** | [**PostSearchBody**](PostSearchBody.md) |  |  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25, must not be more than 100 | [optional]  |

### Return type

[**PostSearchResponseNew**](PostSearchResponseNew.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of records matching the searches |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="searchsavedget"></a>
# **SearchSavedGet**
> GetSearchResponse SearchSavedGet (List<string> types, string pageToken = null, int max = null)

List all saved searches

**REQUIRED PERMISSION:** `search:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **types** | [**List&lt;string&gt;**](string.md) | The type of search to retrieve |  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetSearchResponse**](GetSearchResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of saved searches |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="searchsavedidget"></a>
# **SearchSavedIdGet**
> PostSearchResponse SearchSavedIdGet (int id, string pageToken = null, int max = null)

Run search by ID

**REQUIRED PERMISSION:** `search:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the search to run |  |
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25, must not be more than 100 | [optional]  |

### Return type

[**PostSearchResponse**](PostSearchResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Returns a list of records matching the saved search |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="searchsavedidresetandreenterpost"></a>
# **SearchSavedIdResetAndReenterPost**
> PostResetResponse SearchSavedIdResetAndReenterPost (int id, PostResetRequest postResetRequest)

Reset and reenter records to workflow

**REQUIRED PERMISSION:** `search:reset`   **RATE LIMIT:** `heavy`   **NOTE:** This endpoint creates a batch job to process the reset & reenter request. Run the search again to see progress.   This endpoint supports resetting up to 20,000 records in a single request. If the number of records exceeds 20,000, change   the search criteria to reduce the number of records. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the search to run to find datums to reset |  |
| **postResetRequest** | [**PostResetRequest**](PostResetRequest.md) |  |  |

### Return type

[**PostResetResponse**](PostResetResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **202** | Batch job accepted |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

