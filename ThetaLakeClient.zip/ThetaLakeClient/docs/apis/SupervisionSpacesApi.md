# Org.OpenAPITools.Api.SupervisionSpacesApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**SupervisionSpacesGet**](SupervisionSpacesApi.md#supervisionspacesget) | **GET** /supervision_spaces | List all supervision spaces |
| [**SupervisionSpacesIdDelete**](SupervisionSpacesApi.md#supervisionspacesiddelete) | **DELETE** /supervision_spaces/{id} | Delete supervision space |
| [**SupervisionSpacesIdDirectoryGroupsDelete**](SupervisionSpacesApi.md#supervisionspacesiddirectorygroupsdelete) | **DELETE** /supervision_spaces/{id}/directory_groups | Remove directory groups from supervision space |
| [**SupervisionSpacesIdDirectoryGroupsPost**](SupervisionSpacesApi.md#supervisionspacesiddirectorygroupspost) | **POST** /supervision_spaces/{id}/directory_groups | Add directory groups to supervision space |
| [**SupervisionSpacesIdGet**](SupervisionSpacesApi.md#supervisionspacesidget) | **GET** /supervision_spaces/{id} | Get supervision space by ID |
| [**SupervisionSpacesIdIdentitiesPost**](SupervisionSpacesApi.md#supervisionspacesididentitiespost) | **POST** /supervision_spaces/{id}/identities | Add identities to supervision space |
| [**SupervisionSpacesIdParticipantsDelete**](SupervisionSpacesApi.md#supervisionspacesidparticipantsdelete) | **DELETE** /supervision_spaces/{id}/participants | Remove participants from supervision space |
| [**SupervisionSpacesIdParticipantsPost**](SupervisionSpacesApi.md#supervisionspacesidparticipantspost) | **POST** /supervision_spaces/{id}/participants | Add participants to supervision space |
| [**SupervisionSpacesIdPut**](SupervisionSpacesApi.md#supervisionspacesidput) | **PUT** /supervision_spaces/{id} | Update supervision space |
| [**SupervisionSpacesIdUserGroupsDelete**](SupervisionSpacesApi.md#supervisionspacesidusergroupsdelete) | **DELETE** /supervision_spaces/{id}/user_groups | Remove user groups from supervision space |
| [**SupervisionSpacesIdUserGroupsPost**](SupervisionSpacesApi.md#supervisionspacesidusergroupspost) | **POST** /supervision_spaces/{id}/user_groups | Add user groups to supervision space |
| [**SupervisionSpacesIdUsersDelete**](SupervisionSpacesApi.md#supervisionspacesidusersdelete) | **DELETE** /supervision_spaces/{id}/users | Remove users from supervision space |
| [**SupervisionSpacesIdUsersPost**](SupervisionSpacesApi.md#supervisionspacesiduserspost) | **POST** /supervision_spaces/{id}/users | Add users to supervision space |
| [**SupervisionSpacesPost**](SupervisionSpacesApi.md#supervisionspacespost) | **POST** /supervision_spaces | Create a new supervision space |

<a id="supervisionspacesget"></a>
# **SupervisionSpacesGet**
> GetSupervisionSpacesResponseNew SupervisionSpacesGet (string pageToken = null, int max = null)

List all supervision spaces

**REQUIRED PERMISSION:** `supervision_spaces:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **pageToken** | **string** | The page token to query next, this comes from the &#x60;paging&#x60; in the response. This can be either &#x60;next_page_token&#x60; or &#x60;prev_page_token&#x60; | [optional]  |
| **max** | **int** | The max number of items in each page; default is 25 | [optional]  |

### Return type

[**GetSupervisionSpacesResponseNew**](GetSupervisionSpacesResponseNew.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A paged list of supervision spaces |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesiddelete"></a>
# **SupervisionSpacesIdDelete**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdDelete (int id)

Delete supervision space

**REQUIRED PERMISSION:** `supervision_spaces:delete`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the supervision space to delete |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The deleted supervision space |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesiddirectorygroupsdelete"></a>
# **SupervisionSpacesIdDirectoryGroupsDelete**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdDirectoryGroupsDelete (int id, List<int> requestBody)

Remove directory groups from supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space without the removed directory groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesiddirectorygroupspost"></a>
# **SupervisionSpacesIdDirectoryGroupsPost**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdDirectoryGroupsPost (int id, List<int> requestBody)

Add directory groups to supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space with the added directory groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidget"></a>
# **SupervisionSpacesIdGet**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdGet (int id)

Get supervision space by ID

**REQUIRED PERMISSION:** `supervision_spaces:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the supervision space to retrieve |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The retrieved supervision space |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesididentitiespost"></a>
# **SupervisionSpacesIdIdentitiesPost**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdIdentitiesPost (int id, List<int> requestBody)

Add identities to supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space with the added identities |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidparticipantsdelete"></a>
# **SupervisionSpacesIdParticipantsDelete**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdParticipantsDelete (int id, SupervisionSpacesIdParticipantsDeleteRequest supervisionSpacesIdParticipantsDeleteRequest)

Remove participants from supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **supervisionSpacesIdParticipantsDeleteRequest** | [**SupervisionSpacesIdParticipantsDeleteRequest**](SupervisionSpacesIdParticipantsDeleteRequest.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space without the removed participants |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidparticipantspost"></a>
# **SupervisionSpacesIdParticipantsPost**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdParticipantsPost (int id, SupervisionSpacesIdParticipantsPostRequest supervisionSpacesIdParticipantsPostRequest)

Add participants to supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy`   **NOTE:** This route can be used to add participants to supervision spaces. The `participants_text` is a semi-CSV style list of name, email, or phone number separated by newlines. ``` {   \"participants_text\": \"johnsmith@example.com\\nBob Jones, bob@example.com\\nJames K Anderson, james@example.com, 123-333-4567\\n\" } ``` As shown in the example, the syntax is semi-CSV because any of the fields can be omitted. Internally the fields are parsed and used to search through known identities. If a match is found, the identity is added to the supervision space. If a match is not found, a new identity is created and added to the supervision space. 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **supervisionSpacesIdParticipantsPostRequest** | [**SupervisionSpacesIdParticipantsPostRequest**](SupervisionSpacesIdParticipantsPostRequest.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space with the added directory groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidput"></a>
# **SupervisionSpacesIdPut**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdPut (int id, PostPutSupervisionSpacesRequest postPutSupervisionSpacesRequest)

Update supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy`   **NOTE:** One input field is `media_type_ids` for the supervision space to handle. The input for this field is an array of integers for the media types. Use the following table to lookup the IDs for each media type. | Type       | ID | |- -- -- -- -- -- -|- -- -| | Video      | 1  | | Audio      | 2  | | Chat       | 3  | | Attachment | 4  | | Email      | 5  | 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the supervision space to update |  |
| **postPutSupervisionSpacesRequest** | [**PostPutSupervisionSpacesRequest**](PostPutSupervisionSpacesRequest.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The updated supervision space |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidusergroupsdelete"></a>
# **SupervisionSpacesIdUserGroupsDelete**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdUserGroupsDelete (int id, List<int> requestBody)

Remove user groups from supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space without the removed user groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidusergroupspost"></a>
# **SupervisionSpacesIdUserGroupsPost**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdUserGroupsPost (int id, List<int> requestBody)

Add user groups to supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space with the added user groups |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesidusersdelete"></a>
# **SupervisionSpacesIdUsersDelete**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdUsersDelete (int id, List<int> requestBody)

Remove users from supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space without the removed users |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacesiduserspost"></a>
# **SupervisionSpacesIdUsersPost**
> GetSupervisionSpaceByIdResponse SupervisionSpacesIdUsersPost (int id, List<int> requestBody)

Add users to supervision space

**REQUIRED PERMISSION:** `supervision_spaces:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The supervision space ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**GetSupervisionSpaceByIdResponse**](GetSupervisionSpaceByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The supervision space with the added users |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **404** | The specified resource was not found |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="supervisionspacespost"></a>
# **SupervisionSpacesPost**
> PostSupervisionSpacesResponse SupervisionSpacesPost (PostPutSupervisionSpacesRequest postPutSupervisionSpacesRequest)

Create a new supervision space

**REQUIRED PERMISSION:** `supervision_spaces:create`   **RATE LIMIT:** `heavy`   **NOTE:** One input field is `media_type_ids` for the supervision space to handle. The input for this field is an array of integers for the media types. Use the following table to lookup the IDs for each media type. | Type       | ID | |- -- -- -- -- -- -|- -- -| | Video      | 1  | | Audio      | 2  | | Chat       | 3  | | Attachment | 4  | | Email      | 5  | 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postPutSupervisionSpacesRequest** | [**PostPutSupervisionSpacesRequest**](PostPutSupervisionSpacesRequest.md) |  |  |

### Return type

[**PostSupervisionSpacesResponse**](PostSupervisionSpacesResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The new supervision space |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

