# Org.OpenAPITools.Api.UserGroupsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**UserGroupsGet**](UserGroupsApi.md#usergroupsget) | **GET** /user_groups | List all user groups |
| [**UserGroupsIdAddUsersPut**](UserGroupsApi.md#usergroupsidaddusersput) | **PUT** /user_groups/{id}/add_users | Add users to group |
| [**UserGroupsIdDelete**](UserGroupsApi.md#usergroupsiddelete) | **DELETE** /user_groups/{id} | Delete user group |
| [**UserGroupsIdGet**](UserGroupsApi.md#usergroupsidget) | **GET** /user_groups/{id} | Get user group by ID |
| [**UserGroupsIdPut**](UserGroupsApi.md#usergroupsidput) | **PUT** /user_groups/{id} | Update user group |
| [**UserGroupsIdRemoveUsersPut**](UserGroupsApi.md#usergroupsidremoveusersput) | **PUT** /user_groups/{id}/remove_users | Remove users from group |
| [**UserGroupsPost**](UserGroupsApi.md#usergroupspost) | **POST** /user_groups | Create new user group |

<a id="usergroupsget"></a>
# **UserGroupsGet**
> GetUserGroupsResponse UserGroupsGet ()

List all user groups

**REQUIRED PERMISSION:** `user_groups:read`   **RATE LIMIT:** `heavy` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**GetUserGroupsResponse**](GetUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of user groups |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupsidaddusersput"></a>
# **UserGroupsIdAddUsersPut**
> PutUserGroupsResponse UserGroupsIdAddUsersPut (int id, List<int> requestBody)

Add users to group

**REQUIRED PERMISSION:** `user_groups:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The user group ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**PutUserGroupsResponse**](PutUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response result |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupsiddelete"></a>
# **UserGroupsIdDelete**
> DeleteUserGroupsResponse UserGroupsIdDelete (int id)

Delete user group

**REQUIRED PERMISSION:** `user_groups:delete`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The user group ID |  |

### Return type

[**DeleteUserGroupsResponse**](DeleteUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response result |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupsidget"></a>
# **UserGroupsIdGet**
> GetUserGroupsIdResponse UserGroupsIdGet (int id)

Get user group by ID

**REQUIRED PERMISSION:** `user_groups:read`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The user group ID |  |

### Return type

[**GetUserGroupsIdResponse**](GetUserGroupsIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The list of user groups |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupsidput"></a>
# **UserGroupsIdPut**
> PostUserGroupsResponse UserGroupsIdPut (int id, PostPutUserGroupsRequest postPutUserGroupsRequest)

Update user group

**REQUIRED PERMISSION:** `user_groups:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The user group ID |  |
| **postPutUserGroupsRequest** | [**PostPutUserGroupsRequest**](PostPutUserGroupsRequest.md) |  |  |

### Return type

[**PostUserGroupsResponse**](PostUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The new user group |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupsidremoveusersput"></a>
# **UserGroupsIdRemoveUsersPut**
> PutUserGroupsResponse UserGroupsIdRemoveUsersPut (int id, List<int> requestBody)

Remove users from group

**REQUIRED PERMISSION:** `user_groups:update`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The user group ID |  |
| **requestBody** | [**List&lt;int&gt;**](int.md) |  |  |

### Return type

[**PutUserGroupsResponse**](PutUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The response result |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="usergroupspost"></a>
# **UserGroupsPost**
> PostUserGroupsResponse UserGroupsPost (PostPutUserGroupsRequest postPutUserGroupsRequest)

Create new user group

**REQUIRED PERMISSION:** `user_groups:create`   **RATE LIMIT:** `heavy` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **postPutUserGroupsRequest** | [**PostPutUserGroupsRequest**](PostPutUserGroupsRequest.md) |  |  |

### Return type

[**PostUserGroupsResponse**](PostUserGroupsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | The new user group |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

