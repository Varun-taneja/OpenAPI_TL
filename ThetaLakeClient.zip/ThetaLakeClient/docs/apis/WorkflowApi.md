# Org.OpenAPITools.Api.WorkflowApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**WorkflowsGet**](WorkflowApi.md#workflowsget) | **GET** /workflows | List all workflows |
| [**WorkflowsIdGet**](WorkflowApi.md#workflowsidget) | **GET** /workflows/{id} | Get workflow by id |

<a id="workflowsget"></a>
# **WorkflowsGet**
> ListAllWorkflowsResponse WorkflowsGet ()

List all workflows

**REQUIRED PERMISSIONS:** `workflows:read`   **RATE LIMIT:** `medium` 


### Parameters
This endpoint does not need any parameter.
### Return type

[**ListAllWorkflowsResponse**](ListAllWorkflowsResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A list of workflows |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

<a id="workflowsidget"></a>
# **WorkflowsIdGet**
> ListWorkflowByIdResponse WorkflowsIdGet (int id)

Get workflow by id

**REQUIRED PERMISSIONS:** `workflows:read`   **RATE LIMIT:** `medium` 


### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **id** | **int** | The ID of the workflow |  |

### Return type

[**ListWorkflowByIdResponse**](ListWorkflowByIdResponse.md)

### Authorization

[ClientCredentials](../README.md#ClientCredentials), [BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The workflow details |  -  |
| **400** | This error is a result of missing or malformed required part of the request body or query. |  -  |
| **401** | Access denied. This is due to missing or malformed JWT. |  -  |
| **403** | This error indicates that access has been denied to the requested resource. This is due to incorrect scopes on the API key. |  -  |
| **429** | This error indicates that your organizations rate limit has been met. |  -  |
| **500** | In the event of an internal server error, the response will ask the user to submit a support ticket with the request ID. |  -  |
| **503** | This error is returned when the internal Theta Lake service is unavailable. |  -  |

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

