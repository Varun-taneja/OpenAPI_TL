# Org.OpenAPITools.Model.AnalysisSupervisionSpacesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | The supervision space ID | [optional] 
**Name** | **string** | The supervision space name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

