# Org.OpenAPITools.Model.Case

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloseDate** | **DateTime** | The timestamp of when the case was closed. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | The case description | [optional] 
**Id** | **int** | The case ID | [optional] 
**Name** | **string** | The case name | [optional] 
**Number** | **string** | The case number | [optional] 
**OpenDate** | **DateTime** | The timestamp of when the case was opened. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**RecordsCount** | **int** | The number of records associated with the case | [optional] 
**Status** | **string** | The current case status | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Visibility** | **string** | The case visibility | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

