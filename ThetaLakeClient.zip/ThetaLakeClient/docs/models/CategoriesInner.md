# Org.OpenAPITools.Model.CategoriesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryGroupId** | **int** | The category&#39;s group ID | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Deprecated** | **bool** | Indicates if the category has been deprecated | [optional] 
**Description** | **string** | Describes the category | [optional] 
**DetectionMediaTypes** | [**List&lt;CategoriesInnerDetectionMediaTypesInner&gt;**](CategoriesInnerDetectionMediaTypesInner.md) | An array of the detection media types in this category | [optional] 
**DetectionType** | **string** | Detection type permitted in this category | [optional] 
**DisabledAt** | **DateTime** | Timestamp of when the category was disabled. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Disclaimer** | **bool** | Indicates that this category is detecting for the presence of a disclaimer | [optional] 
**FromDate** | **DateTime** | Only datums after this date are permitted in this category. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Hidden** | **bool** | Indicates if the category is hidden on the UI | [optional] 
**Id** | **int** | The category&#39;s ID | [optional] 
**Identifier** | **string** | Unique text identifier for the category | [optional] 
**Keywords** | **bool** | Indicates that this category is a customer classifier that uses keywords | [optional] 
**Name** | **string** | The category&#39;s name | [optional] 
**RiskType** | **string** | Defines how a detection impacts the risk of datums | [optional] 
**Status** | **string** | The category&#39;s status | [optional] 
**StatusColor** | **string** | A color representing the category&#39;s status | [optional] 
**Terms** | **string** | A new line (&#x60;\\n&#x60;) separated list of terms used for detections | [optional] 
**ToDate** | **DateTime** | Only datums up to this date are permitted in this category. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

