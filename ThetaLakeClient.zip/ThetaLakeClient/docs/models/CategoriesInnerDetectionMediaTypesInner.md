# Org.OpenAPITools.Model.CategoriesInnerDetectionMediaTypesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | The detection media type ID | [optional] 
**Name** | **string** | The detection media type name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

