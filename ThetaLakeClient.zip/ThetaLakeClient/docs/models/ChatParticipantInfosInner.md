# Org.OpenAPITools.Model.ChatParticipantInfosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The unique identifier from the original platform where the content was generated | [optional] 
**Name** | **string** | The participant&#39;s name as a single string | [optional] 
**FirstName** | **string** | The participant&#39;s first name | [optional] 
**LastName** | **string** | The participant&#39;s last name | [optional] 
**Email** | **string** | The participant&#39;s email address | [optional] 
**PhoneNumber** | **string** | The participant&#39;s phone number. This phone number can only be digits with an optional &#39;+&#39; prefix | [optional] 
**Extension** | **string** | The participant&#39;s extension | [optional] 
**Location** | **string** | The participant&#39;s location | [optional] 
**DeviceId** | **string** | The participant&#39;s device ID | [optional] 
**EmployeeId** | **string** | The participant&#39;s employee ID | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

