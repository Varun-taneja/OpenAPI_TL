# Org.OpenAPITools.Model.ChatParticipants
Participants that have sent messages in this chat should be in the **activemember** array.   Participants that have not sent messages in this chat should be in the **passivemember** array. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Activemember** | [**List&lt;ChatParticipantInfosInner&gt;**](ChatParticipantInfosInner.md) |  | [optional] 
**Passivemember** | [**List&lt;ChatParticipantInfosInner&gt;**](ChatParticipantInfosInner.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

