# Org.OpenAPITools.Model.CountResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Platform** | **string** | Third party platform to search. Supported platforms are documented [here](/documentation/reconciliation) | [optional] 
**Start** | **DateTime** | **Inclusive** start of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**End** | **DateTime** | **Inclusive** end of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6), defaults to Now() | [optional] 
**Type** | **string** | The type date range, default is *create_date* | [optional] 
**Count** | **decimal** | The matching number of records for the platform and date range | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

