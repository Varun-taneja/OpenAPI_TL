# Org.OpenAPITools.Model.DateRange
Specifies the date range for the reconciliation window. **The maximum allowed range is 7 days**. If no range is provided, the system defaults to the last 7 days from the current date, based on the upload_date. All dates are inclusive

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** | The range type, default is *upload_date* | [optional] 
**Start** | **DateTime** | **Inclusive** start of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Defaults to 7 days from the current date if not specified | [optional] 
**End** | **DateTime** | **Inclusive** end of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Defaults to current date if not specified | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

