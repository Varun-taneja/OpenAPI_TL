# Org.OpenAPITools.Model.DeleteUserResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatusCode** | **int** | HTTP response status code | [optional] 
**StatusString** | **string** | Text description of the HTTP response status code | [optional] 
**RequestId** | **string** | Unique identifier (UUID) for the request | [optional] 
**Status** | **string** | Status message in response to the disable user action | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

