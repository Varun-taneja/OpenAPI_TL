# Org.OpenAPITools.Model.DetailedSupervisionSpace

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllParticipants** | **bool** | Indicates if the supervision space contains all the participants in the org | [optional] 
**AllUsers** | **bool** | Indicates if the supervision space contains all the users in the org | [optional] 
**CanDelete** | **bool** | Indicates if the supervision space can be deleted | [optional] 
**CanEnableAllParticipants** | **bool** | Indicates if the supervision space can add all participants. Only one supervision space can have all participants enabled. | [optional] 
**CompiledParticipantList** | [**List&lt;SupervisionSpacesSchemasParticipant&gt;**](SupervisionSpacesSchemasParticipant.md) | All identities associated with the supervision space, including identities from directory groups | [optional] 
**CompiledUserList** | [**List&lt;User&gt;**](User.md) | All users associated with the supervision space, including user groups | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | The description of the supervision space given when created | [optional] 
**DirectoryGroups** | [**List&lt;DetailedSupervisionSpaceDirectoryGroupsInner&gt;**](DetailedSupervisionSpaceDirectoryGroupsInner.md) | The directory groups associated with this supervision space | [optional] 
**Disabled** | **bool** | Indicates if supervision space is turned on or off | [optional] 
**EntryStrategiesCount** | **int** | The count of SWRV rules that include this supervision space | [optional] 
**ExternalId** | **string** | An external ID for the supervision space | [optional] 
**HardEnforce** | **bool** | Indicates if users can be assigned records from other supervision spaces | [optional] 
**Id** | **int** | The supervision space ID | [optional] 
**Integrations** | [**List&lt;IntegrationsInner&gt;**](IntegrationsInner.md) | An array of integrations associated with this supervision space | [optional] 
**MediaTypes** | [**List&lt;MediaTypesInner&gt;**](MediaTypesInner.md) | An array of media types included in this supervision space | [optional] 
**Name** | **string** | The supervision space name | [optional] 
**ParticipantCount** | **int** | The number of participants in the supervision space | [optional] 
**Participants** | [**List&lt;SupervisionSpacesSchemasParticipant&gt;**](SupervisionSpacesSchemasParticipant.md) | The identities directly associated with the supervision space not including identities from directory groups | [optional] 
**RetentionLibraries** | [**List&lt;RetentionLibrariesInner&gt;**](RetentionLibrariesInner.md) | An array of retention libraries associated with this supervision space | [optional] 
**ReviewerCount** | **int** | The number of reviewers assigned to the supervision space | [optional] 
**SupervisionSpacePriority** | **int** | The priority of assigning records to a supervision space | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UserGroups** | [**List&lt;DetailedSupervisionSpaceUserGroupsInner&gt;**](DetailedSupervisionSpaceUserGroupsInner.md) | The user groups associated with this supervision space | [optional] 
**Users** | [**List&lt;User&gt;**](User.md) | All users associated with the supervision space, not including user groups | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

