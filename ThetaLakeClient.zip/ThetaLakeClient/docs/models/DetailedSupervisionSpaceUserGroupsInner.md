# Org.OpenAPITools.Model.DetailedSupervisionSpaceUserGroupsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | The user group description | [optional] 
**ExternalId** | **string** | An external identifier for the user group | [optional] 
**Id** | **int** | The user group ID | [optional] 
**Name** | **string** | The user group name | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UserCount** | **int** | The number of users in the group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

