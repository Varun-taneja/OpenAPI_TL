# Org.OpenAPITools.Model.DirectoryGroupIdentity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Email** | **string** | The identity&#39;s email address | [optional] 
**ExternalId** | **string** | An external ID for the identity | [optional] 
**Id** | **int** | The identity ID | [optional] 
**Name** | **string** | The identity&#39;s name | [optional] 
**PhoneNumber** | **string** | The identity&#39;s phone number | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

