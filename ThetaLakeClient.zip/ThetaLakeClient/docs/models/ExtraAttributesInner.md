# Org.OpenAPITools.Model.ExtraAttributesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EndDate** | **DateTime** | End date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Field** | **string** | Extra attribute field name | [optional] 
**Id** | **int** | Extra attribute field identifier | [optional] 
**StartDate** | **DateTime** | Start date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Value** | **string** | Extra attribute field value | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

