# Org.OpenAPITools.Model.GetAuditLogResponseAuditLogsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AuditLogDetails** | [**List&lt;GetAuditLogResponseAuditLogsInnerAuditLogDetailsInner&gt;**](GetAuditLogResponseAuditLogsInnerAuditLogDetailsInner.md) |  | [optional] 
**AuditableAction** | **AuditableAction** |  | [optional] 
**AuditableId** | **int** | The ID of the user who performed this action | [optional] 
**AuditableType** | **AuditableType** |  | [optional] 
**CreatedAt** | **DateTime** | Audit log creation timestamp | [optional] 
**Customer** | [**GetAuditLogResponseAuditLogsInnerCustomer**](GetAuditLogResponseAuditLogsInnerCustomer.md) |  | [optional] 
**Description** | **string** | Description of the audited action | [optional] 
**Id** | **string** | Audit log ID | [optional] 
**OrgUnit** | [**GetAuditLogResponseAuditLogsInnerOrgUnit**](GetAuditLogResponseAuditLogsInnerOrgUnit.md) |  | [optional] 
**UpdatedAt** | **DateTime** | Audit log update timestamp | [optional] 
**User** | [**GetAuditLogResponseAuditLogsInnerUser**](GetAuditLogResponseAuditLogsInnerUser.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

