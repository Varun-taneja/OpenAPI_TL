# Org.OpenAPITools.Model.GetAuditLogResponseAuditLogsInnerAuditLogDetailsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AuditablePreviousValueId** | **int** | The previous auditable value identifier | [optional] 
**AuditablePreviousValueStr** | **string** | The previous auditable value identifier as in string format | [optional] 
**AuditablePreviousValueType** | **string** | The previous auditable human readable type | [optional] 
**AuditableValueId** | **string** | The current auditable value identifier | [optional] 
**AuditableValueStr** | **string** | The current auditable value identifier as in string format | [optional] 
**AuditableValueType** | **string** | The current auditable human readable type | [optional] 
**Description** | **string** | The description of the auditable_value | [optional] 
**Id** | **int** | The id of the auditable_value | [optional] 
**LongDescription** | **string** | Long description of the auditable_value | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

