# Org.OpenAPITools.Model.GetAuditLogResponseAuditLogsInnerOrgUnit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArchiveOnly** | **bool** | True if this org unit is archive only | [optional] 
**Id** | **int** | Org unit ID | [optional] 
**Name** | **string** | Org unit name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

