# Org.OpenAPITools.Model.GetAuditLogResponseAuditLogsInnerUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | The user&#39;s email address | [optional] 
**Id** | **int** | User ID | [optional] 
**Name** | **string** | The user&#39;s name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

