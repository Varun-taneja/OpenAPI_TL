# Org.OpenAPITools.Model.GetContextResponseContext
The token context

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**DataCenter** | **string** | The data center that this key is valid for | [optional] 
**ExpiresAt** | **DateTime** | The expires at timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Only applicable for access tokens with &#x60;jwt&#x60; type | [optional] 
**IntegrationId** | **decimal** | The ID of the integration this token is associated with, used by third party integrations. Only present when &#39;type&#39; is &#39;third_party&#39; | [optional] 
**Name** | **string** | The name of the key | [optional] 
**Permissions** | **List&lt;string&gt;** |  | [optional] 
**Type** | **string** | The type of access token that was used | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

