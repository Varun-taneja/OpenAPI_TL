# Org.OpenAPITools.Model.GetIntegrationStateResponseState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Internal** | **Object** | Free form JSON object that can be used to track any internal integration state | [optional] 
**LastRun** | **DateTime** | The timestamp of the last run of the integration in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6), must be set by the integration | [optional] 
**LastUpload** | **DateTime** | The timestamp of the last upload to the integration in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). Automatically set by the API. | [optional] 
**Name** | **string** | Name of the integration when it was created | [optional] 
**Paused** | **bool** | Indicates if the integration is paused | [optional] 
**Status** | **Status** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

