# Org.OpenAPITools.Model.GetIntegrationsInstallResponseUserTokenStatus
The integration's user identity and token status

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TenantId** | **string** | The Microsoft Active Directory tenant ID | [optional] 
**AccountUserId** | **string** | The user&#39;s Microsoft Active Directory account ID | [optional] 
**AccountUserEmail** | **string** | The user&#39;s Microsoft Active Directory email address | [optional] 
**AccountUserName** | **string** | Rich | [optional] 
**AccessTokenExpirationDate** | **DateTime** | The access token expiration date. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**RefreshTokenExpirationDate** | **DateTime** | The refresh token expiration date. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

