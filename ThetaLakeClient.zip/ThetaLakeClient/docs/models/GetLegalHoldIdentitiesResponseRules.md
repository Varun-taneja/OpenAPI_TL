# Org.OpenAPITools.Model.GetLegalHoldIdentitiesResponseRules

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RuleCount** | **int** | The number of rules associated with the legal hold | [optional] 
**Rules** | [**List&lt;LegalHoldIdentity&gt;**](LegalHoldIdentity.md) | A list of rules associated with the legal hold | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

