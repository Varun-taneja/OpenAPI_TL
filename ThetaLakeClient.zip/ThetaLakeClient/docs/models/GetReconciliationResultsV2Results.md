# Org.OpenAPITools.Model.GetReconciliationResultsV2Results

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalHits** | **int** | The total number of unique records that match across all queries | [optional] 
**Range** | [**DateRange**](DateRange.md) |  | [optional] 
**Hits** | [**List&lt;ResultV2&gt;**](ResultV2.md) | An array of matching results | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

