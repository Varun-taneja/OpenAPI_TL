# Org.OpenAPITools.Model.GetRolesResponseRolesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | Only included in custom roles. Role creation timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Default** | **bool** | Indicates if this role is the default role | [optional] 
**Description** | **string** | A description of the role | [optional] 
**Id** | **int** | The role ID | [optional] 
**IsBuiltIn** | **bool** | Indicates if the role is built in or custom | [optional] 
**Name** | **string** | The role&#39;s name | [optional] 
**NumberOfUsers** | **int** | The number of users currently assigned to this role | [optional] 
**UpdatedAt** | **DateTime** | Only included in custom roles. Role updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

