# Org.OpenAPITools.Model.GetSearchResponseSearchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | A description for the saved search | [optional] 
**Hits** | **int** | The number of datums this search will return | [optional] 
**Id** | **int** | The ID for the security filter search | [optional] 
**Name** | **string** | The security filter&#39;s name | [optional] 
**Type** | **string** | The type of saved search | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

