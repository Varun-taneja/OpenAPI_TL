# Org.OpenAPITools.Model.GetStorageAccountsResponseStorageAccountsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RetentionLibraries** | **int** | The number of retention libraries associated with the storage account | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**GlobalStorage** | **bool** | Indicates if the storage account is global | [optional] 
**Id** | **int** | The storage account ID | [optional] 
**Name** | **string** | The storage account name | [optional] 
**Region** | **string** | Storage account region | [optional] 
**RegionPretty** | **string** | A pretty formatted version of the region field | [optional] 
**Status** | **string** | The current status of the storage account | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

