# Org.OpenAPITools.Model.GetUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**CurrentOrgUnit** | [**SchemasCurrentOrgUnit**](SchemasCurrentOrgUnit.md) |  | [optional] 
**Disabled** | **bool** | Indicates if the user has been disabled | [optional] 
**DisabledAt** | **DateTime** | When the user was disabled timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**DefaultUserTimezone** | **string** | Timezone the user is assigned to by default | [optional] 
**Email** | **string** | The email address associated with this user | [optional] 
**ForceSso** | **bool** | Indicates if the user has to use SSO to sign in | [optional] 
**HasDatums** | **bool** | Indicates if the user is associated with any captured datums | [optional] 
**HasMultipleWorkspaces** | **bool** | Indicates if the user is assigned to multiple workspaces | [optional] 
**Id** | **int** | The user ID | [optional] 
**LastLogin** | **DateTime** | The user&#39;s last login timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Name** | **string** | The user&#39;s name | [optional] 
**OtpEnabled** | **bool** | Indicates if the use has OTP enabled | [optional] 
**OtpEnabledAt** | **DateTime** | The timestamp of when OTP was enabled using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**PasswordChangedAt** | **DateTime** | The timestamp of the last time the user&#39;s password was changed using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**QueuePaused** | **bool** | Indicates if the users queue has been paused | [optional] 
**Role** | [**Role**](Role.md) |  | [optional] 
**SecurityFilter** | [**SecurityFilter**](SecurityFilter.md) |  | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UserInitials** | **string** | The user&#39;s initials | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

