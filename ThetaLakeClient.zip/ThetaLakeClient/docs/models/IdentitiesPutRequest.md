# Org.OpenAPITools.Model.IdentitiesPutRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdentityIds** | **List&lt;int&gt;** | An array of identity IDs to merge to the target identity | [optional] 
**TargetIdentityId** | **int** | The target identity ID to merge the identities into | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

