# Org.OpenAPITools.Model.IdentityExtraAttributesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**EndDate** | **DateTime** | End date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Field** | **string** | Extra attribute field name | [optional] 
**Id** | **int** | Extra attribute field identifier | [optional] 
**Source** | **string** | The originating source for the identity or attribute | [optional] 
**StartDate** | **DateTime** | Start date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Value** | **string** | Extra attribute field value | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

