# Org.OpenAPITools.Model.IdentityRisks

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Comment** | **string** | Comment for the identity&#39;s risk in the datum | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**DatumId** | **int** | The datum ID with the risky behavior in it | [optional] 
**Id** | **int** | Identity of the risk | [optional] 
**IdentityId** | **int** | The ID of the identity behaving riskily | [optional] 
**Risky** | **bool** | Indicates if identity is behaving in a risky fashion | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UserId** | **int** | The ID of the user that created the risk | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

