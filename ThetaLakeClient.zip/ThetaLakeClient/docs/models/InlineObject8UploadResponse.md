# Org.OpenAPITools.Model.InlineObject8UploadResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** | Upload response message | [optional] 
**Success** | **bool** | Indicates the upload was unsuccessful | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

