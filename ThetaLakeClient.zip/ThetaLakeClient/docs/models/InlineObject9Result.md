# Org.OpenAPITools.Model.InlineObject9Result

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentType** | **string** | The uploaded data&#39;s detected [content type](https://www.iana.org/assignments/media-types/media-types.xhtml) | [optional] 
**HashSha256** | **string** | The uploaded data&#39;s SHA256 hash | [optional] 
**Uuid** | **string** | The uploaded data&#39;s UUID in the Theta Lake system | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

