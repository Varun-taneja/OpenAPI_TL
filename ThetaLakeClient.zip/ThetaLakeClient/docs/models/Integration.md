# Org.OpenAPITools.Model.Integration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessTokenExpirationDate** | **DateTime** | If a token is used for authentication, and has a expiration date, it will be reflected here using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**AccountUserEmail** | **string** | The account email that is associated with the API | [optional] 
**AccountUserId** | **string** | The account ID that is associated with the API | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | The description entered when adding the integration | [optional] 
**HasIntegrationPolicy** | **bool** | Indicates if the datum produced by this integration are being analyzed by a detection policy | [optional] 
**Id** | **string** | The integration ID | [optional] 
**IntegrationGroup** | **string** | The type of integration | [optional] 
**IntegrationPolicyId** | **string** | The ID of the policy for this integration | [optional] 
**IntegrationType** | **string** | Name of the service integrated with | [optional] 
**IntegrationTypeId** | **string** | Theta Lake&#39;s internal integration ID | [optional] 
**LastUploadAt** | **DateTime** | The last date the integration uploaded content using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Name** | **string** | Name of the integration when it was created | [optional] 
**NotBeforeDate** | **DateTime** | Indicates the date that no data can be consumed before using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**NotifySubmitter** | **bool** | Indicates if the submitter assigned to review data will be notified when new data is uploaded | [optional] 
**ScopesChanged** | **bool** | Indicates if the scopes have been changed | [optional] 
**ServiceLastRunAt** | **DateTime** | The timestamp of the last integration run using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). This is not the last time data was uploaded | [optional] 
**ServicePaused** | **string** | Indicates if the integration has been paused | [optional] 
**ServiceStatus** | **string** | The state of the last integration run | [optional] 
**Status** | **string** | The integration&#39;s current status | [optional] 
**StatusColor** | **string** | RGB hex color value representing the current status | [optional] 
**UpdatedAt** | **DateTime** | The last time the integration was updated in the Theta Lake portal UI | [optional] 
**UploadsLast30Days** | **string** | How many datums have been uploaded in the last 30 days | [optional] 
**User** | [**IntegrationUser**](IntegrationUser.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

