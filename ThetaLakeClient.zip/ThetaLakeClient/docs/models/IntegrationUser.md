# Org.OpenAPITools.Model.IntegrationUser
The user that set up the integration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | The user&#39;s email | [optional] 
**Id** | **string** | The user&#39;s ID | [optional] 
**Name** | **string** | The user&#39;s name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

