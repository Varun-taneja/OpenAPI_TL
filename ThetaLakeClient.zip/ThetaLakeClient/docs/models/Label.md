# Org.OpenAPITools.Model.Label

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BackgroundColor** | **string** | RGB hex color value representing the background color of the label | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Hidden** | **bool** | Indicates if the label is hidden on the UI | [optional] 
**Id** | **int** | The label ID | [optional] 
**LongName** | **string** | The description of the label | [optional] 
**OrgUnitId** | **int** | The org unit associated with the new label | [optional] 
**ShortName** | **string** | The name of the label shown on records | [optional] 
**TaggedDatumsCount** | **int** | The number of records with this label assigned | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UserId** | **int** | The user&#39;s ID | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

