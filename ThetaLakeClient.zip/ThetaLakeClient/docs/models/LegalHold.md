# Org.OpenAPITools.Model.LegalHold

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The create date of the legal hold. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | Legal hold description | [optional] 
**Id** | **int** | The ID of the legal hold | [optional] 
**Name** | **string** | The name of the legal hold | [optional] 
**RuleCount** | **int** | The number of rules associated with the legal hold | [optional] 
**UpdatedAt** | **DateTime** | The last update date of the legal hold. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

