# Org.OpenAPITools.Model.LegalHoldIdentity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | The ID of the legal hold rule | [optional] 
**Identity** | **Object** | The identity associated with the legal hold rule | [optional] 
**CreatedAt** | **DateTime** | The create date of the legal hold rule. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**EndDate** | **DateTime** | The end date of the legal hold rule. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Roles** | **List&lt;string&gt;** | A list of roles associated with the identity on the legal hold rule | [optional] 
**StartDate** | **DateTime** | The start date of the legal hold rule. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UpdatedAt** | **DateTime** | The updated date of the legal hold rule. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

