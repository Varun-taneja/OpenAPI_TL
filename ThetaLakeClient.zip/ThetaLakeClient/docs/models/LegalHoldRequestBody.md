# Org.OpenAPITools.Model.LegalHoldRequestBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdentityId** | **int** | The ID of the identity to add to the legal hold | 
**Roles** | **List&lt;string&gt;** | The roles to add to the legal hold. Roles can be found in the [/legal_hold/roles](/api-reference#get-/legal_hold/roles) endpoint using the &#x60;value&#x60; field. At least 1 role must be specified | 
**EndDate** | **DateTime** | The end date of the legal hold. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**StartDate** | **DateTime** | The start date of the legal hold. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

