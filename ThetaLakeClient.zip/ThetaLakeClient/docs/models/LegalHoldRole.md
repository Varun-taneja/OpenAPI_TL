# Org.OpenAPITools.Model.LegalHoldRole

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the role | [optional] 
**Value** | **string** | The value of the role. This value is needed when adding an identity to a legal hold | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

