# Org.OpenAPITools.Model.LinkedInInstalledUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisplayName** | **string** | The installed user&#39;s LinkedIn display name | [optional] 
**Email** | **string** | The installed user&#39;s email | [optional] 
**Expired** | **bool** | Indicates if the user&#39;s LinkedIn token has expired | [optional] 
**ExpiryDate** | **DateTime** | The date the user&#39;s LinkedIn token expires using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

