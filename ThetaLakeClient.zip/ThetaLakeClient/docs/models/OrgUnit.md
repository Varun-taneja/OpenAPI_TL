# Org.OpenAPITools.Model.OrgUnit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowAnonymousViaSharedLinks** | **bool** | Indicates the ability to share a link to records publicly | [optional] 
**AnalysisSupervisionSpaces** | [**List&lt;AnalysisSupervisionSpacesInner&gt;**](AnalysisSupervisionSpacesInner.md) | Datums matching these spaces will be analyzed for risky behaviors | [optional] 
**AuditLogRetentionPeriod** | **int** | The duration audit logs for this bucket will be retained | [optional] 
**BucketName** | **string** | The assigned bucket for this org unit | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**DefaultOrgTimezone** | **string** | The org units default timezone | [optional] 
**DeleteOnExpiration** | **bool** | Indicates if records in this org unit should be deleted when they expire from the archive | [optional] 
**Description** | **string** | A description for the org unit | [optional] 
**Disabled** | **bool** | Indicates if the org unit is disabled | [optional] 
**DisabledAt** | **string** | If the org is disabled, the timestamp of when it was disabled, using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). | [optional] 
**FallbackLanguage** | **FallbackLanguage** |  | [optional] 
**Id** | **int** | ID of the org unit | [optional] 
**Name** | **string** | Name of the Org Unit | [optional] 
**PreferredLanguageList** | [**List&lt;OrgUnitPreferredLanguageListInner&gt;**](OrgUnitPreferredLanguageListInner.md) | An array of all preferred languages | [optional] 
**PreferredLanguages** | **List&lt;OrgUnit.PreferredLanguagesEnum&gt;** | An array of selected preferred languages | [optional] 
**SharedLinksExpirationPeriod** | **int** | The duration in days that shared links for this org unit will be valid | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**UseNameMatcher** | **bool** | Indicates if the org unit identity matching algorithm uses names | [optional] 
**UseOwnerOnlySpaceMatcher** | **bool** | Indicates if the org unit identity matching algorithm should stop after owner and then fallback to default | [optional] 
**Users** | [**List&lt;OrgUnitUsersInner&gt;**](OrgUnitUsersInner.md) | Users included to this org unit | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

