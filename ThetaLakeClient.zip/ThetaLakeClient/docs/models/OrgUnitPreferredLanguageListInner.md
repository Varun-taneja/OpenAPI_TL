# Org.OpenAPITools.Model.OrgUnitPreferredLanguageListInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** | The language code using ISO 639-1/3 | [optional] 
**Label** | **string** | The English name for the language | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

