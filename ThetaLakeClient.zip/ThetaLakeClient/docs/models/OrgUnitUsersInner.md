# Org.OpenAPITools.Model.OrgUnitUsersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | The email address associated with this user | [optional] 
**Id** | **int** | The id of the user | [optional] 
**Name** | **string** | The user&#39;s | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

