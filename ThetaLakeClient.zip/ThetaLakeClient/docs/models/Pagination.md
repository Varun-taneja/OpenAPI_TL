# Org.OpenAPITools.Model.Pagination
Pagination information

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PrevPageToken** | **string** | The previous page token, if there is no previous page, it will be null | [optional] 
**NextPageToken** | **string** | The next page token, if there is no next page, it will be null | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

