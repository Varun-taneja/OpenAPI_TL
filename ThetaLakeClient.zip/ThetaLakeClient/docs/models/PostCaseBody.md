# Org.OpenAPITools.Model.PostCaseBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** | The case description | [optional] 
**Name** | **string** | The case name | [optional] 
**Number** | **string** | The case number, this is usually a unique identifier for the case | [optional] 
**OpenDate** | **DateTime** | The timestamp of when the case was opened. Uses the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Visibility** | **string** | The case visibility | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

