# Org.OpenAPITools.Model.PostChatConversationBodyChat

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Application** | [**PostChatConversationBodyChatApplication**](PostChatConversationBodyChatApplication.md) |  | 
**Conversation** | [**PostChatConversationBodyChatConversation**](PostChatConversationBodyChatConversation.md) |  | 
**Messages** | [**List&lt;PostChatConversationBodyChatMessagesInner&gt;**](PostChatConversationBodyChatMessagesInner.md) |  | 
**Attachments** | [**List&lt;PostChatConversationBodyChatAttachmentsInner&gt;**](PostChatConversationBodyChatAttachmentsInner.md) | An array of meta data for all the attachments. If there are no attachments, this should just be an empty array. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

