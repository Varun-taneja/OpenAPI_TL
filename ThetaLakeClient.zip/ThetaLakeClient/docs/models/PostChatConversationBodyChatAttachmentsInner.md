# Org.OpenAPITools.Model.PostChatConversationBodyChatAttachmentsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | A unique ID for the attachment. Used to reference attachments in the chat messages. | 
**Name** | **string** | The file name of the attachment. **Must match the file name of the actual attachment** | 
**ContentType** | **string** | The content-type of the attachment. Uses standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml) | 
**Size** | **int** | The size in bytes of the attachment | [optional] 
**CreateTime** | **DateTime** | The creation timestamp of the attachment in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

