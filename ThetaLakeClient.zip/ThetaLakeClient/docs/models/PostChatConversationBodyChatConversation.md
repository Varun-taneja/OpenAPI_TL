# Org.OpenAPITools.Model.PostChatConversationBodyChatConversation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The chat conversation&#39;s ID | 
**Name** | **string** | The chat conversation&#39;s name | 
**BeginTime** | **DateTime** | The chat conversation&#39;s begin time in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | 
**EndTime** | **DateTime** | The chat conversation&#39;s end time in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | 
**PreviousUuid** | **string** | The UUID of the conversation&#39;s previous chat messages. Required if connecting chat messages into a conversation. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

