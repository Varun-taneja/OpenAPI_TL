# Org.OpenAPITools.Model.PostChatConversationBodyChatMessagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The message ID from the chat platform | 
**ParticipantId** | **string** | The ID of the participant that sent this message. This ID must correspond to an ID in the &#x60;meta.participants.activemember&#x60; array. | 
**Text** | **string** | The message&#39;s text | 
**ContentType** | **MessageContentType** |  | 
**Timestamp** | **DateTime** | The message&#39;s timestamp in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | 
**DeletedTimestamp** | **DateTime** | The message&#39;s deleted timestamp in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**EditedMessageId** | **string** | The id of the message being edited | [optional] 
**ReactionToMessageId** | **string** | The id of the message being reacted to | [optional] 
**ReplyToMessageId** | **string** | The id of the message being replied to | [optional] 
**AttachmentIds** | **List&lt;string&gt;** | The IDs of the attachments attached to this specific message | [optional] 
**Importance** | [**PostChatConversationBodyChatMessagesInnerImportance**](PostChatConversationBodyChatMessagesInnerImportance.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

