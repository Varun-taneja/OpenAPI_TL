# Org.OpenAPITools.Model.PostChatConversationBodyChatMessagesInnerImportance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** | The importance of the message | 
**Text** | **string** | A description of why this message is important | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

