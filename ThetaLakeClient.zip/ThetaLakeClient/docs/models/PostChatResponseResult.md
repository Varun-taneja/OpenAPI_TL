# Org.OpenAPITools.Model.PostChatResponseResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Chat** | [**PostDatumResult**](.md) |  | [optional] 
**FileAttachments** | [**Dictionary&lt;string, PostDatumResult&gt;**](PostDatumResult.md) | A map of the attachment upload responses. The keys are the attachment filenames. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

