# Org.OpenAPITools.Model.PostDatumResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentType** | **string** | The uploaded data&#39;s detected [content type](https://www.iana.org/assignments/media-types/media-types.xhtml) | [optional] 
**HashSha256** | **string** | The uploaded data&#39;s SHA256 hash | [optional] 
**Uuid** | **string** | The uploaded data&#39;s UUID in the Theta Lake system | [optional] 
**UploadDate** | **DateTime** | The uploaded data&#39;s timestamp in [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

