# Org.OpenAPITools.Model.PostDirectoryGroupIdentityRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The identity&#39;s name | [optional] 
**PhoneNumber** | **string** | The identity&#39;s phone number | [optional] 
**Email** | **string** | The identity&#39;s email address | [optional] 
**ExternalId** | **string** | An external ID for the identity | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

