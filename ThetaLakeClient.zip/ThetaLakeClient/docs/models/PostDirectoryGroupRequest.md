# Org.OpenAPITools.Model.PostDirectoryGroupRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name of the directory group | [optional] 
**ExternalId** | **string** | An external identifier for the directory group | [optional] 
**Description** | **string** | A short description of the directory group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

