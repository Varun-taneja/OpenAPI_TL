# Org.OpenAPITools.Model.PostDirectoryGroupResponseDirectoryGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | A short description of the directory group | [optional] 
**ExternalId** | **string** | An external identifier for the directory group | [optional] 
**Id** | **int** | The directory group&#39;s ID | [optional] 
**Name** | **string** | Name of the directory group | [optional] 
**OrgUnitId** | **int** | The org unit associated with the new directory group | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

