# Org.OpenAPITools.Model.PostEmailBodyMeta

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreateDate** | **DateTime** | The data creation timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | 
**FileName** | **string** | This is the **title** of the email file. It appears as the record title in the Theta Lake Portal. When you search by &#39;media title&#39; in the Portal, you search for this text. | 
**IdentityData** | **string** | A unique, arbitrary string identifier that is specified by the client. You can use this identifier to verify whether the data has been uploaded. | 
**CustomTransportType** | **string** | A custom MIME style string which identifies the platform from which the content was generated | [optional] 
**PlatformAttributes** | **Dictionary&lt;string, string&gt;** | An open set of key-value pairs that can be used to store platform attributes. API platform attributes are only searchable by exact string match. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

