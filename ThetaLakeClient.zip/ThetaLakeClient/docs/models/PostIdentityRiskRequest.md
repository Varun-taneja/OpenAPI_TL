# Org.OpenAPITools.Model.PostIdentityRiskRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DatumId** | **int** | The datum ID with the risky behavior in it | [optional] 
**Risky** | **bool** | Indicates if identity is behaving in a risky fashion | [optional] 
**Comment** | **string** | Comment for the identity&#39;s risk in the datum | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

