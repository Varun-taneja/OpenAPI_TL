# Org.OpenAPITools.Model.PostLabelRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BackgroundColor** | **string** | RGB hex color value representing the background color of the label | [optional] 
**Hidden** | **bool** | Indicates if the label is hidden on the UI | [optional] 
**LongName** | **string** | The description of the label | [optional] 
**ShortName** | **string** | The name of the label shown on records | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

