# Org.OpenAPITools.Model.PostPutSupervisionSpacesRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllParticipants** | **bool** | Indicates if the supervision space should allow adding all participants, creating a catch all space for participants. Only one supervision space can have all participants enabled. | [optional] 
**AllUsers** | **bool** | Indicates if the supervision space should allow adding all users | [optional] 
**Name** | **string** | The supervision space name | [optional] 
**Description** | **string** | The description of the supervision space given when created | [optional] 
**DirectoryGroupIds** | **List&lt;int&gt;** | An array of directory group IDs to associate with this supervision space | [optional] 
**ExternalId** | **string** | An external ID for the supervision space | [optional] 
**HardEnforce** | **bool** | Indicates if users can be assigned records from other supervision spaces | [optional] 
**IntegrationIds** | **List&lt;int&gt;** | An array of integration IDs to associate with this supervision space | [optional] 
**MediaTypeIds** | **List&lt;int&gt;** | An array of media type IDs to associate with this supervision space, | [optional] 
**RetentionLibraryIds** | **List&lt;int&gt;** | An array of retention library IDs to associate with this supervision space | [optional] 
**SupervisionSpacePriority** | **int** | The priority of assigning records to a supervision space | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

