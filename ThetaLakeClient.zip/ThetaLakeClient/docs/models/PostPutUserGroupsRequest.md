# Org.OpenAPITools.Model.PostPutUserGroupsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The user group&#39;s name | [optional] 
**Description** | **string** | The user group&#39;s description | [optional] 
**ExternalId** | **string** | An eternal ID for the user group | [optional] 
**CategoryIds** | **List&lt;int&gt;** | An array of category IDs for this user group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

