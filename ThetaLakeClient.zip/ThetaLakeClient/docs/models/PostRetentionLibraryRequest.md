# Org.OpenAPITools.Model.PostRetentionLibraryRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageAccountId** | **int** | Storage account ID | 
**Name** | **string** | The name of the bucket | 
**Description** | **string** | A description of the bucket | [optional] 
**ExternalId** | **string** | An external ID for the retention library | [optional] 
**SecCompliantStorageEnabled** | **bool** | Indicates if the storage has SEC Rule 17a-4 compliance enabled | [optional] 
**RetentionPeriodEnabled** | **bool** | Indicates if a retention period policy is currently enabled | [optional] 
**RetentionPeriodDays** | **int** | Retention period in days | [optional] 
**RetainInReview** | **bool** | Indicates if the retention library should be retained while review is open | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

