# Org.OpenAPITools.Model.PostSearchBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Comments** | [**PostSearchBodyComments**](PostSearchBodyComments.md) |  | [optional] 
**Cases** | [**PostSearchBodyCases**](PostSearchBodyCases.md) |  | [optional] 
**ContentSource** | **List&lt;string&gt;** | Each [content source](/documentation/search#content-source) is used with an OR operator. If 2 content_source&#39;s are given, records from both content_source&#39;s will be searched. | [optional] 
**Id** | **List&lt;int&gt;** | The record ID. If multiple record IDs are given, the search will use an OR operator | [optional] 
**Identities** | [**PostSearchBodyIdentities**](PostSearchBodyIdentities.md) |  | [optional] 
**Media** | **List&lt;PostSearchBody.MediaEnum&gt;** | The record [media type](/documentation/search#media). If multiple media types are given, the search will use an OR operator | [optional] 
**Participants** | [**PostSearchBodyParticipants**](PostSearchBodyParticipants.md) |  | [optional] 
**PolicyDetections** | [**PostSearchBodyPolicyDetections**](PostSearchBodyPolicyDetections.md) |  | [optional] 
**Range** | [**PostSearchBodyRange**](PostSearchBodyRange.md) |  | [optional] 
**Risk** | **List&lt;PostSearchBody.RiskEnum&gt;** | The analyzed risk of the record. If not_analyzed is passed, only not_analyzed records will be found. Other risks will be used as a OR operator | [optional] 
**Sort** | [**PostSearchBodySort**](PostSearchBodySort.md) |  | [optional] 
**Uuid** | **List&lt;string&gt;** | The record UUID. If multiple record UUIDs are given, the search will use an OR operator | [optional] 
**Workflow** | [**PostSearchBodyWorkflow**](PostSearchBodyWorkflow.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

