# Org.OpenAPITools.Model.PostSearchBodyCases
The [cases](/documentation/search#cases) attributes for the record

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FilterType** | **string** | The operator to search with, defaults to *is* | [optional] 
**Ids** | **List&lt;int&gt;** | The case IDs to search for. If multiple case IDs are given, the search will use an OR operator | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

