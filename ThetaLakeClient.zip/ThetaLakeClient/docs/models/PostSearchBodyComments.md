# Org.OpenAPITools.Model.PostSearchBodyComments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flags** | **List&lt;PostSearchBodyComments.FlagsEnum&gt;** | The comment flags to search for. If multiple comment flags are given, the search will use an OR operator | [optional] 
**AuthorName** | **List&lt;string&gt;** | The name of the comment author to search for | [optional] 
**AuthorEmail** | **List&lt;string&gt;** | The email of the comment author to search for | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

