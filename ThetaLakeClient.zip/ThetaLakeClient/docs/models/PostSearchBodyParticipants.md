# Org.OpenAPITools.Model.PostSearchBodyParticipants
The [participants](/documentation/search#participants) attributes for the record

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Operator** | **string** | The operator to search with | [optional] 
**Attributes** | [**List&lt;PostSearchBodyParticipantsAttributesInner&gt;**](PostSearchBodyParticipantsAttributesInner.md) | The attribute to search on | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

