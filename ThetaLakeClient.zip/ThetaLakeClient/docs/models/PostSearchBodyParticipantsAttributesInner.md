# Org.OpenAPITools.Model.PostSearchBodyParticipantsAttributesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attribute** | **string** | The type of attribute to search on | [optional] 
**ParticipantInformation** | **string** | The value of the attribute to search with | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

