# Org.OpenAPITools.Model.PostSearchBodyPolicyDetectionsPolicyHits
Policy hits that triggered on the record

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Inclusion** | **string** |  | [optional] 
**PolicyHit** | **List&lt;int&gt;** | The &#x60;id&#x60; from the [list all policy_hits](/api-reference#get-/analysis/policy_hits) endpoint | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

