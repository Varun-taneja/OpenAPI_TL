# Org.OpenAPITools.Model.PostSearchBodyRange
A date [range](/documentation/search#range) to search on. **The maximum allowed range is 7 days**. If no range is provided, the system defaults to the last 7 days from the current date. The default type is `upload_date`. All dates are inclusive

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** | The type date range, default is *upload_date* | [optional] 
**Start** | **DateTime** | **Inclusive** start of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**End** | **DateTime** | **Inclusive** end of the date range using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6), defaults to Now() | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

