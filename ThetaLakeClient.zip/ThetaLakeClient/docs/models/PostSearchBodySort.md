# Org.OpenAPITools.Model.PostSearchBodySort
Sort by attribute of the results. See [this documentation](/documentation/search#sort) for more details

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**By** | **string** | How to sort the results, default is *upload_date* | [optional] 
**Order** | **string** | How to sort the results, default is *desc* | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

