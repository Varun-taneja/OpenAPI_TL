# Org.OpenAPITools.Model.PostSearchBodyWorkflow
Search records related to workflows

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | [**PostSearchBodyWorkflowName**](PostSearchBodyWorkflowName.md) |  | [optional] 
**State** | [**PostSearchBodyWorkflowState**](PostSearchBodyWorkflowState.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

