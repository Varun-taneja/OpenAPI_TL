# Org.OpenAPITools.Model.PostSearchBodyWorkflowName

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **List&lt;int&gt;** | The workflow name to search for by id. If multiple workflow ids are given, the search will use an OR operator. Ids can be found in the [list all workflows](/api-reference#get-/workflows) endpoint | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

