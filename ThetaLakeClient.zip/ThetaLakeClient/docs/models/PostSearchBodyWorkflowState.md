# Org.OpenAPITools.Model.PostSearchBodyWorkflowState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Inclusion** | **string** | The operator to search with, defaults to *is* | [optional] 
**Id** | **List&lt;int&gt;** | The workflow state ids to search for. If multiple ids are given, the search will use an OR operator. Ids can be found in the [list all states for a workflow](/api-reference#get-/workflows/-id-/states) endpoint | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

