# Org.OpenAPITools.Model.PostSearchResponseNewResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Id** | **decimal** | The id of the search | [optional] 
**Hits** | **decimal** | This is the total hits for this search. This value will not change during pagination | [optional] 
**Records** | [**List&lt;PostSearchResponseNewResultRecordsInner&gt;**](PostSearchResponseNewResultRecordsInner.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

