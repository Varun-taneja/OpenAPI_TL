# Org.OpenAPITools.Model.PostSearchResponseRecordsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentSource** | **string** | The content source of the record | [optional] 
**ContentType** | **string** | The content-type of the data. Uses standard [MIME types](https://www.iana.org/assignments/media-types/media-types.xhtml) | [optional] 
**CreateDate** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**HashSha256** | **string** | The record&#39;s SHA256 hash | [optional] 
**Id** | **int** | The record ID | [optional] 
**OriginalFileName** | **string** | The record&#39;s filename | [optional] 
**RecordSize** | **int** | The record&#39;s file size in bytes | [optional] 
**Risk** | **string** | The record&#39;s risk | [optional] 
**UploadDate** | **DateTime** | Record upload timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Uuid** | **string** | The record&#39;s UUID. This UUID matches the portal record ID | [optional] 
**PlatformAttributes** | **Object** | A map of key value pairs of the records platform attributes | [optional] 
**Participants** | **Dictionary&lt;string, List&lt;SchemasParticipantInner&gt;&gt;** | The record&#39;s participants | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

