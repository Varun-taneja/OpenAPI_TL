# Org.OpenAPITools.Model.PublishingType
Indicates whether or not the content has been published and therefore is in a pre-publishing or post-publishing workflow

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

