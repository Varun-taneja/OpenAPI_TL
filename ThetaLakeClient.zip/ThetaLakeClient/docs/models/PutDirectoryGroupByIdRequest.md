# Org.OpenAPITools.Model.PutDirectoryGroupByIdRequest
The fields to be updated on the group

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** | A short description of the directory group | [optional] 
**ExternalId** | **string** | An external identifier for the directory group | [optional] 
**Name** | **string** | Name of the directory group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

