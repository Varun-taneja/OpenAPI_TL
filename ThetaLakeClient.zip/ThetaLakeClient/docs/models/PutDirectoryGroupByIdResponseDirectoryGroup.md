# Org.OpenAPITools.Model.PutDirectoryGroupByIdResponseDirectoryGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** | A short description of the directory group | [optional] 
**ExternalId** | **string** | An external identifier for the directory group | [optional] 
**Id** | **int** | The directory group&#39;s ID | [optional] 
**Name** | **string** | Name of the directory group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

