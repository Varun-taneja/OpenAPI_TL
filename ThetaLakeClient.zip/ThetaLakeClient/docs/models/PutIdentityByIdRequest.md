# Org.OpenAPITools.Model.PutIdentityByIdRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The identity&#39;s name | [optional] 
**Email** | **string** | Email of the identity user | [optional] 
**EmailStartDate** | **DateTime** | Email start date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**EmailEndDate** | **DateTime** | Email end date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**PhoneNumber** | **string** | The identity&#39;s phone number | [optional] 
**PhoneNumberStartDate** | **DateTime** | Phone number start date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**PhoneNumberEndDate** | **DateTime** | Phone number end date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**ExternalId** | **string** | An external ID for the identity | [optional] 
**ExternalIdStartDate** | **DateTime** | External ID start date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**ExternalIdEndDate** | **DateTime** | External ID end date timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

