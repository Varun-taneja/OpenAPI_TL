# Org.OpenAPITools.Model.PutOrgUnitByIdRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowAnonymousViaSharedLinks** | **bool** | Indicates the ability to share a link to records publicly | [optional] 
**AnalysisSupervisionSpaceIds** | **List&lt;int&gt;** | Datums matching these supervision spaces will be analyzed for risky behaviors | [optional] 
**AuditLogRetentionPeriod** | **int** | The duration audit logs for this bucket will be retained | [optional] 
**DefaultOrgTimezone** | **string** | The org units default timezone | [optional] 
**DeleteOnExpiration** | **bool** | Indicates if records in this org unit should be deleted when they expire from the archive | [optional] 
**FallbackLanguage** | **FallbackLanguage** |  | [optional] 
**PreferredLanguages** | **List&lt;PutOrgUnitByIdRequest.PreferredLanguagesEnum&gt;** | An array of selected preferred languages | [optional] 
**UseNameMatcher** | **bool** | Indicates if the org unit identity matching algorithm uses names | [optional] 
**UseOwnerOnlySpaceMatcher** | **bool** | Indicates if the org unit identity matching algorithm should stop after owner and then fallback to default | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

