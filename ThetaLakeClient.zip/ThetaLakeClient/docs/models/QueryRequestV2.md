# Org.OpenAPITools.Model.QueryRequestV2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Platform** | **string** | Third party platform to reconcile. [Supported platforms are documented here](/documentation/reconciliation) | [optional] 
**Attribute** | [**QueryRequestV2Attribute**](QueryRequestV2Attribute.md) |  | [optional] 
**IncludesTimestamp** | **DateTime** | Records that contain the provided timestamp in the list of records in the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6). This applies to select attributes,  for more information for more information see [the documentation on includes_timestamp](/documentation/reconciliation#includes_timestamp).  | [optional] 
**MediaTypes** | **List&lt;QueryRequestV2.MediaTypesEnum&gt;** | Filter the records by the media_type. If multiple values are provided, the results will be filtered by the OR operator | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

