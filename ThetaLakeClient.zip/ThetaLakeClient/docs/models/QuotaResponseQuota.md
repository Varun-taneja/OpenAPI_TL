# Org.OpenAPITools.Model.QuotaResponseQuota

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | [**QuotaResponseQuotaData**](QuotaResponseQuotaData.md) |  | [optional] 
**Message** | **string** | A message with the date range for the quota summary | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

