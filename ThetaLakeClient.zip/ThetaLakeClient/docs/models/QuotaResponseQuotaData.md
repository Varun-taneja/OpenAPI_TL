# Org.OpenAPITools.Model.QuotaResponseQuotaData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApiAttachmentBytesUsed** | **int** | The used quota in bytes for API attachment data | [optional] 
**ApiBytes** | **int** | The quota in bytes for API data | [optional] 
**ApiBytesDaily** | **int** | The daily used quota in bytes for API data | [optional] 
**ApiBytesUsed** | **int** | The used quota in bytes for API data | [optional] 
**AudioAttachmentBytesUsed** | **int** | The used quota in bytes for audio attachment data | [optional] 
**AudioBytes** | **int** | The quota in bytes for audio data | [optional] 
**AudioBytesUsed** | **int** | The used quota in bytes for audio data | [optional] 
**DocumentAttachmentBytesUsed** | **int** | The used quota in bytes for document attachment data | [optional] 
**DocumentBytes** | **int** | The quota in bytes for document data | [optional] 
**DocumentBytesUsed** | **int** | The used quota in bytes for document data | [optional] 
**EmailAttachmentBytesUsed** | **int** | The used quota in bytes for email attachment data | [optional] 
**EmailBytes** | **int** | The quota in bytes for email data | [optional] 
**EmailBytesUsed** | **int** | The used quota in bytes for email data | [optional] 
**OtherAttachmentBytesUsed** | **int** | The used quota in bytes for all other attachment data | [optional] 
**OtherBytes** | **int** | The quota in bytes for all other types of data | [optional] 
**OtherBytesUsed** | **int** | The used quota in bytes for all other types of data | [optional] 
**TotalBytes** | **int** | The quota in bytes for all data | [optional] 
**TotalBytesDaily** | **int** | The daily used quota in bytes for all data | [optional] 
**TotalBytesUsed** | **int** | The used quota in bytes for all data | [optional] 
**VideoAttachmentBytesUsed** | **int** | The used quota in bytes for video attachment data | [optional] 
**VideoBytes** | **int** | The quota in bytes for video data | [optional] 
**VideoBytesUsed** | **int** | The used quota in bytes for video data | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

