# Org.OpenAPITools.Model.RecordMatch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArchiveHandles** | [**List&lt;RecordMatchArchiveHandlesInner&gt;**](RecordMatchArchiveHandlesInner.md) | List of archive handles for the record | [optional] 
**DataPath** | **string** | The path to the record in the the cloud storage. Only populated if the storage is BYOS | [optional] 
**Error** | **string** | A user friendly message for a bad request query | [optional] 
**MediaType** | **string** | The media type for the record | [optional] 
**RecordId** | **int** | The record id. This id matches the portal record-id | [optional] 
**UploadDate** | **DateTime** | Record upload timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Uuid** | **string** | The uuid for the record. This id matches the portal record id | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

