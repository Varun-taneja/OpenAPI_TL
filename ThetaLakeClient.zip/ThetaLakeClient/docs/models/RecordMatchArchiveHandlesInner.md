# Org.OpenAPITools.Model.RecordMatchArchiveHandlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | The id of the archive handle | [optional] 
**Destination** | **string** | A comma separated list of destinations where the record was sent to | [optional] 
**SentAt** | **DateTime** | When the archive operation occurred | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

