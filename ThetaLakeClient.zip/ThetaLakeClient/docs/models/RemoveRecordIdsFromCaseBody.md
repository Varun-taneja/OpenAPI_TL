# Org.OpenAPITools.Model.RemoveRecordIdsFromCaseBody

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ids** | **List&lt;decimal&gt;** | The record ids to remove from case. Max is 100 per request | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

