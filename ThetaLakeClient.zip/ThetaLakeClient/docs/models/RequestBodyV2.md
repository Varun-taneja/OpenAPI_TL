# Org.OpenAPITools.Model.RequestBodyV2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Range** | [**DateRange**](DateRange.md) |  | [optional] 
**Queries** | [**List&lt;QueryRequestV2&gt;**](QueryRequestV2.md) | Array of reconciliation queries | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

