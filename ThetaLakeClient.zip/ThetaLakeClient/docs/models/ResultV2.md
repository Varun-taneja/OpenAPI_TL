# Org.OpenAPITools.Model.ResultV2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | **string** | A user friendly message for a bad request query | [optional] 
**StatusCode** | **int** | HTTP status code of the query. When set to 400, &#x60;error&#x60; will be populated | [optional] 
**Query** | [**QueryRequestV2**](QueryRequestV2.md) |  | [optional] 
**Records** | [**List&lt;RecordMatch&gt;**](RecordMatch.md) | List of records that match the reconciliation query | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

