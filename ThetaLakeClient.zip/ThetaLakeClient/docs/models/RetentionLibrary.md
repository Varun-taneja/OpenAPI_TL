# Org.OpenAPITools.Model.RetentionLibrary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**DatumCount** | **int** | The number of datums stored in the retention library | [optional] 
**DatumSize** | **int** | The total size of all the datums in the retention library | [optional] 
**Description** | **string** | A description of the bucket | [optional] 
**DisplayName** | **string** | The retention library display name including the region | [optional] 
**ExternalId** | **string** | An external ID for the retention library | [optional] 
**Id** | **int** | Retention library ID | [optional] 
**LegalHoldCount** | **int** | The number of datums in legal hold in this retention library | [optional] 
**Name** | **string** | The name of the bucket | [optional] 
**RetentionPeriodDays** | **int** | Retention period in days | [optional] 
**RetentionPeriodEnabled** | **bool** | Indicates if a retention period policy is currently enabled | [optional] 
**RetentionSummaryText** | **string** | Summary description of the retention policy | [optional] 
**SecCompliantStorageConfirmed** | **bool** | Indicates if the SEC Rule 17a-4 compliance has been confirmed | [optional] 
**SecCompliantStorageEnabled** | **bool** | Indicates if the storage has SEC Rule 17a-4 compliance enabled | [optional] 
**StorageAccountId** | **int** | Storage account ID | [optional] 
**SwrvRuleCount** | **int** | Smart workflow review (SWRV) rules currently applied to this retention library | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

