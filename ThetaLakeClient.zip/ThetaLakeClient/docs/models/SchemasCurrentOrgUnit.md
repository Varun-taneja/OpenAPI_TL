# Org.OpenAPITools.Model.SchemasCurrentOrgUnit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArchiveOnly** | **bool** | Indicates if the org unit is archive only | [optional] 
**Id** | **int** | The ID of the current org unit | [optional] 
**Name** | **string** | The name of the current org unit | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

