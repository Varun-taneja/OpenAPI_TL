# Org.OpenAPITools.Model.SchemasParticipantInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | Participant&#39;s email, if null the content source did not provide the information | [optional] 
**Id** | **string** | The id given to the participant from the platform | [optional] 
**JoinLeaveInfo** | [**List&lt;SchemasParticipantInnerJoinLeaveInfoInner&gt;**](SchemasParticipantInnerJoinLeaveInfoInner.md) | Participant&#39;s join and leave times, if null the content source did not provide the information | [optional] 
**Name** | **string** | Participant&#39;s first name, if null the content source did not provide the information | [optional] 
**OrgRelationship** | **string** | Participant&#39;s org relationship, if null the content source did not indicate | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

