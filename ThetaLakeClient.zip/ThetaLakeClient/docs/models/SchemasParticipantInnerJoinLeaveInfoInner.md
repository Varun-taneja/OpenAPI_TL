# Org.OpenAPITools.Model.SchemasParticipantInnerJoinLeaveInfoInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**JoinTime** | **DateTime** | Participant&#39;s join time using [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**LeaveTime** | **DateTime** | Participant&#39;s leave time using [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

