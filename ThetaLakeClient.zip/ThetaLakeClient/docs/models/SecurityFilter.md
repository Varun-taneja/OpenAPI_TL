# Org.OpenAPITools.Model.SecurityFilter

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SearchId** | **int** | The ID of the search used for the user&#39;s security filter | [optional] 
**Name** | **string** | The name of the security filter | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

