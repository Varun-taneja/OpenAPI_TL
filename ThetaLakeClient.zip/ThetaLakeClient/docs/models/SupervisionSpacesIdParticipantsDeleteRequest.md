# Org.OpenAPITools.Model.SupervisionSpacesIdParticipantsDeleteRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdentityIds** | **List&lt;int&gt;** | An array of participant&#39;s identity IDs to remove from the supervision space | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

