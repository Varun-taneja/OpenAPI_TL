# Org.OpenAPITools.Model.SupervisionSpacesIdParticipantsPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParticipantsText** | **string** | A semi-CSV style list of newline separated name, email, or phone numbers that are associated with an identity | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

