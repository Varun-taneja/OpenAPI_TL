# Org.OpenAPITools.Model.SupervisionSpacesSchemasParticipant

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | The participant&#39;s email address | [optional] 
**IdentityId** | **int** | The participant&#39;s ID | [optional] 
**IsSubmitter** | **bool** | Indicates if the participant did submit data | [optional] 
**Name** | **string** | The participant&#39;s name | [optional] 
**PhoneNumber** | **string** | The participant&#39;s phone number | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

