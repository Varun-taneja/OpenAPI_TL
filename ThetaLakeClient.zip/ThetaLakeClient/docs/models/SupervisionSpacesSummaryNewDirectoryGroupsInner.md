# Org.OpenAPITools.Model.SupervisionSpacesSummaryNewDirectoryGroupsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | The directory group&#39;s ID | [optional] 
**Name** | **string** | Name of the directory group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

