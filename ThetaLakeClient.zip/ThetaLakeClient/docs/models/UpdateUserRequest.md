# Org.OpenAPITools.Model.UpdateUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The user&#39;s name | [optional] 
**Email** | **string** | The email address associated with this user | [optional] 
**RoleId** | **int** | The ID of the role that will be assigned to the new user | [optional] 
**SearchId** | **int** | The ID of the search used for the user&#39;s security filter | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

