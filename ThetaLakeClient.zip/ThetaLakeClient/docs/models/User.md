# Org.OpenAPITools.Model.User

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentOrgUnit** | [**UserCurrentOrgUnit**](UserCurrentOrgUnit.md) |  | [optional] 
**Disabled** | **bool** | Indicates if the user is disabled | [optional] 
**Email** | **string** | The user&#39;s email address | [optional] 
**LastLogin** | **DateTime** | The user&#39;s last login timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Name** | **string** | The user&#39;s name | [optional] 
**Role** | **string** | The user&#39;s role | [optional] 
**RoleId** | **int** | The ID of the user&#39;s role | [optional] 
**UserId** | **int** | The user&#39;s ID | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

