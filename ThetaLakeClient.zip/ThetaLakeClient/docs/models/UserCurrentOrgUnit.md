# Org.OpenAPITools.Model.UserCurrentOrgUnit
The user's current org unit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArchiveOnly** | **bool** | Indicates if this org unit is archive Only | [optional] 
**Id** | **int** | The ID of the current org unit | [optional] 
**Name** | **string** | The name of current org unit | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

