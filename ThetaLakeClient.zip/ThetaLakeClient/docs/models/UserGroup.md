# Org.OpenAPITools.Model.UserGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categories** | [**List&lt;CategoriesInner&gt;**](CategoriesInner.md) | An array of categories | [optional] 
**CreatedAt** | **DateTime** | The created timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Description** | **string** | The user group&#39;s description | [optional] 
**ExternalId** | **string** | An eternal ID for the user group | [optional] 
**Name** | **string** | The user group&#39;s name | [optional] 
**UpdatedAt** | **DateTime** | The updated timestamp using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**Id** | **int** | The user group&#39;s ID | [optional] 
**Users** | [**List&lt;UsersInner&gt;**](UsersInner.md) | An array of the users in this group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

