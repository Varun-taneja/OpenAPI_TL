# Org.OpenAPITools.Model.UsersInnerCurrentOrgUnit
The user's current org unit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArchiveOnly** | **bool** | Indicates if the org unit is archive only | [optional] 
**Id** | **int** | The org unit&#39;s ID | [optional] 
**Name** | **string** | The org unit&#39;s name | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

