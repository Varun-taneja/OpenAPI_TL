# Org.OpenAPITools.Model.VerizonInstalledUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PhoneNumber** | **string** | The installed user&#39;s Verizon phone_number | [optional] 
**ProvisionedDate** | **DateTime** | The date the Verizon user was provisioned using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

