# Org.OpenAPITools.Model.Workflow

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime** | Timestamp when the workflow was created at using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**CreatorUserId** | **int** | The user ID of who created the workflow | [optional] 
**Description** | **string** | Description of the workflow | [optional] 
**Id** | **int** | The ID of the workflow | [optional] 
**Name** | **string** | The name of the workflow | [optional] 
**RecordsClosed** | **int** | The number of records closed in the workflow | [optional] 
**RecordsInProgress** | **int** | The number of records in progress in the workflow | [optional] 
**RecordsOpen** | **int** | The number of records open in the workflow | [optional] 
**SwrvCount** | **int** | The number of smart workflow rules applicable to the workflow | [optional] 
**UpdatedAt** | **DateTime** | Timestamp when the workflow was last updated at using the [RFC3339 date-time format](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | [optional] 
**WorkflowType** | **WorkflowType** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

