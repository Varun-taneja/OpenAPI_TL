# Org.OpenAPITools.Model.WorkflowState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Actions** | [**List&lt;WorkflowAction&gt;**](WorkflowAction.md) | List of actions in this workflow state | [optional] 
**Description** | **string** | Description of the workflow state | [optional] 
**Id** | **int** | The ID of the workflow state | [optional] 
**Name** | **string** | The name of the workflow state | [optional] 
**WorkflowStateEvents** | [**List&lt;WorkflowStateEvent&gt;**](WorkflowStateEvent.md) | The events configured for this workflow state | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

