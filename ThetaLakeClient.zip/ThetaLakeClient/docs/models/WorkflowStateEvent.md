# Org.OpenAPITools.Model.WorkflowStateEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventType** | **string** | The event type | [optional] 
**ExternalEmail** | **string** | The external email address associated with the event | [optional] 
**Id** | **int** | The ID of the event | [optional] 
**Message** | **string** | Message content for the event | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

