using Microsoft.AspNetCore.Mvc;
using ThetaLakeProxyApi.Models.ThetaLake;
using ThetaLakeProxyApi.Services;

namespace ThetaLakeProxyApi.Controllers;

[ApiController]
[Route("api/thetalake")]
public class ThetaLakeController : ControllerBase
{
    private readonly IThetaLakeApiClient _client;
    private readonly ILogger<ThetaLakeController> _logger;
    public ThetaLakeController(IThetaLakeApiClient client, ILogger<ThetaLakeController> logger)
    {
        _client = client;
        _logger = logger;
    }

    [HttpPost("reconciliation/count")]
    public async Task<ActionResult<ReconciliationCountResponse>> Count([FromBody] ReconciliationCountRequest request, CancellationToken ct)
        => Ok(await _client.ReconciliationCountAsync(request, ct));

    [HttpPost("reconciliation/new")]
    public async Task<ActionResult<ReconciliationNewResponse>> New([FromBody] ReconciliationNewRequest request, CancellationToken ct)
        => Ok(await _client.ReconciliationNewAsync(request, ct));

    [HttpGet("integrations")]
    public async Task<ActionResult<IntegrationsResponse>> Integrations(CancellationToken ct)
        => Ok(await _client.GetIntegrationsAsync(ct));
}
