using MediatR;

namespace ThetaLakeProxyApi.Events;

public sealed record MessagesCollectedEvent(string OutputFile, System.DateTimeOffset WindowStartUtc, System.DateTimeOffset WindowEndUtc, int TotalMessages) : INotification;
