namespace ThetaLakeProxyApi.Models.Graph;

public sealed class MinimalChatMessage
{
    public string? Id { get; set; }
    public string? MessageType { get; set; }
    public DateTimeOffset? CreatedDateTime { get; set; }
    public DateTimeOffset? LastModifiedDateTime { get; set; }
    public string? ChatId { get; set; }
    public string? UserPrincipalName { get; set; }
}
