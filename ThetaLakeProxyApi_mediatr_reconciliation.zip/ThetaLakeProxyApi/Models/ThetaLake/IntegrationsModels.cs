using System.Text.Json.Serialization;

namespace ThetaLakeProxyApi.Models.ThetaLake;

public sealed class IntegrationsResponse
{
    [JsonPropertyName("status_code")] public int Status_Code { get; set; }
    [JsonPropertyName("status_string")] public string? Status_String { get; set; }
    [JsonPropertyName("request_id")] public string? Request_Id { get; set; }
    [JsonPropertyName("integrations")] public List<Integration> Integrations { get; set; } = new();
}
public sealed class Integration
{
    [JsonPropertyName("access_token_expiration_date")] public DateTimeOffset? Access_Token_Expiration_Date { get; set; }
    [JsonPropertyName("account_user_email")] public string? Account_User_Email { get; set; }
    [JsonPropertyName("account_user_id")] public string? Account_User_Id { get; set; }
    [JsonPropertyName("created_at")] public DateTimeOffset Created_At { get; set; }
    [JsonPropertyName("description")] public string? Description { get; set; }
    [JsonPropertyName("has_integration_policy")] public bool Has_Integration_Policy { get; set; }
    [JsonPropertyName("id")] public string Id { get; set; } = string.Empty;
    [JsonPropertyName("integration_group")] public string Integration_Group { get; set; } = string.Empty;
    [JsonPropertyName("integration_policy_id")] public string? Integration_Policy_Id { get; set; }
    [JsonPropertyName("integration_type")] public string Integration_Type { get; set; } = string.Empty;
    [JsonPropertyName("integration_type_id")] public string Integration_Type_Id { get; set; } = string.Empty;
    [JsonPropertyName("last_upload_at")] public DateTimeOffset? Last_Upload_At { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = string.Empty;
    [JsonPropertyName("not_before_date")] public DateTimeOffset? Not_Before_Date { get; set; }
    [JsonPropertyName("notify_submitter")] public bool Notify_Submitter { get; set; }
    [JsonPropertyName("scopes_changed")] public bool Scopes_Changed { get; set; }
    [JsonPropertyName("service_last_run_at")] public DateTimeOffset? Service_Last_Run_At { get; set; }
    [JsonPropertyName("service_paused")] public string Service_Paused { get; set; } = string.Empty;
    [JsonPropertyName("service_status")] public string Service_Status { get; set; } = string.Empty;
    [JsonPropertyName("status")] public string Status { get; set; } = string.Empty;
    [JsonPropertyName("status_color")] public string Status_Color { get; set; } = string.Empty;
    [JsonPropertyName("updated_at")] public DateTimeOffset? Updated_At { get; set; }
    [JsonPropertyName("uploads_last_30_days")] public string? Uploads_Last_30_Days { get; set; }
    [JsonPropertyName("user")] public IntegrationUser? User { get; set; }
}
public sealed class IntegrationUser
{
    [JsonPropertyName("email")] public string Email { get; set; } = string.Empty;
    [JsonPropertyName("id")] public string Id { get; set; } = string.Empty;
    [JsonPropertyName("name")] public string Name { get; set; } = string.Empty;
}
