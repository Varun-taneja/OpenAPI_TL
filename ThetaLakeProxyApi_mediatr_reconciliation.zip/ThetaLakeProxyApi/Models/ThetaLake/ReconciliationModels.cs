using System.Text.Json.Serialization;

namespace ThetaLakeProxyApi.Models.ThetaLake;

public enum DateRangeType { create_date, upload_date }
public enum MediaType { audio, chat, document, email, other, video }

public sealed class ReconciliationCountRequest
{
    [JsonPropertyName("platform")] public string Platform { get; set; } = "microsoft-teams";
    [JsonPropertyName("type")] public DateRangeType Type { get; set; } = DateRangeType.create_date;
    [JsonPropertyName("start")] public DateTimeOffset Start { get; set; }
    [JsonPropertyName("end")] public DateTimeOffset? End { get; set; }
}

public sealed class ReconciliationCountResponse
{
    [JsonPropertyName("status_code")] public int Status_Code { get; set; }
    [JsonPropertyName("status_string")] public string? Status_String { get; set; }
    [JsonPropertyName("request_id")] public string? Request_Id { get; set; }
    [JsonPropertyName("result")] public ReconciliationCountResult? Result { get; set; }
}
public sealed class ReconciliationCountResult
{
    [JsonPropertyName("platform")] public string? Platform { get; set; }
    [JsonPropertyName("start")] public DateTimeOffset Start { get; set; }
    [JsonPropertyName("end")] public DateTimeOffset? End { get; set; }
    [JsonPropertyName("type")] public DateRangeType Type { get; set; }
    [JsonPropertyName("count")] public double Count { get; set; }
}

public sealed class ReconciliationNewRequest
{
    [JsonPropertyName("range")] public ReconciliationRange? Range { get; set; }
    [JsonPropertyName("queries")] public List<ReconciliationQuery> Queries { get; set; } = new();
}
public sealed class ReconciliationRange
{
    [JsonPropertyName("type")] public DateRangeType Type { get; set; } = DateRangeType.upload_date;
    [JsonPropertyName("start")] public DateTimeOffset Start { get; set; }
    [JsonPropertyName("end")] public DateTimeOffset End { get; set; }
}
public sealed class AttributeKV { [JsonPropertyName("name")] public string Name { get; set; } = string.Empty; [JsonPropertyName("value")] public string Value { get; set; } = string.Empty; }
public sealed class ReconciliationQuery
{
    [JsonPropertyName("platform")] public string Platform { get; set; } = "microsoft-teams";
    [JsonPropertyName("attribute")] public AttributeKV Attribute { get; set; } = new();
    [JsonPropertyName("includes_timestamp")] public DateTimeOffset? Includes_Timestamp { get; set; }
    [JsonPropertyName("media_types")] public List<MediaType>? Media_Types { get; set; }
}

public sealed class ReconciliationNewResponse
{
    [JsonPropertyName("status_code")] public int Status_Code { get; set; }
    [JsonPropertyName("status_string")] public string? Status_String { get; set; }
    [JsonPropertyName("request_id")] public string? Request_Id { get; set; }
    [JsonPropertyName("results")] public ReconciliationNewResults? Results { get; set; }
}
public sealed class ReconciliationNewResults
{
    [JsonPropertyName("total_hits")] public int Total_Hits { get; set; }
    [JsonPropertyName("range")] public ReconciliationRange? Range { get; set; }
    [JsonPropertyName("hits")] public List<ReconciliationHit> Hits { get; set; } = new();
}
public sealed class ReconciliationHit
{
    [JsonPropertyName("error")] public string? Error { get; set; }
    [JsonPropertyName("status_code")] public int Status_Code { get; set; }
    [JsonPropertyName("query")] public ReconciliationQuery? Query { get; set; }
    [JsonPropertyName("records")] public List<ReconciliationRecord> Records { get; set; } = new();
}
public sealed class ArchiveHandle
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("destination")] public string? Destination { get; set; }
    [JsonPropertyName("sent_at")] public DateTimeOffset? Sent_At { get; set; }
}
public sealed class ReconciliationRecord
{
    [JsonPropertyName("archive_handles")] public List<ArchiveHandle>? Archive_Handles { get; set; }
    [JsonPropertyName("data_path")] public string? Data_Path { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
    [JsonPropertyName("media_type")] public MediaType Media_Type { get; set; }
    [JsonPropertyName("record_id")] public int Record_Id { get; set; }
    [JsonPropertyName("upload_date")] public DateTimeOffset Upload_Date { get; set; }
    [JsonPropertyName("uuid")] public string? Uuid { get; set; }
}
