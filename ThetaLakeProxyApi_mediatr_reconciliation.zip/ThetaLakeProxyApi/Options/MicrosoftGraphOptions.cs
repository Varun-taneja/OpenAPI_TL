namespace ThetaLakeProxyApi.Options;

public sealed class MicrosoftGraphOptions
{
    public string TenantId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string Scope { get; set; } = "https://graph.microsoft.com/.default";
    public string UserListFile { get; set; } = "userlist.json";
    public string OutputDirectory { get; set; } = "data";
    public int DailyRunHourUtc { get; set; } = 2;
    public int WindowHours { get; set; } = 24;
}
