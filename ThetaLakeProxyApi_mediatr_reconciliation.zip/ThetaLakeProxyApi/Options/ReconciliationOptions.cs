namespace ThetaLakeProxyApi.Options;

public sealed class ReconciliationOptions
{
    public string OutputDirectory { get; set; } = "reconciliation";
}
