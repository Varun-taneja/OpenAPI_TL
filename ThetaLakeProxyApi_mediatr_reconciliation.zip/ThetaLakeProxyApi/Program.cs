using System.Net;
using MediatR;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Polly;
using Polly.Contrib.WaitAndRetry;
using ThetaLakeProxyApi.Options;
using ThetaLakeProxyApi.Services;
using ThetaLakeProxyApi.Services.Graph;
using ThetaLakeProxyApi.Services.Reconciliation;

var builder = WebApplication.CreateBuilder(args);

// Options
builder.Services.Configure<ThetaLakeOptions>(builder.Configuration.GetSection("ThetaLake"));
builder.Services.Configure<MicrosoftGraphOptions>(builder.Configuration.GetSection("MicrosoftGraph"));
builder.Services.Configure<ReconciliationOptions>(builder.Configuration.GetSection("Reconciliation"));

// MediatR
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblyContaining<Program>());

// Controllers & Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Health checks
builder.Services.AddHealthChecks();

// Logging is configured via appsettings.json (default)

// Polly policies (retry with jitter, 429-aware)
var delay = Backoff.DecorrelatedJitterBackoffV2(TimeSpan.FromSeconds(1), 5);
var retry = Policy<HttpResponseMessage>.HandleResult(r => (int)r.StatusCode >= 500 || r.StatusCode == HttpStatusCode.TooManyRequests)
    .Or<HttpRequestException>()
    .WaitAndRetryAsync(delay);

var timeout = Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30));

var policyWrap = Policy.WrapAsync(retry, timeout);

// HttpClients
builder.Services.AddHttpClient("ThetaLake")
    .AddPolicyHandler(policyWrap);

builder.Services.AddHttpClient("Graph")
    .AddPolicyHandler(policyWrap);

// DI
builder.Services.AddSingleton<IThetaLakeTokenService, ThetaLakeTokenService>();
builder.Services.AddSingleton<IThetaLakeApiClient, ThetaLakeApiClient>();

builder.Services.AddSingleton<IGraphTokenService, GraphTokenService>();
builder.Services.AddSingleton<GraphMessageCollector>();

builder.Services.AddHostedService<TeamsMessageCollectorService>();

builder.Services.AddSingleton<ReconciliationService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();

app.MapHealthChecks("/health");
app.MapHealthChecks("/healthz", new HealthCheckOptions());

app.Run();
