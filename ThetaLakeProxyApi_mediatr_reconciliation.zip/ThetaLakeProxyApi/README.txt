Build & Run
-----------
1) Set ThetaLake and Graph credentials in appsettings.json
2) dotnet restore
3) dotnet run
- Swagger at /swagger
- Health at /health

Flow
----
- TeamsMessageCollectorService runs daily at MicrosoftGraph:DailyRunHourUtc UTC
- GraphMessageCollector writes minimal messages json to MicrosoftGraph:OutputDirectory
- Immediately publishes MessagesCollectedEvent via MediatR
- MessagesCollectedHandler invokes ReconciliationService
- ReconciliationService dedups by message id, groups by chatId, batches 500 queries per call:
  attribute: chat_id, media_types: [chat], includes_timestamp per message, range type=create_date with same window as Graph.
- Writes missing messages to Reconciliation:OutputDirectory as missed-messages-*.json
