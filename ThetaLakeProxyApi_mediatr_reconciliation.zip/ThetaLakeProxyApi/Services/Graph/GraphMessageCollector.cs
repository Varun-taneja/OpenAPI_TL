using System.Text.Json;
using System.Web;
using MediatR;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Events;
using ThetaLakeProxyApi.Models.Graph;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Graph;

public sealed class GraphMessageCollector
{
    private readonly IHttpClientFactory _http;
    private readonly IGraphTokenService _token;
    private readonly MicrosoftGraphOptions _opts;
    private readonly ILogger<GraphMessageCollector> _logger;
    private readonly IMediator _mediator;

    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };

    public GraphMessageCollector(IHttpClientFactory http, IGraphTokenService token, IOptions<MicrosoftGraphOptions> options, ILogger<GraphMessageCollector> logger, IMediator mediator)
    {
        _http = http;
        _token = token;
        _opts = options.Value;
        _logger = logger;
        _mediator = mediator;
    }

    public async Task<string> CollectAsync(CancellationToken ct)
    {
        var outDir = Path.Combine(AppContext.BaseDirectory, _opts.OutputDirectory);
        Directory.CreateDirectory(outDir);

        var windowEndUtc = DateTimeOffset.UtcNow;
        var windowStartUtc = windowEndUtc.AddHours(-_opts.WindowHours);

        var userListPath = Path.Combine(AppContext.BaseDirectory, _opts.UserListFile);
        var upns = File.Exists(userListPath) ? (await File.ReadAllLinesAsync(userListPath, ct)).Where(l => !string.IsNullOrWhiteSpace(l)).ToList() : new List<string>();
        if (upns.Count == 0)
        {
            _logger.LogWarning("No UPNs in user list file {File}", userListPath);
            return string.Empty;
        }

        var token = await _token.GetTokenAsync(ct);
        var client = _http.CreateClient("Graph");
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var all = new List<MinimalChatMessage>();

        foreach (var upn in upns)
        {
            var url = $"https://graph.microsoft.com/v1.0/users/{HttpUtility.UrlEncode(upn)}/chats/getAllMessages?$top=50&$filter=lastModifiedDateTime gt {windowStartUtc:O} and lastModifiedDateTime lt {windowEndUtc:O}";
            while (!ct.IsCancellationRequested && !string.IsNullOrEmpty(url))
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                using var res = await client.SendAsync(req, ct);
                res.EnsureSuccessStatusCode();
                using var s = await res.Content.ReadAsStreamAsync(ct);
                using var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);

                if (doc.RootElement.TryGetProperty("value", out var arr) && arr.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    foreach (var el in arr.EnumerateArray())
                    {
                        all.Add(new MinimalChatMessage
                        {
                            Id = el.TryGetProperty("id", out var vId) ? vId.GetString() : null,
                            MessageType = el.TryGetProperty("messageType", out var vMt) ? vMt.GetString() : null,
                            CreatedDateTime = el.TryGetProperty("createdDateTime", out var vCd) ? vCd.GetDateTimeOffset() : (DateTimeOffset?)null,
                            LastModifiedDateTime = el.TryGetProperty("lastModifiedDateTime", out var vMd) ? vMd.GetDateTimeOffset() : (DateTimeOffset?)null,
                            ChatId = el.TryGetProperty("chatId", out var vCh) ? vCh.GetString() : null,
                            UserPrincipalName = upn
                        });
                    }
                }

                url = doc.RootElement.TryGetProperty("@odata.nextLink", out var next) ? next.GetString() ?? string.Empty : string.Empty;
            }
        }

        // Only keep minimal fields and write once
        var outFile = Path.Combine(outDir, $"teams-messages-{DateTime.UtcNow:yyyyMMddHHmmss}.json");
        await File.WriteAllTextAsync(outFile, JsonSerializer.Serialize(all, new JsonSerializerOptions { WriteIndented = true }), ct);
        _logger.LogInformation("Wrote {Count} messages to {File}", all.Count, outFile);

        // Publish event to trigger reconciliation immediately
        await _mediator.Publish(new MessagesCollectedEvent(outFile, windowStartUtc, windowEndUtc, all.Count), ct);
        _logger.LogInformation("Published MessagesCollectedEvent for {File}", outFile);

        return outFile;
    }
}
