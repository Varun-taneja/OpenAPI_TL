using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Graph;

public interface IGraphTokenService
{
    Task<string> GetTokenAsync(CancellationToken ct);
}

public sealed class GraphTokenService : IGraphTokenService
{
    private readonly IHttpClientFactory _http;
    private readonly MicrosoftGraphOptions _opts;
    private string? _cached;
    private DateTimeOffset _exp;

    public GraphTokenService(IHttpClientFactory http, IOptions<MicrosoftGraphOptions> options)
    {
        _http = http;
        _opts = options.Value;
    }

    public async Task<string> GetTokenAsync(CancellationToken ct)
    {
        if (!string.IsNullOrEmpty(_cached) && _exp > DateTimeOffset.UtcNow.AddMinutes(1))
            return _cached!;

        var client = _http.CreateClient("Graph");
        var url = $"https://login.microsoftonline.com/{_opts.TenantId}/oauth2/v2.0/token";
        var form = new Dictionary<string, string>
        {
            ["client_id"] = _opts.ClientId,
            ["client_secret"] = _opts.ClientSecret,
            ["scope"] = _opts.Scope,
            ["grant_type"] = "client_credentials"
        };
        using var req = new HttpRequestMessage(HttpMethod.Post, url) { Content = new FormUrlEncodedContent(form) };
        var res = await client.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        using var s = await res.Content.ReadAsStreamAsync(ct);
        var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);
        _cached = doc.RootElement.GetProperty("access_token").GetString();
        var expiresIn = doc.RootElement.TryGetProperty("expires_in", out var e) ? e.GetInt32() : 3600;
        _exp = DateTimeOffset.UtcNow.AddSeconds(expiresIn);
        return _cached!;
    }
}
