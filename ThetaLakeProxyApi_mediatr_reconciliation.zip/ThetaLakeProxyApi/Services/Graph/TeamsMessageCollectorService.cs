using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Graph;

public sealed class TeamsMessageCollectorService : BackgroundService
{
    private readonly GraphMessageCollector _collector;
    private readonly MicrosoftGraphOptions _opts;
    private readonly ILogger<TeamsMessageCollectorService> _logger;

    public TeamsMessageCollectorService(GraphMessageCollector collector, IOptions<MicrosoftGraphOptions> options, ILogger<TeamsMessageCollectorService> logger)
    {
        _collector = collector;
        _opts = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var nowUtc = DateTimeOffset.UtcNow;
            var nextRun = new DateTimeOffset(nowUtc.Year, nowUtc.Month, nowUtc.Day, _opts.DailyRunHourUtc, 0, 0, TimeSpan.Zero);
            if (nowUtc >= nextRun) nextRun = nextRun.AddDays(1);
            var delay = nextRun - nowUtc;
            _logger.LogInformation("TeamsMessageCollectorService sleeping for {Delay} until {NextRun}", delay, nextRun);
            try { await Task.Delay(delay, stoppingToken); } catch (TaskCanceledException) { break; }
            try
            {
                _logger.LogInformation("Starting Graph message collection...");
                await _collector.CollectAsync(stoppingToken);
                _logger.LogInformation("Graph message collection finished.");
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                _logger.LogWarning("Collector cancelled.");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Graph message collection failed.");
            }
        }
    }
}
