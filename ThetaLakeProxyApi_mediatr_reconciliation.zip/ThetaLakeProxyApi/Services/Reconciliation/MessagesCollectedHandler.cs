using MediatR;
using ThetaLakeProxyApi.Events;

namespace ThetaLakeProxyApi.Services.Reconciliation;

public sealed class MessagesCollectedHandler : INotificationHandler<MessagesCollectedEvent>
{
    private readonly ReconciliationService _svc;
    private readonly ILogger<MessagesCollectedHandler> _logger;

    public MessagesCollectedHandler(ReconciliationService svc, ILogger<MessagesCollectedHandler> logger)
    {
        _svc = svc;
        _logger = logger;
    }

    public async Task Handle(MessagesCollectedEvent notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation("MessagesCollectedEvent received. Starting reconciliation for file {File}", notification.OutputFile);
        try
        {
            await _svc.ReconcileAsync(notification.OutputFile, notification.WindowStartUtc, notification.WindowEndUtc, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _logger.LogWarning("Reconciliation cancelled.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Reconciliation run failed.");
        }
    }
}
