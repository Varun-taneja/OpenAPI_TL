using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Models.Graph;
using ThetaLakeProxyApi.Models.ThetaLake;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Reconciliation;

public sealed class ReconciliationService
{
    private readonly IThetaLakeApiClient _theta;
    private readonly ILogger<ReconciliationService> _logger;
    private readonly ReconciliationOptions _opts;

    private static readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };

    public ReconciliationService(IThetaLakeApiClient theta, IOptions<ReconciliationOptions> options, ILogger<ReconciliationService> logger)
    {
        _theta = theta;
        _logger = logger;
        _opts = options.Value;
    }

    public async Task<int> ReconcileAsync(string inputFile, DateTimeOffset windowStartUtc, DateTimeOffset windowEndUtc, CancellationToken ct)
    {
        if (!File.Exists(inputFile))
        {
            _logger.LogWarning("Reconciliation skipped: input file not found: {File}", inputFile);
            return 0;
        }

        var outDir = Path.Combine(AppContext.BaseDirectory, _opts.OutputDirectory);
        Directory.CreateDirectory(outDir);
        var missedOut = Path.Combine(outDir, $"missed-messages-{DateTime.UtcNow:yyyyMMddHHmmss}.json");

        var content = await File.ReadAllTextAsync(inputFile, ct);
        var all = JsonSerializer.Deserialize<List<MinimalChatMessage>>(content, _jsonOptions) ?? new();

        // Deduplicate by Graph message Id across users
        var dedup = all.Where(m => !string.IsNullOrWhiteSpace(m.Id)).GroupBy(m => m.Id!).Select(g => g.First()).ToList();

        // Group by chatId
        var byChat = dedup.Where(m => !string.IsNullOrWhiteSpace(m.ChatId)).GroupBy(m => m.ChatId!).ToList();

        var missed = new List<MinimalChatMessage>();
        foreach (var grp in byChat)
        {
            var chatId = grp.Key;
            var msgs = grp.ToList();

            // For counting parity check
            var countReq = new ReconciliationCountRequest
            {
                Platform = "microsoft-teams",
                Type = DateRangeType.create_date,
                Start = windowStartUtc,
                End = windowEndUtc
            };

            try { await _theta.ReconciliationCountAsync(countReq, ct); } catch (Exception ex) { _logger.LogWarning(ex, "Count call failed (non-blocking) for chat {ChatId}", chatId); }

            // Batch into queries of 500 (TL limit)
            var batches = msgs.Chunk(500);
            foreach (var batch in batches)
            {
                var req = new ReconciliationNewRequest
                {
                    Range = new ReconciliationRange
                    {
                        Type = DateRangeType.create_date, // same window as requested to Graph
                        Start = windowStartUtc,
                        End = windowEndUtc
                    },
                    Queries = batch.Select(m => new ReconciliationQuery
                    {
                        Platform = "microsoft-teams",
                        Attribute = new AttributeKV { Name = "chat_id", Value = chatId },
                        Includes_Timestamp = m.LastModifiedDateTime ?? m.CreatedDateTime,
                        Media_Types = new List<MediaType> { MediaType.chat }
                    }).ToList()
                };

                ReconciliationNewResponse res;
                try
                {
                    res = await _theta.ReconciliationNewAsync(req, ct);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Reconciliation API failed for chat {ChatId}", chatId);
                    // Mark entire batch as missed (conservative) and continue
                    missed.AddRange(batch);
                    continue;
                }

                // Match response hits to batch items by query order
                var hits = res.Results?.Hits ?? new List<ReconciliationHit>();
                for (int i = 0; i < batch.Length; i++)
                {
                    var msg = batch[i];
                    var hit = i < hits.Count ? hits[i] : null;

                    var found = hit != null && hit.Status_Code == 200 && (hit.Records?.Count ?? 0) > 0;
                    if (!found)
                    {
                        missed.Add(msg);
                    }
                }
            }
        }

        await File.WriteAllTextAsync(missedOut, JsonSerializer.Serialize(missed, new JsonSerializerOptions { WriteIndented = true }), ct);
        _logger.LogInformation("Reconciliation completed. {Missed} messages missing. Output: {File}", missed.Count, missedOut);
        return missed.Count;
    }
}
