using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Models.ThetaLake;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services;

public interface IThetaLakeApiClient
{
    Task<ReconciliationCountResponse> ReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct);
    Task<ReconciliationNewResponse> ReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct);
    Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct);
}

public sealed class ThetaLakeApiClient : IThetaLakeApiClient
{
    private readonly IHttpClientFactory _http;
    private readonly IThetaLakeTokenService _tokenSvc;
    private readonly ThetaLakeOptions _opts;
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    public ThetaLakeApiClient(IHttpClientFactory http, IThetaLakeTokenService tokenSvc, IOptions<ThetaLakeOptions> options)
    {
        _http = http;
        _tokenSvc = tokenSvc;
        _opts = options.Value;
    }

    private async Task<HttpRequestMessage> CreateRequestAsync(HttpMethod method, string path, object? body, CancellationToken ct)
    {
        var token = await _tokenSvc.GetTokenAsync(ct);
        var req = new HttpRequestMessage(method, $"{_opts.BaseURL.TrimEnd('/')}{path}");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        if (body != null)
        {
            req.Content = new StringContent(JsonSerializer.Serialize(body, _json), Encoding.UTF8, "application/json");
        }
        return req;
    }

    public async Task<ReconciliationCountResponse> ReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct)
    {
        var client = _http.CreateClient("ThetaLake");
        using var req = await CreateRequestAsync(HttpMethod.Post, "/reconciliation/count", request, ct);
        using var res = await client.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        var stream = await res.Content.ReadAsStreamAsync(ct);
        return (await JsonSerializer.DeserializeAsync<ReconciliationCountResponse>(stream, _json, ct))!;
    }

    public async Task<ReconciliationNewResponse> ReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct)
    {
        var client = _http.CreateClient("ThetaLake");
        using var req = await CreateRequestAsync(HttpMethod.Post, "/reconciliation/new", request, ct);
        using var res = await client.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        var stream = await res.Content.ReadAsStreamAsync(ct);
        return (await JsonSerializer.DeserializeAsync<ReconciliationNewResponse>(stream, _json, ct))!;
    }

    public async Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct)
    {
        var client = _http.CreateClient("ThetaLake");
        using var req = await CreateRequestAsync(HttpMethod.Get, "/integrations", null, ct);
        using var res = await client.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        var stream = await res.Content.ReadAsStreamAsync(ct);
        return (await JsonSerializer.DeserializeAsync<IntegrationsResponse>(stream, _json, ct))!;
    }
}
