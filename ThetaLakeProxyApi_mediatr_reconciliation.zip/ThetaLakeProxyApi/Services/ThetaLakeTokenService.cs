using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services;

public interface IThetaLakeTokenService
{
    Task<string> GetTokenAsync(CancellationToken ct);
}

public sealed class ThetaLakeTokenService : IThetaLakeTokenService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ThetaLakeOptions _opts;
    private string? _cachedToken;
    private DateTimeOffset _expiresAt;

    public ThetaLakeTokenService(IHttpClientFactory httpClientFactory, IOptions<ThetaLakeOptions> options)
    {
        _httpClientFactory = httpClientFactory;
        _opts = options.Value;
    }

    public async Task<string> GetTokenAsync(CancellationToken ct)
    {
        if (!string.IsNullOrWhiteSpace(_cachedToken) && _expiresAt > DateTimeOffset.UtcNow.AddMinutes(1))
            return _cachedToken!;

        var client = _httpClientFactory.CreateClient("ThetaLake");
        var payload = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _opts.ClientID,
            ["client_secret"] = _opts.ClientSecret
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, _opts.ClientURL)
        {
            Content = new FormUrlEncodedContent(payload)
        };

        var res = await client.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        using var s = await res.Content.ReadAsStreamAsync(ct);
        var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);
        _cachedToken = doc.RootElement.GetProperty("access_token").GetString();
        var expiresIn = doc.RootElement.TryGetProperty("expires_in", out var e) ? e.GetInt32() : 3600;
        _expiresAt = DateTimeOffset.UtcNow.AddSeconds(expiresIn);
        return _cachedToken!;
    }
}
