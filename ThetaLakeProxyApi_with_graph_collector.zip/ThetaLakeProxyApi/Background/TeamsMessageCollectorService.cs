using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;
using ThetaLakeProxyApi.Services.Graph;

namespace ThetaLakeProxyApi.Background;

public sealed class TeamsMessageCollectorService : BackgroundService
{
    private readonly ILogger<TeamsMessageCollectorService> _logger;
    private readonly IServiceProvider _sp;
    private readonly MicrosoftGraphOptions _opts;

    public TeamsMessageCollectorService(ILogger<TeamsMessageCollectorService> logger, IServiceProvider sp, IOptions<MicrosoftGraphOptions> opts)
    {
        _logger = logger;
        _sp = sp;
        _opts = opts.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("TeamsMessageCollectorService started.");
        while (!stoppingToken.IsCancellationRequested)
        {
            var nowUtc = DateTimeOffset.UtcNow;
            var runAtHour = _opts.DailyRunHourUtc % 24;
            var nextRun = new DateTimeOffset(nowUtc.Year, nowUtc.Month, nowUtc.Day, runAtHour, 0, 0, TimeSpan.Zero);
            if (nowUtc > nextRun) nextRun = nextRun.AddDays(1);

            var delay = nextRun - nowUtc;
            _logger.LogInformation("Next Teams collection at {NextRun} (in {Delay})", nextRun, delay);
            try { await Task.Delay(delay, stoppingToken); } catch (TaskCanceledException) { break; }

            if (stoppingToken.IsCancellationRequested) break;

            try
            {
                using var scope = _sp.CreateScope();
                var collector = scope.ServiceProvider.GetRequiredService<GraphMessageCollector>();
                var end = DateTimeOffset.UtcNow;
                var start = end.AddHours(-Math.Max(1, _opts.WindowHours));
                var count = await collector.CollectAsync(start, end, stoppingToken);
                _logger.LogInformation("Teams collection finished: {Count} messages", count);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                _logger.LogWarning("Teams collection cancelled due to shutdown.");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Teams collection failed with error.");
            }
        }
        _logger.LogInformation("TeamsMessageCollectorService stopped.");
    }
}
