using Microsoft.AspNetCore.Mvc;
using ThetaLakeProxyApi.Services;
using ThetaLakeProxyApi.Models.ThetaLake;

namespace ThetaLakeProxyApi.Controllers;

[ApiController]
[Route("api/integrations")]
public sealed class IntegrationsController : ControllerBase
{
    private readonly IThetaLakeApiClient _client;

    public IntegrationsController(IThetaLakeApiClient client)
    {
        _client = client;
    }

    [HttpGet]
    public async Task<ActionResult<IntegrationsResponse>> Get(CancellationToken ct)
    {
        var res = await _client.GetIntegrationsAsync(ct);
        return Ok(res);
    }
}
