using Microsoft.AspNetCore.Mvc;
using ThetaLakeProxyApi.Models.ThetaLake;
using ThetaLakeProxyApi.Services;

namespace ThetaLakeProxyApi.Controllers;

[ApiController]
[Route("api/reconciliation")]
public sealed class ReconciliationController : ControllerBase
{
    private readonly IThetaLakeApiClient _client;
    private readonly ILogger<ReconciliationController> _logger;

    public ReconciliationController(IThetaLakeApiClient client, ILogger<ReconciliationController> logger)
    {
        _client = client;
        _logger = logger;
    }

    [HttpPost("count")]
    public async Task<ActionResult<ReconciliationCountResponse>> Count([FromBody] ReconciliationCountRequest request, CancellationToken ct)
    {
        var res = await _client.ReconciliationCountAsync(request, ct);
        return Ok(res);
    }

    [HttpPost("new")]
    public async Task<ActionResult<ReconciliationNewResponse>> New([FromBody] ReconciliationNewRequest request, CancellationToken ct)
    {
        var res = await _client.ReconciliationNewAsync(request, ct);
        return Ok(res);
    }
}
