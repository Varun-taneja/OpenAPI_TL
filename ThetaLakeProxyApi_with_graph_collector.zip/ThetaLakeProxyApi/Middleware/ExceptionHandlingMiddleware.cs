using System.Net;
using System.Text.Json;

namespace ThetaLakeProxyApi.Middleware;

public sealed class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        {
            _logger.LogWarning("Request cancelled by client for {Path}", context.Request.Path);
            context.Response.StatusCode = (int)HttpStatusCode.RequestTimeout;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception for {Method} {Path}", context.Request.Method, context.Request.Path);
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            var problem = new { title = "Unexpected error", status = context.Response.StatusCode, detail = ex.Message };
            await context.Response.WriteAsync(JsonSerializer.Serialize(problem));
        }
    }
}
