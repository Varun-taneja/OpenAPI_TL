namespace ThetaLakeProxyApi.Models.ThetaLake;

public sealed class IntegrationsResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public List<Integration> Integrations { get; set; } = new();
}

public sealed class Integration
{
    public string Id { get; set; } = string.Empty;
    public string Integration_Group { get; set; } = string.Empty;
    public string Integration_Type { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Status_Color { get; set; } = "#FFFFFF";
}
