using System.Text.Json.Serialization;

namespace ThetaLakeProxyApi.Models.ThetaLake;

public sealed class ReconciliationCountRequest
{
    public string Platform { get; set; } = string.Empty;
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public DateRangeType Type { get; set; } = DateRangeType.UploadDate;
    public DateTimeOffset Start { get; set; }
    public DateTimeOffset? End { get; set; }
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DateRangeType { CreateDate, UploadDate }

public sealed class ReconciliationCountResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public ReconciliationCountResult Result { get; set; } = new();
}

public sealed class ReconciliationCountResult
{
    public string Platform { get; set; } = string.Empty;
    public DateTimeOffset Start { get; set; }
    public DateTimeOffset? End { get; set; }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public DateRangeType Type { get; set; } = DateRangeType.CreateDate;
    public double Count { get; set; }
}

public sealed class ReconciliationNewRequest
{
    public ReconciliationRange? Range { get; set; }
    public List<ReconciliationQuery> Queries { get; set; } = new();
}

public sealed class ReconciliationRange
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public DateRangeType Type { get; set; } = DateRangeType.UploadDate;
    public DateTimeOffset? Start { get; set; }
    public DateTimeOffset? End { get; set; }
}

public sealed class ReconciliationQuery
{
    public string Platform { get; set; } = string.Empty;
    public AttributeKV Attribute { get; set; } = new();
    public DateTimeOffset? Includes_Timestamp { get; set; }
    public List<MediaType>? Media_Types { get; set; }
}

public sealed class AttributeKV
{
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum MediaType { audio, chat, document, email, other, video }

public sealed class ReconciliationNewResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public ReconciliationResults Results { get; set; } = new();
}

public sealed class ReconciliationResults
{
    public int Total_Hits { get; set; }
    public ReconciliationRange? Range { get; set; }
    public List<ReconciliationHit> Hits { get; set; } = new();
}

public sealed class ReconciliationHit
{
    public string? Error { get; set; }
    public int Status_Code { get; set; }
    public ReconciliationQuery Query { get; set; } = new();
    public List<ReconciliationRecord> Records { get; set; } = new();
}

public sealed class ReconciliationRecord
{
    public List<ArchiveHandle> Archive_Handles { get; set; } = new();
    public string? Data_Path { get; set; }
    public string? Error { get; set; }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public MediaType Media_Type { get; set; }
    public int Record_Id { get; set; }
    public DateTimeOffset Upload_Date { get; set; }
    public string Uuid { get; set; } = string.Empty;
}

public sealed class ArchiveHandle
{
    public int Id { get; set; }
    public string Destination { get; set; } = string.Empty;
    public DateTimeOffset Sent_At { get; set; }
}
