using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Polly;
using Polly.Extensions.Http;
using Polly.Timeout;
using ThetaLakeProxyApi.Middleware;
using ThetaLakeProxyApi.Options;
using ThetaLakeProxyApi.Services;
using ThetaLakeProxyApi.Services.Graph;
using ThetaLakeProxyApi.Background;

var builder = WebApplication.CreateBuilder(args);

// Options
builder.Services.Configure<ThetaLakeOptions>(builder.Configuration.GetSection("ThetaLake"));
builder.Services.Configure<MicrosoftGraphOptions>(builder.Configuration.GetSection("MicrosoftGraph"));

// Health checks
builder.Services.AddHealthChecks()
    .AddCheck("self", () => HealthCheckResult.Healthy("OK"))
    .AddUrlGroup(new Uri(builder.Configuration["ThetaLake:BaseURL"] ?? "https://api.thetalake.com/api/v1"), name: "thetalake-api", failureStatus: HealthStatus.Degraded, tags: new[] { "external" });

// HttpClients
builder.Services.AddHttpClient("ThetaLakeClient")
    .ConfigureHttpClient((sp, client) =>
    {
        var opts = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<ThetaLakeOptions>>().Value;
        client.BaseAddress = new Uri(opts.BaseURL.TrimEnd('/') + "/");
        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
    })
    .AddPolicyHandler((sp, request) =>
    {
        var jitter = new Random();
        return HttpPolicyExtensions.HandleTransientHttpError().Or<TimeoutRejectedException>()
            .WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)) + TimeSpan.FromMilliseconds(jitter.Next(0, 100)));
    })
    .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30)))
    .AddPolicyHandler(Policy.BulkheadAsync<HttpResponseMessage>(20, 40));

// Graph HttpClient with resilience
builder.Services.AddHttpClient("GraphClient", client =>
{
    client.BaseAddress = new Uri("https://graph.microsoft.com/v1.0/");
    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
})
.AddPolicyHandler((sp, request) =>
{
    return HttpPolicyExtensions
        .HandleTransientHttpError()
        .OrResult(msg => (int)msg.StatusCode == 429 || (int)msg.StatusCode == 503)
        .WaitAndRetryAsync(5, attempt =>
        {
            var jitter = TimeSpan.FromMilliseconds(Random.Shared.Next(0, 250));
            return TimeSpan.FromSeconds(Math.Pow(2, attempt)) + jitter;
        }, onRetryAsync: async (outcome, timespan, retryAttempt, context) =>
        {
            if (outcome.Result?.Headers?.RetryAfter != null && outcome.Result.Headers.RetryAfter.Delta.HasValue)
            {
                await Task.Delay(outcome.Result.Headers.RetryAfter.Delta.Value);
            }
        });
})
.AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(60)))
.AddPolicyHandler(Policy.BulkheadAsync<HttpResponseMessage>(50, 200))
.AddPolicyHandler(Policy.HandleResult<HttpResponseMessage>(r => (int)r.StatusCode == 429 || (int)r.StatusCode == 503)
    .CircuitBreakerAsync(10, TimeSpan.FromMinutes(2)));

// Token client shared
builder.Services.AddHttpClient("TokenClient")
    .AddPolicyHandler(HttpPolicyExtensions.HandleTransientHttpError().WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt))));

// Services
builder.Services.AddSingleton<ITokenService, TokenService>();
builder.Services.AddSingleton<IThetaLakeApiClient, ThetaLakeApiClient>();

builder.Services.AddSingleton<IGraphTokenService, GraphTokenService>();
builder.Services.AddSingleton<GraphMessageCollector>();
builder.Services.AddHostedService<TeamsMessageCollectorService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "ThetaLake Proxy API", Version = "v1" });
});

var app = builder.Build();

// Exception middleware
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

// Health checks
app.MapHealthChecks("/health");
app.MapHealthChecks("/healthz", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = async (context, report) =>
    {
        context.Response.ContentType = "application/json";
        var result = new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(e => new { name = e.Key, status = e.Value.Status.ToString(), description = e.Value.Description })
        };
        await context.Response.WriteAsJsonAsync(result);
    }
});

app.Run();
