# ThetaLake Proxy API + Teams Collector (.NET 8)

## Features
- Theta Lake proxy endpoints
  - `POST /api/reconciliation/count`
  - `POST /api/reconciliation/new`
  - `GET /api/integrations`
- OAuth2 Client Credentials for Theta Lake
- Swagger for testing
- Health checks at `/health` and `/healthz`
- Global exception handling middleware
- Polly resilience (retry w/ jitter, timeout, bulkhead, circuit breaker)
- Microsoft Graph background collector (Teams messages)
  - Runs daily at configured UTC hour
  - Reads users from `userlist.json`
  - Saves minimal message fields to `data/teams-messages-YYYYMMDD.json`

## Configuration
Edit `appsettings.json`:

- `ThetaLake` section: `ClientURL`, `BaseURL`, `ClientID`, `ClientSecret`
- `MicrosoftGraph` section: `TenantId`, `ClientId`, `ClientSecret`, `Scope`, `UserListFile`, `OutputDirectory`, `DailyRunHourUtc`, `WindowHours`

> Ensure your AAD app has **application** permissions for Teams messages (e.g., `Chat.Read.All` or `ChatMessage.Read.All`) and admin consent.

## Run
```
dotnet restore
dotnet run
```

Open Swagger at `/swagger` to test Theta Lake endpoints.

