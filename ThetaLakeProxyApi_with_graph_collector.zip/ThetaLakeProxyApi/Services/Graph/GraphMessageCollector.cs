using System.Text.Json;
using System.Web;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Models.Graph;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Graph;

public sealed class GraphMessageCollector
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IGraphTokenService _tokenService;
    private readonly MicrosoftGraphOptions _opts;
    private readonly ILogger<GraphMessageCollector> _logger;

    private static readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    public GraphMessageCollector(IHttpClientFactory httpClientFactory,
                                 IGraphTokenService tokenService,
                                 IOptions<MicrosoftGraphOptions> options,
                                 ILogger<GraphMessageCollector> logger)
    {
        _httpClientFactory = httpClientFactory;
        _tokenService = tokenService;
        _opts = options.Value;
        _logger = logger;
    }

    public async Task<int> CollectAsync(DateTimeOffset windowStartUtc, DateTimeOffset windowEndUtc, CancellationToken ct)
    {
        var users = await LoadUsersAsync(ct);
        if (users.Count == 0)
        {
            _logger.LogWarning("User list is empty. Skipping collection.");
            return 0;
        }

        var outDir = Path.Combine(AppContext.BaseDirectory, _opts.OutputDirectory);
        Directory.CreateDirectory(outDir);
        var outFile = Path.Combine(outDir, $"teams-messages-{DateTime.UtcNow:yyyyMMdd}.json");

        var all = new List<MinimalChatMessage>();
        foreach (var upn in users)
        {
            try
            {
                var userCount = await CollectForUserAsync(upn, windowStartUtc, windowEndUtc, all, ct);
                _logger.LogInformation("Collected {Count} messages for {User}", userCount, upn);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                _logger.LogWarning("Collection cancelled.");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed collecting messages for user {User}", upn);
            }
        }

        await File.WriteAllTextAsync(outFile, JsonSerializer.Serialize(all, new JsonSerializerOptions { WriteIndented = true }), ct);
        _logger.LogInformation("Wrote {Total} messages to {File}", all.Count, outFile);
        return all.Count;
    }

    private async Task<int> CollectForUserAsync(string upn, DateTimeOffset start, DateTimeOffset end, List<MinimalChatMessage> sink, CancellationToken ct)
    {
        var token = await _tokenService.GetBearerTokenAsync(ct);
        var client = _httpClientFactory.CreateClient("GraphClient");
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var baseUrl = $"https://graph.microsoft.com/v1.0/users/{HttpUtility.UrlEncode(upn)}/chats/getAllMessages";
        var filter = $"lastModifiedDateTime gt {start.UtcDateTime:o} and lastModifiedDateTime lt {end.UtcDateTime:o}";
        var url = $"{baseUrl}?$top=50&$filter={HttpUtility.UrlEncode(filter)}";

        var total = 0;
        while (!string.IsNullOrEmpty(url))
        {
            using var resp = await client.GetAsync(url, ct);
            var json = await resp.Content.ReadAsStringAsync(ct);

            if (!resp.IsSuccessStatusCode)
            {
                _logger.LogWarning("Graph call failed ({Status}) for {User} at url={Url}: {Body}", (int)resp.StatusCode, upn, url, json);
                if ((int)resp.StatusCode == 429 || (int)resp.StatusCode == 503)
                {
                    if (resp.Headers.TryGetValues("Retry-After", out var vals) && int.TryParse(vals.FirstOrDefault(), out var seconds))
                    {
                        _logger.LogInformation("Retry-After header detected: waiting {Seconds}s", seconds);
                        await Task.Delay(TimeSpan.FromSeconds(seconds), ct);
                        continue;
                    }
                }
                resp.EnsureSuccessStatusCode();
            }

            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (root.TryGetProperty("value", out var valueElem) && valueElem.ValueKind == JsonValueKind.Array)
            {
                foreach (var msg in valueElem.EnumerateArray())
                {
                    var record = new MinimalChatMessage
                    {
                        Id = msg.TryGetProperty("id", out var id) ? id.GetString() : null,
                        MessageType = msg.TryGetProperty("messageType", out var mt) ? mt.GetString() : null,
                        CreatedDateTime = msg.TryGetProperty("createdDateTime", out var cd) && cd.ValueKind == JsonValueKind.String && DateTimeOffset.TryParse(cd.GetString(), out var cdo) ? cdo : null,
                        LastModifiedDateTime = msg.TryGetProperty("lastModifiedDateTime", out var lmd) && lmd.ValueKind == JsonValueKind.String && DateTimeOffset.TryParse(lmd.GetString(), out var lmdo) ? lmdo : null,
                        ChatId = msg.TryGetProperty("chatId", out var cid) ? cid.GetString() : null,
                        UserPrincipalName = upn
                    };
                    sink.Add(record);
                    total++;
                }
            }

            url = root.TryGetProperty("@odata.nextLink", out var next) ? next.GetString() : null;
        }

        return total;
    }

    private async Task<List<string>> LoadUsersAsync(CancellationToken ct)
    {
        var file = _opts.UserListFile;
        if (!Path.IsPathRooted(file))
            file = Path.Combine(AppContext.BaseDirectory, file);
        if (!File.Exists(file))
            return new List<string>();

        var content = await File.ReadAllTextAsync(file, ct);
        var who = JsonSerializer.Deserialize<List<string>>(content, _jsonOptions) ?? new List<string>();
        return who.Select(s => (s ?? "").Trim()).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }
}
