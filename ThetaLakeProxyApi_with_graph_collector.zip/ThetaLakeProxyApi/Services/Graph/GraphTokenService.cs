using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services.Graph;

public interface IGraphTokenService
{
    Task<string> GetBearerTokenAsync(CancellationToken ct = default);
}

internal sealed class GraphTokenService : IGraphTokenService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly MicrosoftGraphOptions _options;
    private readonly ILogger<GraphTokenService> _logger;
    private string? _cachedToken;
    private DateTimeOffset _expiresAt;

    public GraphTokenService(IHttpClientFactory httpClientFactory, IOptions<MicrosoftGraphOptions> options, ILogger<GraphTokenService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<string> GetBearerTokenAsync(CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(_cachedToken) && _expiresAt > DateTimeOffset.UtcNow.AddMinutes(2))
            return _cachedToken!;

        var tokenUrl = $"https://login.microsoftonline.com/{_options.TenantId}/oauth2/v2.0/token";
        using var client = _httpClientFactory.CreateClient("TokenClient");
        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientId,
            ["client_secret"] = _options.ClientSecret,
            ["scope"] = _options.Scope
        };

        using var content = new FormUrlEncodedContent(form);
        try
        {
            using var resp = await client.PostAsync(tokenUrl, content, ct);
            var body = await resp.Content.ReadAsStringAsync(ct);
            resp.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            _cachedToken = root.GetProperty("access_token").GetString() ?? throw new InvalidOperationException("access_token missing");
            var expiresIn = root.TryGetProperty("expires_in", out var exp) ? exp.GetInt32() : 3600;
            _expiresAt = DateTimeOffset.UtcNow.AddSeconds(expiresIn);
            _logger.LogInformation("Graph access token acquired; expires in {Seconds}s", expiresIn);
            return _cachedToken!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to acquire Microsoft Graph access token from {Url}", tokenUrl);
            throw;
        }
    }
}
