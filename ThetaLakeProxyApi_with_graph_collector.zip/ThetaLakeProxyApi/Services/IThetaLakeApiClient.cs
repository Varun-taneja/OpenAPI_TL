using ThetaLakeProxyApi.Models.ThetaLake;

namespace ThetaLakeProxyApi.Services;

public interface IThetaLakeApiClient
{
    Task<ReconciliationCountResponse> ReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct = default);
    Task<ReconciliationNewResponse> ReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct = default);
    Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct = default);
}
