namespace ThetaLakeProxyApi.Services;

public interface ITokenService
{
    Task<string> GetBearerTokenAsync(CancellationToken ct = default);
}
