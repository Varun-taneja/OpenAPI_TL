using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Models.ThetaLake;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services;

internal sealed class ThetaLakeApiClient : IThetaLakeApiClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ITokenService _tokenService;
    private readonly ThetaLakeOptions _options;
    private readonly ILogger<ThetaLakeApiClient> _logger;
    private static readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };

    public ThetaLakeApiClient(IHttpClientFactory httpClientFactory, ITokenService tokenService, IOptions<ThetaLakeOptions> options, ILogger<ThetaLakeApiClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _tokenService = tokenService;
        _options = options.Value;
        _logger = logger;
    }

    private async Task<HttpClient> CreateClientAsync(CancellationToken ct)
    {
        var token = await _tokenService.GetBearerTokenAsync(ct);
        var client = _httpClientFactory.CreateClient("ThetaLakeClient");
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return client;
    }

    public async Task<ReconciliationCountResponse> ReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct = default)
    {
        var client = await CreateClientAsync(ct);
        var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
        try
        {
            using var resp = await client.PostAsync("reconciliation/count", content, ct);
            var json = await resp.Content.ReadAsStringAsync(ct);
            resp.EnsureSuccessStatusCode();
            return JsonSerializer.Deserialize<ReconciliationCountResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling /reconciliation/count");
            throw;
        }
    }

    public async Task<ReconciliationNewResponse> ReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct = default)
    {
        var client = await CreateClientAsync(ct);
        var content = new StringContent(JsonSerializer.Serialize(request, _jsonOptions), Encoding.UTF8, "application/json");
        try
        {
            using var resp = await client.PostAsync("reconciliation/new", content, ct);
            var json = await resp.Content.ReadAsStringAsync(ct);
            resp.EnsureSuccessStatusCode();
            return JsonSerializer.Deserialize<ReconciliationNewResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling /reconciliation/new");
            throw;
        }
    }

    public async Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct = default)
    {
        var client = await CreateClientAsync(ct);
        try
        {
            using var resp = await client.GetAsync("integrations", ct);
            var json = await resp.Content.ReadAsStringAsync(ct);
            resp.EnsureSuccessStatusCode();
            return JsonSerializer.Deserialize<IntegrationsResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling /integrations");
            throw;
        }
    }
}
