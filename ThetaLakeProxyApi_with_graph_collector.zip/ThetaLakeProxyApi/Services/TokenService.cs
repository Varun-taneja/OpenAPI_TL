using System.Text.Json;
using Microsoft.Extensions.Options;
using ThetaLakeProxyApi.Options;

namespace ThetaLakeProxyApi.Services;

internal sealed class TokenService : ITokenService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ThetaLakeOptions _options;
    private readonly ILogger<TokenService> _logger;

    private string? _cachedToken;
    private DateTimeOffset _expiresAt;

    public TokenService(IHttpClientFactory httpClientFactory, IOptions<ThetaLakeOptions> options, ILogger<TokenService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<string> GetBearerTokenAsync(CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(_cachedToken) && _expiresAt > DateTimeOffset.UtcNow.AddMinutes(2))
            return _cachedToken!;

        using var client = _httpClientFactory.CreateClient("TokenClient");
        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientID,
            ["client_secret"] = _options.ClientSecret
        };
        using var content = new FormUrlEncodedContent(form);

        try
        {
            using var resp = await client.PostAsync(_options.ClientURL, content, ct);
            var json = await resp.Content.ReadAsStringAsync(ct);
            resp.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            _cachedToken = root.GetProperty("access_token").GetString() ?? throw new InvalidOperationException("access_token missing");
            var expiresIn = root.TryGetProperty("expires_in", out var exp) ? exp.GetInt32() : 3600;
            _expiresAt = DateTimeOffset.UtcNow.AddSeconds(expiresIn);
            _logger.LogInformation("ThetaLake token acquired; expires in {Sec}s", expiresIn);
            return _cachedToken!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to obtain ThetaLake access token from {Url}", _options.ClientURL);
            throw;
        }
    }
}
