using Microsoft.AspNetCore.Mvc;
using ThetaLakeProxyApi.Models.Integrations;
using ThetaLakeProxyApi.Services;

namespace ThetaLakeProxyApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class IntegrationsController : ControllerBase
{
    private readonly IThetaLakeApiClient _client;
    public IntegrationsController(IThetaLakeApiClient client) => _client = client;

    /// <summary>
    /// Proxy for GET /integrations
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(IntegrationsResponse), StatusCodes.Status200OK)]
    public async Task<ActionResult<IntegrationsResponse>> Get(CancellationToken ct)
        => Ok(await _client.GetIntegrationsAsync(ct));
}
