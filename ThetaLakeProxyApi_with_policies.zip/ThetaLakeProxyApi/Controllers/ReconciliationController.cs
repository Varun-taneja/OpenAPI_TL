using Microsoft.AspNetCore.Mvc;
using ThetaLakeProxyApi.Models.Reconciliation;
using ThetaLakeProxyApi.Services;

namespace ThetaLakeProxyApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class ReconciliationController : ControllerBase
{
    private readonly IThetaLakeApiClient _client;
    public ReconciliationController(IThetaLakeApiClient client) => _client = client;

    /// <summary>
    /// Proxy for POST /reconciliation/count
    /// </summary>
    [HttpPost("count")]
    [ProducesResponseType(typeof(ReconciliationCountResponse), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReconciliationCountResponse>> Count([FromBody] ReconciliationCountRequest request, CancellationToken ct)
        => Ok(await _client.GetReconciliationCountAsync(request, ct));

    /// <summary>
    /// Proxy for POST /reconciliation/new
    /// </summary>
    [HttpPost("new")]
    [ProducesResponseType(typeof(ReconciliationNewResponse), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReconciliationNewResponse>> New([FromBody] ReconciliationNewRequest request, CancellationToken ct)
        => Ok(await _client.PostReconciliationNewAsync(request, ct));
}
