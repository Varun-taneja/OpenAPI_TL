namespace ThetaLakeProxyApi.Models.Integrations;

public sealed class IntegrationsResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public List<Integration> Integrations { get; set; } = new();
}

public sealed class Integration
{
    public DateTimeOffset? Access_Token_Expiration_Date { get; set; }
    public string? Account_User_Email { get; set; }
    public string? Account_User_Id { get; set; }
    public DateTimeOffset Created_At { get; set; }
    public string? Description { get; set; }
    public bool Has_Integration_Policy { get; set; }
    public string Id { get; set; } = string.Empty;
    public string Integration_Group { get; set; } = string.Empty;
    public string Integration_Policy_Id { get; set; } = string.Empty;
    public string Integration_Type { get; set; } = string.Empty;
    public string Integration_Type_Id { get; set; } = string.Empty;
    public DateTimeOffset? Last_Upload_At { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateTimeOffset? Not_Before_Date { get; set; }
    public bool Notify_Submitter { get; set; }
    public bool Scopes_Changed { get; set; }
    public DateTimeOffset? Service_Last_Run_At { get; set; }
    public string Service_Paused { get; set; } = string.Empty;
    public string Service_Status { get; set; } = string.Empty; // OK | SKIPPED | BADAUTH | PAUSED
    public string Status { get; set; } = string.Empty; // Active | Paused | Invalid Credentials
    public string Status_Color { get; set; } = string.Empty;
    public DateTimeOffset? Updated_At { get; set; }
    public string? Uploads_Last_30_Days { get; set; }
    public IntegrationUser User { get; set; } = new();
}

public sealed class IntegrationUser
{
    public string Email { get; set; } = string.Empty;
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}
