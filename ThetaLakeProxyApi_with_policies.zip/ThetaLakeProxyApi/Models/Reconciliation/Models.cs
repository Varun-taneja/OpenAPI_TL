using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ThetaLakeProxyApi.Models.Reconciliation;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum DateRangeType
{
    create_date,
    upload_date
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum MediaType
{
    audio,
    chat,
    document,
    email,
    other,
    video
}

public sealed class ReconciliationCountRequest
{
    /// <summary>Third party platform to search.</summary>
    [Required]
    public string Platform { get; set; } = string.Empty;

    /// <summary>The type date range, default is upload_date.</summary>
    public DateRangeType? Type { get; set; }

    /// <summary>Inclusive start using RFC3339 date-time format.</summary>
    [Required]
    public DateTimeOffset Start { get; set; }

    /// <summary>Inclusive end using RFC3339 date-time format, defaults to Now().</summary>
    public DateTimeOffset? End { get; set; }
}

public sealed class ReconciliationCountResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public ReconciliationCountResult Result { get; set; } = new();
}

public sealed class ReconciliationCountResult
{
    public string Platform { get; set; } = string.Empty;
    public DateTimeOffset Start { get; set; }
    public DateTimeOffset? End { get; set; }
    public DateRangeType Type { get; set; }
    public double Count { get; set; }
}

// ---------- /reconciliation/new -------------

public sealed class RangeWindow
{
    public DateRangeType? Type { get; set; }
    public DateTimeOffset? Start { get; set; }
    public DateTimeOffset? End { get; set; }
}

public sealed class AttributeSelector
{
    [Required] public string Name { get; set; } = string.Empty;
    [Required] public string Value { get; set; } = string.Empty;
}

public sealed class ReconciliationQuery
{
    [Required] public string Platform { get; set; } = string.Empty;
    [Required] public AttributeSelector Attribute { get; set; } = new();
    public DateTimeOffset? Includes_Timestamp { get; set; }
    public List<MediaType>? Media_Types { get; set; }
}

public sealed class ReconciliationNewRequest
{
    public RangeWindow? Range { get; set; }
    [Required]
    [MaxLength(500)]
    public List<ReconciliationQuery> Queries { get; set; } = new();
}

// Responses

public sealed class ReconciliationNewResponse
{
    public int Status_Code { get; set; }
    public string Status_String { get; set; } = string.Empty;
    public string Request_Id { get; set; } = string.Empty;
    public ReconciliationNewResults Results { get; set; } = new();
}

public sealed class ReconciliationNewResults
{
    public int Total_Hits { get; set; }
    public RangeWindow? Range { get; set; }
    public List<ReconciliationHit> Hits { get; set; } = new();
}

public sealed class ReconciliationHit
{
    public string? Error { get; set; }
    public int Status_Code { get; set; }
    public ReconciliationQuery Query { get; set; } = new();
    public List<ReconciliationRecord> Records { get; set; } = new();
}

public sealed class ArchiveHandle
{
    public int Id { get; set; }
    public string Destination { get; set; } = string.Empty;
    public DateTimeOffset Sent_At { get; set; }
}

public sealed class ReconciliationRecord
{
    public List<ArchiveHandle>? Archive_Handles { get; set; }
    public string? Data_Path { get; set; }
    public string? Error { get; set; }
    public MediaType Media_Type { get; set; }
    public int Record_Id { get; set; }
    public DateTimeOffset Upload_Date { get; set; }
    public string Uuid { get; set; } = string.Empty;
}
