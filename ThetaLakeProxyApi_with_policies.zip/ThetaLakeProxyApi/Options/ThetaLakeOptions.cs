namespace ThetaLakeProxyApi.Options;

public sealed class ThetaLakeOptions
{
    public string ClientURL { get; set; } = string.Empty;
    public string BaseURL { get; set; } = string.Empty;
    public string ClientID { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
}
