using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Polly;
using Polly.Extensions.Http;
using Polly.Timeout;
using ThetaLakeProxyApi.Middleware;
using ThetaLakeProxyApi.Options;
using ThetaLakeProxyApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Bind options
builder.Services.Configure<ThetaLakeOptions>(builder.Configuration.GetSection("ThetaLake"));

// Logging (use built-in logging; you can swap Serilog here if desired)
// Add health checks
builder.Services.AddHealthChecks()
    .AddCheck("self", () => HealthCheckResult.Healthy("OK"))
    .AddUrlGroup(new Uri(builder.Configuration["ThetaLake:BaseURL"] ?? "https://api.thetalake.com/api/v1"), name: "thetalake-api", failureStatus: HealthStatus.Degraded, tags: new[] { "external" });

// Add HttpClient with Polly policies
builder.Services.AddHttpClient("ThetaLakeClient")
    .ConfigureHttpClient((sp, client) =>
    {
        var opts = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<ThetaLakeOptions>>().Value;
        client.BaseAddress = new Uri(opts.BaseURL.TrimEnd('/') + "/");
        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
    })
    .AddPolicyHandler((sp, request) =>
    {
        // Retry with exponential backoff for transient errors and 5xx responses
        var jitter = new Random();
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .Or<TimeoutRejectedException>()
            .WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)) + TimeSpan.FromMilliseconds(jitter.Next(0, 100)));
    })
    .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30)))
    .AddPolicyHandler(Policy.BulkheadAsync<HttpResponseMessage>(20, 40)); // limit concurrency to 20, queue 40

// Token client for obtaining tokens -- small retry as well
builder.Services.AddHttpClient("TokenClient")
    .AddPolicyHandler(HttpPolicyExtensions.HandleTransientHttpError().WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt))));

// Add services
builder.Services.AddSingleton<ITokenService, TokenService>();
builder.Services.AddSingleton<IThetaLakeApiClient, ThetaLakeApiClient>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "ThetaLake Proxy API",
        Version = "v1",
        Description = "A .NET 8 Web API that proxies selected Theta Lake endpoints for testing via Swagger."
    });
});

var app = builder.Build();

// Exception handling middleware (must be early in pipeline)
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "ThetaLake Proxy API v1");
    });
}

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

// Health checks endpoints
app.MapHealthChecks("/health");
app.MapHealthChecks("/healthz", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = async (context, report) =>
    {
        context.Response.ContentType = "application/json";
        var result = new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(e => new { name = e.Key, status = e.Value.Status.ToString(), description = e.Value.Description })
        };
        await context.Response.WriteAsJsonAsync(result);
    }
});

app.Run();
