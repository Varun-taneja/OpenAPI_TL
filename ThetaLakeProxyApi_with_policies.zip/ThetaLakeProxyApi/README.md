# ThetaLake Proxy API (NET 8)

A minimal Web API that uses OAuth2 Client Credentials to call selected Theta Lake endpoints and exposes them for testing via Swagger.

## Endpoints (your API)
- `POST /api/reconciliation/count`
- `POST /api/reconciliation/new`
- `GET  /api/integrations`

## Configure
Edit `appsettings.json`:
```json
{
  "ThetaLake": {
    "ClientURL": "https://YOUR_OAUTH_TOKEN_URL/oauth2/token",
    "BaseURL": "https://api.thetalake.com/api/v1",
    "ClientID": "YOUR_CLIENT_ID",
    "ClientSecret": "YOUR_CLIENT_SECRET"
  }
}
```

## Run
```bash
dotnet restore
dotnet run
```
Open Swagger at `https://localhost:5001/swagger` (or the port shown at startup).


## Enhancements added
- Health checks at `/health` and `/healthz` (JSON detailed output).
- Global exception handling middleware that logs unhandled exceptions and returns a JSON problem object.
- Polly policies on HTTP clients: retry (with jitter), timeout (30s), and bulkhead (concurrency + queue) for the ThetaLake client. Token client has retry policy.
- Services now use ILogger to log important events and errors.

To run locally, set the `ThetaLake` settings in `appsettings.json` and run `dotnet run`.
