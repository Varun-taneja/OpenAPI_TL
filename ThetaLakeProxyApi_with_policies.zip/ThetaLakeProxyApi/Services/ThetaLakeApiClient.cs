using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using ThetaLakeProxyApi.Options;
using ThetaLakeProxyApi.Models.Reconciliation;
using ThetaLakeProxyApi.Models.Integrations;
using Microsoft.Extensions.Options;

namespace ThetaLakeProxyApi.Services;

public interface IThetaLakeApiClient
{
    Task<ReconciliationCountResponse> GetReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct = default);
    Task<ReconciliationNewResponse> PostReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct = default);
    Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct = default);
}

internal sealed class ThetaLakeApiClient : IThetaLakeApiClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<ThetaLakeApiClient> _logger;
    private readonly ITokenService _tokenService;
    private readonly ThetaLakeOptions _options;
    private static readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = false
    };

    public ThetaLakeApiClient(IHttpClientFactory httpClientFactory, ITokenService tokenService, IOptions<ThetaLakeOptions> options, ILogger<ThetaLakeApiClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _tokenService = tokenService;
        _options = options.Value;
        _logger = logger;
    }

    private async Task<HttpClient> CreateAuthedClientAsync(CancellationToken ct)
    {
        var token = await _tokenService.GetBearerTokenAsync(ct);
        var client = _httpClientFactory.CreateClient("ThetaLakeClient");
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        return client;
    }

    public async Task<ReconciliationCountResponse> GetReconciliationCountAsync(ReconciliationCountRequest request, CancellationToken ct = default)
    {
        using var client = await CreateAuthedClientAsync(ct);
        var payload = JsonSerializer.Serialize(request, _jsonOptions);
        using var content = new StringContent(payload, Encoding.UTF8, "application/json");
        try
        {
            using var resp = await client.PostAsync("reconciliation/count", content, ct);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync(ct);
            return JsonSerializer.Deserialize<ReconciliationCountResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling reconciliation/count");
            throw;
        }
    }

    public async Task<ReconciliationNewResponse> PostReconciliationNewAsync(ReconciliationNewRequest request, CancellationToken ct = default)
    {
        using var client = await CreateAuthedClientAsync(ct);
        var payload = JsonSerializer.Serialize(request, _jsonOptions);
        using var content = new StringContent(payload, Encoding.UTF8, "application/json");
        try
        {
            using var resp = await client.PostAsync("reconciliation/new", content, ct);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync(ct);
            return JsonSerializer.Deserialize<ReconciliationNewResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling reconciliation/new");
            throw;
        }
    }

    public async Task<IntegrationsResponse> GetIntegrationsAsync(CancellationToken ct = default)
    {
        using var client = await CreateAuthedClientAsync(ct);
        try
        {
            using var resp = await client.GetAsync("integrations", ct);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync(ct);
            return JsonSerializer.Deserialize<IntegrationsResponse>(json, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling integrations");
            throw;
        }
    }
}
