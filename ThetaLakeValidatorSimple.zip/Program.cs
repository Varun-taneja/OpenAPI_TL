using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ThetaLakeValidatorSimple.Services;

var builder = Host.CreateDefaultBuilder(args)
    .ConfigureServices((hostContext, services) =>
    {
        services.AddHttpClient();
        services.AddSingleton<GraphCollectorService>();
        services.AddSingleton<ReconciliationService>();
        services.AddHostedService<GraphCollectorService>(); // Background service
    });

await builder.Build().RunAsync();