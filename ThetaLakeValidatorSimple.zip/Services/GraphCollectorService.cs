using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace ThetaLakeValidatorSimple.Services
{
    public class GraphCollectorService : BackgroundService
    {
        private readonly ILogger<GraphCollectorService> _logger;
        private readonly ReconciliationService _reconciliation;

        public GraphCollectorService(ILogger<GraphCollectorService> logger, ReconciliationService reconciliation)
        {
            _logger = logger;
            _reconciliation = reconciliation;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    _logger.LogInformation("Fetching messages from Microsoft Graph...");

                    // Simulate fetch
                    var messages = new[] { "msg1", "msg2", "msg3" };

                    _logger.LogInformation("Fetched {count} messages", messages.Length);

                    // Directly call reconciliation
                    await _reconciliation.ReconcileAsync(messages);

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in GraphCollectorService");
                }

                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }
    }
}